using HSVPicker;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace namudev
{
    public class PropertyGridColor : PropertyGridItem<Color>
    {
        private GameObject caption;
        private GameObject inputFieldR;
        private GameObject inputFieldG;
        private GameObject inputFieldB;
        private GameObject inputFieldA;
        private GameObject inputFieldHex;
        private Image colorDisplayer;
        private Button colorDisplayerBtn;

        protected override void Awake()
        {
            base.Awake();

            caption = transform.Find("Caption").gameObject;
            /*inputFieldR = transform.Find("Controls/InputFields/InputFieldR").gameObject;
            inputFieldG = transform.Find("Controls/InputFields/InputFieldG").gameObject;
            inputFieldB = transform.Find("Controls/InputFields/InputFieldB").gameObject;
            inputFieldA = transform.Find("Controls/InputFields/InputFieldA").gameObject;*/
            inputFieldHex = transform.Find("Controls/InputField").gameObject;
            colorDisplayer = transform.Find("Controls/ColorDisplayer").GetComponent<Image>();
            colorDisplayerBtn = colorDisplayer.GetComponent<Button>();
        }

        private void OnDestroy()
        {
            CreatorController.singleton.propertyColorPicker.gameObject.SetActive(false);
        }

        private void Start()
        {
            caption.GetComponentInChildren<TMP_Text>().text = Caption;
            colorDisplayer.color = Value;

            /*InputField r = inputFieldR.GetComponentInChildren<InputField>();
            r.text = Value.r.ToString();
            r.onValueChanged.AddListener(OnValueChangeR);
            r.onEndEdit.AddListener(OnEndEditR);

            InputField g = inputFieldG.GetComponentInChildren<InputField>();
            g.text = Value.g.ToString();
            g.onValueChanged.AddListener(OnValueChangeG);
            g.onEndEdit.AddListener(OnEndEditG);

            InputField b = inputFieldB.GetComponentInChildren<InputField>();
            b.text = Value.b.ToString();
            b.onValueChanged.AddListener(OnValueChangeB);
            b.onEndEdit.AddListener(OnEndEditB);

            InputField a = inputFieldA.GetComponentInChildren<InputField>();
            a.text = Value.a.ToString();
            a.onValueChanged.AddListener(OnValueChangeA);
            a.onEndEdit.AddListener(OnEndEditA);*/

            InputField hex = inputFieldHex.GetComponent<InputField>();
            hex.text = "#" + ColorUtility.ToHtmlStringRGBA(Value);
            hex.onValueChanged.AddListener(OnValueChangeHex);
            hex.onEndEdit.AddListener(OnEndEditHex);

            colorDisplayerBtn.onClick.AddListener(OnColorBtnClick);
        }

        private void OnColorBtnClick()
        {
            ColorPicker picker = CreatorController.singleton.propertyColorPicker;
            picker.gameObject.SetActive(true);
            picker.onValueChanged.RemoveAllListeners();
            picker.CurrentColor = Value;
            picker.R = Value.r;
            picker.G = Value.g;
            picker.B = Value.b;
            picker.A = Value.a;
            picker.onValueChanged.AddListener(OnValueChange);
        }

        private void OnValueChange(Color color)
        {
            colorDisplayer.color = color;
            if (Value != color)
            {
                Value = color;
                OnEndEditHex("");
            }
        }

        private void OnValueChangeHex(string hexColor)
        {
            if (ColorUtility.TryParseHtmlString(hexColor, out Color c))
            {
                Value = c;
                OnValueChange(Value);
            }
        }

        private void OnEndEditHex(string str)
        {
            InputField hex = inputFieldHex.GetComponent<InputField>();
            hex.onValueChanged.RemoveListener(OnValueChangeHex);
            hex.text = "#" + ColorUtility.ToHtmlStringRGBA(Value);
            hex.onValueChanged.AddListener(OnValueChangeHex);
        }

        private void OnValueChangeR(string str)
        {
            float r;
            if (float.TryParse(str, out r))
            {
                Color c = Value;
                Value = new Color(r, c.g, c.b, c.a);
            }
        }

        private void OnEndEditR(string str)
        {
            InputField r = inputFieldR.GetComponentInChildren<InputField>();
            r.onValueChanged.RemoveListener(OnValueChangeR);
            r.text = Value.r.ToString();
            r.onValueChanged.AddListener(OnValueChangeR);
        }

        private void OnValueChangeG(string str)
        {
            float g;
            if (float.TryParse(str, out g))
            {
                Color c = Value;
                Value = new Color(c.r, g, c.b, c.a);
            }
        }

        private void OnEndEditG(string str)
        {
            InputField g = inputFieldG.GetComponentInChildren<InputField>();
            g.onValueChanged.RemoveListener(OnValueChangeG);
            g.text = Value.g.ToString();
            g.onValueChanged.AddListener(OnValueChangeG);
        }

        private void OnValueChangeB(string str)
        {
            float b;
            if (float.TryParse(str, out b))
            {
                Color c = Value;
                Value = new Color(c.r, c.g, b, c.a);
            }
        }

        private void OnEndEditB(string str)
        {
            InputField b = inputFieldB.GetComponentInChildren<InputField>();
            b.onValueChanged.RemoveListener(OnValueChangeB);
            b.text = Value.b.ToString();
            b.onValueChanged.AddListener(OnValueChangeB);
        }

        private void OnValueChangeA(string str)
        {
            float a;
            if (float.TryParse(str, out a))
            {
                Color c = Value;
                Value = new Color(c.r, c.g, c.b, a);
            }
        }

        private void OnEndEditA(string str)
        {
            InputField a = inputFieldA.GetComponentInChildren<InputField>();
            a.onValueChanged.RemoveListener(OnValueChangeA);
            a.text = Value.a.ToString();
            a.onValueChanged.AddListener(OnValueChangeA);
        }
    }
}
