﻿namespace RLD
{
    public enum RLDMode
    {
        SelectAndManipulate = 1,
        Spawn
    }
}