﻿namespace RLD
{
    public enum ObjectGrabSurfaceFlags
    {
        Mesh = 1,
        Terrain = 2,
        Grid = 4
    }
}