﻿namespace RLD
{
    public enum AxisSign
    {
        Positive = 0,
        Negative
    }
}
