﻿namespace RLD
{
    public interface IRLDApplication
    {
    }
}
