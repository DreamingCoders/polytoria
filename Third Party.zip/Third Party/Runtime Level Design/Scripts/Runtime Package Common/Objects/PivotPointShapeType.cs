﻿namespace RLD
{
    public enum PivotPointShapeType
    {
        Square = 0,
        Circle
    }
}
