﻿namespace RLD
{
    public enum ObjectRotationPivot
    {
        IndividualPivot = 0,
        IndividualCenter,
        GroupCenter
    }
}
