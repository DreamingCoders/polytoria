﻿namespace RLD
{
    public enum InputDeviceType
    {
        Mouse = 0,
        Touch,
        VRController
    }
}
