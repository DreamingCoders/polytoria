﻿namespace RLD
{
    public enum ScenePhysicsMode
    {
        UnityColliders = 1,
        RLD
    }
}
