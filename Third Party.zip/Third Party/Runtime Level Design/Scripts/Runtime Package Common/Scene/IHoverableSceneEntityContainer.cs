﻿using UnityEngine;

namespace RLD
{
    public interface IHoverableSceneEntityContainer
    {
        bool HasHoveredSceneEntity { get; }
    }
}
