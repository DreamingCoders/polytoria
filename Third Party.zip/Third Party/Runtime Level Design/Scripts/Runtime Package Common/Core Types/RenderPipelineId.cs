﻿namespace RLD
{
    public enum RenderPipelineId
    {
        Standard = 0,
        URP,
        HDRP
    }
}
