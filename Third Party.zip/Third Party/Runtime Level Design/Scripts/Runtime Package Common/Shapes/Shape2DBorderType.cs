﻿namespace RLD
{
    public enum Shape2DBorderType
    {
        Thin = 0,
        Thick
    }
}
