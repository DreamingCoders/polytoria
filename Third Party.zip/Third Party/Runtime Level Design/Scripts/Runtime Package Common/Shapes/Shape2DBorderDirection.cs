﻿namespace RLD
{
    public enum Shape2DBorderDirection
    {
        Inward = 0,
        Outward
    }
}
