﻿namespace RLD
{
    public enum Shape2DExtentPoint
    {
        Left = 0,
        Top,
        Right,
        Bottom
    }
}
