﻿namespace RLD
{
    public enum Shape2DPtContainMode
    {
        InsideArea = 0,
        OnBorder
    }
}
