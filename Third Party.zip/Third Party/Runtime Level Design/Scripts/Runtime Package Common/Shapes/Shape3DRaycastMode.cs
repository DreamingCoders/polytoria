﻿namespace RLD
{
    public enum Shape3DRaycastMode
    {
        Solid,
        Wire
    }
}
