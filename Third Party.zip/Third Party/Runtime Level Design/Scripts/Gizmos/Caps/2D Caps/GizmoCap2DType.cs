﻿namespace RLD
{
    public enum GizmoCap2DType
    {
        Quad = 0,
        Circle,
        Arrow
    }
}
