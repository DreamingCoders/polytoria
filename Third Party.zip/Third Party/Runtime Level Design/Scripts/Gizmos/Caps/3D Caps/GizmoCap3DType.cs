﻿namespace RLD
{
    public enum GizmoCap3DType
    {
        Cone = 0,
        Pyramid,
        Box,
        Sphere,
        TriangPrism
    }
}
