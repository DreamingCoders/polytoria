﻿namespace RLD
{
    public enum GizmoDragChannel
    {
        None = 0,
        Offset,
        Rotation,
        Scale
    }
}
