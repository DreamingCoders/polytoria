﻿namespace RLD
{
    public enum UniversalGizmoSettingsType
    {
        Settings2D = 0,
        Settings3D,
        LookAndFeel2D,
        LookAndFeel3D
    }
}
