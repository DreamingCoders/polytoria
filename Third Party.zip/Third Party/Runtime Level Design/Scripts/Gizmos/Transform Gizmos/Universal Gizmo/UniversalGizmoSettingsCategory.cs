﻿namespace RLD
{
    public enum UniversalGizmoSettingsCategory
    {
        Move = 0,
        Rotate,
        Scale
    }
}
