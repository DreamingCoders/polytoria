﻿using UnityEngine;

namespace RLD
{
    public interface ISceneGizmoCamViewportUpdater
    {
        void Update(RTSceneGizmoCamera sceneGizmoCamera);
    }
}
