﻿using UnityEngine;

namespace RLD
{
    public enum GizmoDimension
    {
        None = 0,
        Dim2D,
        Dim3D
    }
}
