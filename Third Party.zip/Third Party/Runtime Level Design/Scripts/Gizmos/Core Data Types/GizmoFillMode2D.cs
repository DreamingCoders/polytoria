﻿using System;

namespace RLD
{
    public enum GizmoFillMode2D
    {
        Filled = 0,
        Border,
        FilledAndBorder
    }
}
