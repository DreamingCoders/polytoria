﻿namespace RLD
{
    public enum GizmoPlane2DType
    {
        Quad = 0,
        Circle,
        Polygon
    }
}
