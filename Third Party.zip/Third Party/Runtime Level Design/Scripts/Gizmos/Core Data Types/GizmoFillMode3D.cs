﻿namespace RLD
{
    public enum GizmoFillMode3D
    {
        Filled = 0,
        Wire
    }
}
