﻿namespace RLD
{
    public enum GizmoSnapMode
    {
        Relative = 0,
        Absolute
    }
}
