﻿namespace RLD
{
    public enum GizmoPlane3DType
    {
        Quad = 0,
        RATriangle,
        Circle
    }
}
