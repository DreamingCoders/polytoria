﻿namespace RLD
{
    public enum GizmoShadeMode
    {
        Lit = 0,
        Flat
    }
}