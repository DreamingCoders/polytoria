﻿namespace RLD
{
    public enum GizmoLine2DType
    {
        Thin = 0,
        Box
    }
}
