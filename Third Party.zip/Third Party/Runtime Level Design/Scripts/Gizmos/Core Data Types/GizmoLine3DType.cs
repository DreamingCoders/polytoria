﻿namespace RLD
{
    public enum GizmoLine3DType 
    {
        Thin = 0,
        Box,
        Cylinder
    }
}
