﻿namespace RLD
{
    public enum GizmoSpace
    {
        Global = 0,
        Local
    }
}
