﻿namespace RLD
{
    public enum GizmoMultiAxisScaleMode
    {
        DoubleAxis = 0,
        Uniform
    }
}
