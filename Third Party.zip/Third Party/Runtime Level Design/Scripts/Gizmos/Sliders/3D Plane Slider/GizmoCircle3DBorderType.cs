﻿namespace RLD
{
    public enum GizmoCircle3DBorderType
    {
        Thin = 0,
        Torus,
        CylindricalTorus
    }
}
