﻿namespace RLD
{
    public enum GizmoQuad3DBorderType
    {
        Thin = 0,
        Box
    }
}
