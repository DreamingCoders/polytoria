﻿namespace RLD
{
    public enum GizmoRATriangle3DBorderType
    {
        Thin = 0
    }
}
