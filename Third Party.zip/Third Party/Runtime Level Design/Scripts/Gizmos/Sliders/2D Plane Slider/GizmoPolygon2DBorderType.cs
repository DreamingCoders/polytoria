﻿namespace RLD
{
    public enum GizmoPolygon2DBorderType
    {
        Thin = 0,
        Thick
    }
}
