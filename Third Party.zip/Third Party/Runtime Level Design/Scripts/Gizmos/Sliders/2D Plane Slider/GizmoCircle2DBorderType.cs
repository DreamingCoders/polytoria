﻿namespace RLD
{
    public enum GizmoCircle2DBorderType
    {
        Thin = 0
    }
}