﻿namespace RLD
{
    public enum GizmoQuad2DBorderType
    {
        Thin = 0
    }
}
