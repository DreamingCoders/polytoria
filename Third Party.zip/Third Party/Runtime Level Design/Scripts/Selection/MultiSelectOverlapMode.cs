﻿namespace RLD
{
    public enum MultiSelectOverlapMode
    {
        Partial = 0,
        FullOverlap
    }
}
