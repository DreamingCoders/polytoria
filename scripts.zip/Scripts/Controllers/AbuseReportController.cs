using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;

public class AbuseReportController : MonoBehaviour
{
	[SerializeField] TMP_InputField input;
	[SerializeField] RectTransform defaultPanel, finishedPanel;

	public void Submit()
	{
		string message = input.text.Trim();
		if (message.Replace(" ", "").Length == 0) return;

		StartCoroutine(SubmitAbuseReport(message));
		defaultPanel.gameObject.SetActive(false);
		finishedPanel.gameObject.SetActive(true);
	}

	public void Return()
	{
		input.text = "";
		defaultPanel.gameObject.SetActive(true);
		finishedPanel.gameObject.SetActive(false);
	}

	public void Cancel()
	{
		input.text = "";
		UIController.singleton.SetActiveMenuTab(0);
		UIController.singleton.TogglePaused();
	}

	IEnumerator SubmitAbuseReport(string message)
	{
		if (LaunchController.isLocal || LaunchController.isSolo) yield break;
		WWWForm form = new WWWForm();
		form.AddField("message", message);
		using (UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/game/client/report", form))
		{
			uwr.SetRequestHeader("Authorization", LaunchController.clientToken);
			yield return uwr.SendWebRequest();
		}
	}
}
