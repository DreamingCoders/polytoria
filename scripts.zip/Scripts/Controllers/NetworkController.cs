using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using kcp2k;
using Mirror;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

public class NetworkController : MonoBehaviour
{
	public static NetworkController singleton;
	string passphrase;
	public int PlaceID
	{
		get; private set;
	}

	private void Awake()
	{
		if (singleton != null)
			Debug.LogWarning("NetworkController already initialized!");

		singleton = this;
	}

	void Start()
	{
		switch (LaunchController.launchType)
		{
			case NetworkType.Host:
				StartCoroutine(PlaySolo());
				break;
			case NetworkType.Server:
#if !PRODUCTION_CLIENT
				if (!LaunchController.isLocal)
					Application.targetFrameRate = 30;
				StartCoroutine(StartServer());
#endif
				break;
			case NetworkType.Client:
				passphrase = "5ZnNWJHc7KmntXxc";
				if (!LaunchController.isLocal && LaunchController.clientToken == null)
				{
					Debug.LogError("Client token null, aborting...");
					break;
				}
				StartCoroutine(StartClient());
				break;
		}
	}

#if !PRODUCTION_CLIENT
	IEnumerator StartServer()
	{
		if (LaunchController.isLocal)
		{
			PlaceID = LaunchController.localGameId;
			NetworkManager.singleton.GetComponent<KcpTransport>().Port = 7777;
			NetworkManager.singleton.StartServer();
		}
		else
		{
			using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/game/server/listen"))
			{
				uwr.SetRequestHeader("Authorization", LaunchController.serverToken);
				uwr.SetRequestHeader("Accept", "application/json");
				yield return uwr.SendWebRequest();

				if (uwr.result != UnityWebRequest.Result.Success)
				{
					Debug.LogError("Could not start server: Network error.");
					Debug.LogError(uwr.downloadHandler.text);
					yield break;
				}

				JSONNode data = JSON.Parse(uwr.downloadHandler.text);
				PlaceID = data["placeID"];

				if (!LaunchController.isLocal)
				{
					NetworkManager.singleton.GetComponent<KcpTransport>().Port = (ushort) data["port"];
					NetworkManager.singleton.GetComponent<KcpTransport>().Timeout = 10000;
				}

				NetworkManager.singleton.StartServer();
			}
		}
	}
#endif

	IEnumerator StartClient()
	{
		yield return new WaitForEndOfFrame();

		LoadScreenController.singleton.SetStatus("Requesting game data");

		if (LaunchController.isLocal)
		{
#if !PRODUCTION_CLIENT
			NetworkManager.singleton.GetComponent<KcpTransport>().Port = 7777;
			NetworkManager.singleton.StartClient();
#else
Application.Quit();
yield break;
#endif
		}
		else
		{
			WWWForm form = new WWWForm();
			JSONNode telemetryInfo = new JSONObject();
			telemetryInfo["GameVersion"] = Application.version;
			telemetryInfo["DeviceName"] = SystemInfo.deviceName;
			telemetryInfo["DeviceModel"] = SystemInfo.deviceModel;
			telemetryInfo["DeviceType"] = SystemInfo.deviceType.ToString();
			telemetryInfo["DeviceUniqueIdentifier"] = SystemInfo.deviceUniqueIdentifier;
			telemetryInfo["GraphicsDeviceName"] = SystemInfo.graphicsDeviceName;
			telemetryInfo["GraphicsDeviceType"] = SystemInfo.graphicsDeviceType.ToString();
			telemetryInfo["GraphicsMemorySize"] = SystemInfo.graphicsMemorySize;
			telemetryInfo["OperatingSystem"] = SystemInfo.operatingSystem;
			telemetryInfo["ProcessorCount"] = SystemInfo.processorCount;
			telemetryInfo["ProcessorFrequency"] = SystemInfo.processorFrequency;
			telemetryInfo["ProcessorType"] = SystemInfo.processorType;
			telemetryInfo["SystemMemorySize"] = SystemInfo.systemMemorySize;
			telemetryInfo["Platform"] = Application.platform.ToString();
			telemetryInfo["UnsupportedIdentifier"] = SystemInfo.unsupportedIdentifier;
			telemetryInfo["UnityVersion"] = Application.unityVersion;

			byte[] telemetryInfoBytes = Encoding.ASCII.GetBytes(telemetryInfo.ToString());

			SHA256 sha256 = SHA256Managed.Create();
			byte[] key = sha256.ComputeHash(Encoding.ASCII.GetBytes(passphrase));
			byte[] iv = new byte[16] { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 };

			Aes encryptor = Aes.Create();

			encryptor.Mode = CipherMode.CBC;
			encryptor.Key = key;
			encryptor.IV = iv;

			MemoryStream memoryStream = new MemoryStream();
			ICryptoTransform aesEncryptor = encryptor.CreateEncryptor();
			CryptoStream cryptoStream = new CryptoStream(memoryStream, aesEncryptor, CryptoStreamMode.Write);
			cryptoStream.Write(telemetryInfoBytes, 0, telemetryInfoBytes.Length);

			cryptoStream.FlushFinalBlock();
			byte[] cipherBytes = memoryStream.ToArray();

			memoryStream.Close();
			cryptoStream.Close();

			string base64 = Convert.ToBase64String(cipherBytes);

			string timestamp = ((int) (DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds).ToString();
			form.AddField("telemetry", base64);
			form.AddField("timestamp", timestamp);
			form.AddField("token", LaunchController.clientToken);
			form.AddField("signature", Convert.ToBase64String(sha256.ComputeHash(Encoding.ASCII.GetBytes(base64 + timestamp + LaunchController.clientToken))));

			using (UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/game/client/connect", form))
			{
				uwr.SetRequestHeader("Authorization", LaunchController.clientToken);
				uwr.SetRequestHeader("Accept", "application/json");
				yield return uwr.SendWebRequest();

				if (uwr.result != UnityWebRequest.Result.Success)
				{
					//HudController.singleton.SetLoadingStatus(uwr.error);
					yield break;
				}

				JSONNode tokenData = JSON.Parse(uwr.downloadHandler.text);

				UIController.singleton?.SetGameInfo(tokenData["name"]);
				LoadScreenController.singleton.SetGameInfo(tokenData["name"]);
				Game.GameName = tokenData["name"];

				LoadScreenController.singleton.SetStatus("Connecting to server");

				DiscordController.Instance.UpdateActivity(new Discord.Activity
				{
					State = tokenData["name"],
					Details = "Waiting for server",
					Assets = {
						LargeImage = "multiplayer",
						LargeText = "Multiplayer"
					},
					Timestamps =
					{
						Start = DateTimeOffset.Now.ToUnixTimeSeconds()
					}
				});

				NetworkManager.singleton.networkAddress = tokenData["ip"];
				NetworkManager.singleton.GetComponent<KcpTransport>().Port = (ushort) tokenData["port"];
				NetworkManager.singleton.GetComponent<KcpTransport>().Timeout = 120000;
				NetworkManager.singleton.StartClient();
			}
		}

	}

	IEnumerator PlaySolo()
	{
		if (!LaunchController.isSolo) yield break;
		Debug.Log("Playing solo");
		yield return new WaitForEndOfFrame();
		//PresenceManager.UpdatePresence(detail: "Playing solo", largeKey: "solo", start: DateTimeOffset.Now.ToUnixTimeSeconds());

		DiscordController.Instance.UpdateActivity(new Discord.Activity
		{
			State = null,
			Details = "Playing solo",
			Assets = {
				LargeImage = "solo",
				LargeText = "Solo"
			},
			Timestamps =
			{
				Start = DateTimeOffset.Now.ToUnixTimeSeconds()
			}
		});

		NetworkManager.singleton.StartHost();
		//HudController.singleton.FinishLoading();
	}
}
