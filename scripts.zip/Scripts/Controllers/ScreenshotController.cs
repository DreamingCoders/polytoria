using System;
using System.Collections;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using SimpleJSON;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class ScreenshotController : MonoBehaviour
{
	public static ScreenshotController instance { get; private set; }
	[SerializeField] RectTransform toast;
	[SerializeField] RectTransform publishModal;
	[SerializeField] public TMP_InputField captionInput;
	[SerializeField] Button publishButton;
	[SerializeField] TMP_Text publishError;
	float toastDuration = 5f;
	float toastTimer = 0f;
	bool toastActive = false;
	string screenshotPath = "";
	Sprite lastScreenshot;
	string passphrase = "";
	byte[] screenshotBytes;

	public bool Focused
	{
		get
		{
			if (captionInput)
			{
				return captionInput.isFocused;
			}
			else
			{
				return false;
			}
		}
	}

	private void Awake()
	{
		instance = this;
	}

	void Start()
	{
		passphrase = "Xcbr3snwgYRB7TFtvBYNTV";
		toast.Find("PublishBtn").GetComponent<Button>().onClick.AddListener(() =>
		{
			publishModal.gameObject.SetActive(true);
			publishModal.Find("Image").GetComponent<Image>().sprite = lastScreenshot;
			publishModal.GetComponentInChildren<TMP_InputField>().text = "";
			HideToast();
		});
	}

	void Update()
	{
		if (toastActive)
		{
			toastTimer -= Time.deltaTime;
			if (toastTimer <= 0)
			{
				HideToast();
			}
		}

		if (Input.GetKeyDown(KeyCode.F12))
		{
			Screenshot(false);
		}
	}

	void HideToast()
	{
		if (!toastActive) return;
		toastActive = false;
		toastTimer = 0f;
		LeanTween.moveX(toast.gameObject, Screen.width + (toast.rect.width / 2) + 15f, 1f).setEase(LeanTweenType.easeOutExpo);
	}

	void ShowToast()
	{
		if (LaunchController.isSolo) return;
		if (toastActive) return;
		toastActive = true;
		toastTimer = toastDuration;
		LeanTween.moveX(toast.gameObject, Screen.width - (toast.rect.width / 2) - 15f, 0.5f).setEase(LeanTweenType.easeOutQuad);
	}

	public void Screenshot(bool hideUI)
	{
		StartCoroutine(DoScreenshot(hideUI));
	}

	IEnumerator DoScreenshot(bool hideUI)
	{
		if (hideUI)
		{
			GetComponent<Canvas>().enabled = false;
		}

		string path = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyPictures), "Polytoria");
		if (!Directory.Exists(path))
		{
			Directory.CreateDirectory(path);
		}
		DateTime time = DateTime.Now;
		string formattedTime = time.ToString("yyyyMMdd-hhmmss");
		string filename = "PolytoriaScreenshot-" + formattedTime + ".png";
		yield return new WaitForEndOfFrame();
		screenshotPath = Path.Combine(path, filename);
		ScreenCapture.CaptureScreenshot(screenshotPath);
		while (!File.Exists(screenshotPath))
		{
			yield return new WaitForSeconds(0.1f);
		}

		screenshotBytes = File.ReadAllBytes(screenshotPath);

		Texture2D screenshot = new Texture2D(Screen.width, Screen.height, TextureFormat.RGB24, false);
		ImageConversion.LoadImage(screenshot, File.ReadAllBytes(screenshotPath));
		toast.Find("Image").GetComponent<Image>().sprite = lastScreenshot = Sprite.Create(screenshot, new Rect(0, 0, screenshot.width, screenshot.height), new Vector2(0.5f, 0.5f));

		if (hideUI)
		{
			GetComponent<Canvas>().enabled = true;
			if (UIController.Paused) UIController.singleton.TogglePaused();
		}

		ShowToast();
		yield return 0;
	}

	public void OpenScreenshot()
	{
		if (screenshotPath == "") return;
		Application.OpenURL(screenshotPath);
	}

	public void PublishScreenshot()
	{
		publishButton.interactable = false;
		publishError.text = "";
		StartCoroutine(DoPublishScreenshot());
	}

	IEnumerator DoPublishScreenshot()
	{
		SHA256 sha256 = SHA256Managed.Create();
		byte[] key = sha256.ComputeHash(Encoding.ASCII.GetBytes(passphrase));
		byte[] iv = new byte[16] { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 };

		Aes encryptor = Aes.Create();

		encryptor.Mode = CipherMode.CBC;
		encryptor.Key = key;
		encryptor.IV = iv;

		MemoryStream memoryStream = new MemoryStream();
		ICryptoTransform aesEncryptor = encryptor.CreateEncryptor();
		CryptoStream cryptoStream = new CryptoStream(memoryStream, aesEncryptor, CryptoStreamMode.Write);
		cryptoStream.Write(screenshotBytes, 0, screenshotBytes.Length);

		cryptoStream.FlushFinalBlock();
		byte[] cipherBytes = memoryStream.ToArray();

		memoryStream.Close();
		cryptoStream.Close();

		string base64 = Convert.ToBase64String(cipherBytes);

		WWWForm form = new WWWForm();
		byte[] bytes = Encoding.UTF8.GetBytes(base64);
		form.AddBinaryData("data", bytes, "screenshot.png");
		form.AddField("caption", captionInput.text);

		using (UnityWebRequest www = UnityWebRequest.Post("https://api.polytoria.com/v1/game/client/publish-screenshot", form))
		{
			www.SetRequestHeader("Authorization", LaunchController.clientToken);
			yield return www.SendWebRequest();
			if (www.result != UnityWebRequest.Result.Success)
			{
				try
				{
					JSONNode json = JSON.Parse(www.downloadHandler.text);
					publishError.text = json["Errors"][0].Value;
				}
				catch
				{
					publishError.text = www.error;
				}
			}
			else
			{
				Application.OpenURL("https://polytoria.com/home");
				publishModal.gameObject.SetActive(false);
			}
		}

		publishButton.interactable = true;
		yield return 0;
	}
}
