using System.Collections;
using System.Text.RegularExpressions;
using SimpleJSON;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class ToolboxController : MonoBehaviour
{
	[SerializeField] TMP_Dropdown categorySelector;
	[SerializeField] RectTransform toolboxContainer;
	[SerializeField] RectTransform entryPrefab;
	[SerializeField] TMP_Text pageLabel;

	int page = 1;
	int pageLimit = int.MaxValue;

	ToolboxCategory cat = ToolboxCategory.RecentlyUpdated;

	public int Page
	{
		get => page;
		set
		{
			page = Mathf.Clamp(value, 1, pageLimit);
			ReloadToolbox();
		}
	}

	public ToolboxCategory Category
	{
		get => cat;
		set
		{
			cat = value;
			ReloadToolbox();
		}
	}

	private string searchQuery;

	public string SearchQuery
	{
		get => searchQuery;
		set { searchQuery = value; ReloadToolbox(); }
	}


	private void Start()
	{
		string[] categories = System.Enum.GetNames(typeof(ToolboxCategory));

		foreach (string category in categories)
		{
			categorySelector.options.Add(new TMP_Dropdown.OptionData(Regex.Replace(category, @"((?<=\p{Ll})\p{Lu})|((?!\A)\p{Lu}(?>\p{Ll}))", " $0")));
		}

		categorySelector.value = 0;

		ReloadToolbox();
	}

	public void SetSearchQuery(string q)
	{
		SearchQuery = q;
	}

	public void ReloadToolbox()
	{
		StartCoroutine(DoReloadToolbox());
	}

	public void PageUp()
	{
		if (Page < pageLimit)
			Page++;
	}

	public void PageDown()
	{
		if (Page > 1)
			Page--;
	}

	IEnumerator DoReloadToolbox()
	{
		using (UnityWebRequest uwr = UnityWebRequest.Get($"https://api.polytoria.com/v1/models/toolbox?page={Page}&q=" + UnityWebRequest.EscapeURL(SearchQuery) + "&cat=" + Category.ToString()))
		{
			uwr.SetRequestHeader("Authorization", CreatorController.singleton.CreatorToken ?? "");
			yield return uwr.SendWebRequest();

			if (uwr.result != UnityWebRequest.Result.Success)
			{
				Debug.LogError(uwr.error);
				yield break;
			}

			foreach (Transform transform in toolboxContainer)
			{
				Destroy(transform.gameObject);
			}

			JSONNode node = JSON.Parse(uwr.downloadHandler.text);

			foreach (JSONNode entry in node["data"])
			{
				RectTransform r = Instantiate(entryPrefab, toolboxContainer);

				r.Find("Title").GetComponent<TMP_Text>().text = entry["name"];
				r.Find("ThumbnailCard").GetComponent<Button>().onClick.AddListener(delegate { InsertModel(entry["id"]); });
				r.Find("Title").GetComponent<Button>().onClick.AddListener(delegate { InsertModel(entry["id"]); });
				r.Find("Creator").GetComponent<TMP_Text>().text = "By " + entry["creatorName"];
				r.Find("Creator").GetComponent<Button>().onClick.AddListener(delegate { Application.OpenURL("https://polytoria.com/user/" + entry["creatorID"]); });
			}

			pageLimit = node["meta"]["lastPage"].AsInt;
			page = node["meta"]["currentPage"].AsInt;

			pageLabel.text = "Page " + page + " of " + pageLimit;

			LayoutRebuilder.ForceRebuildLayoutImmediate(toolboxContainer);
		}
	}

	public void InsertModel(int id)
	{
		GameIO.singleton.LoadModelFromSite(id, Game.singleton.FindChildOfType<Environment>(), (i) =>
		{
			if (i is Model model)
			{
				CreatorController.singleton.ToolboxModelAdded(model);
			}
		});
	}

	public void SetCategory(int c)
	{
		page = 0;
		Category = (ToolboxCategory) c;
	}

	public enum ToolboxCategory
	{
		RecentlyUpdated,
		//BestSelling,
		//FreeModels,
		//PurchasedModels,
		UploadedModels
	}
}
