using TMPro;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.UI;

public class SettingsController : MonoBehaviour
{

	[SerializeField] RectTransform audioContainer;
	[SerializeField] RectTransform graphicsContainer;
	[SerializeField] RectTransform inputContainer;
	[SerializeField] RectTransform miscContainer;
	[SerializeField] PostProcessLayer postProcessLayer;

	public RectTransform[] containers;

	void Start()
	{
		postProcessLayer = FindObjectOfType<PostProcessLayer>();
		LoadSettings();

		SetSettingsCategory(0);
	}

	public void SetSettingsCategory(int index)
	{
		for (int i = 0; i < containers.Length; i++)
		{
			containers[i].gameObject.SetActive(false);
		}
		containers[index].gameObject.SetActive(true);
	}

	public void LoadSettings()
	{
		SetFullscreen(PlayerPrefs.GetInt("Graphics_Fullscreen", 0) == 1);
		SetPostProcessing(PlayerPrefs.GetInt("Graphics_PostProcessing", 1) == 1);
		SetQualityLevel(PlayerPrefs.GetInt("Graphics_QualityLevel", 5));
		SetPixelLightCount(PlayerPrefs.GetInt("Graphics_PixelLightCount", QualitySettings.pixelLightCount));
		SetShadowDistance(PlayerPrefs.GetFloat("Graphics_ShadowDistance", QualitySettings.shadowDistance));
		SetShadowResolution(PlayerPrefs.GetInt("Graphics_ShadowResolution", (int) QualitySettings.shadowResolution));
		SetTextureQuality(PlayerPrefs.GetInt("Graphics_TextureQuality", QualitySettings.globalTextureMipmapLimit));
		SetVSync(PlayerPrefs.GetInt("Graphics_VSync", QualitySettings.vSyncCount));
		SetAntiAliasing(PlayerPrefs.GetInt("Graphics_AntiAliasing", (int) postProcessLayer.antialiasingMode));
		SetAnisotropicFiltering(PlayerPrefs.GetInt("Graphics_AnisotropicFiltering", (int) QualitySettings.anisotropicFiltering));

		SetDebugLogLength(PlayerPrefs.GetInt("Misc_MaxDebugLogLength", UIController.maxDebugLogLength).ToString());

		SetMouseSensitivity(PlayerPrefs.GetFloat("Input_MouseSensitivity", CameraController.sensitivityModifier));

		SetMasterVolume(PlayerPrefs.GetFloat("Audio_MasterVolume", AudioListener.volume));

		ReloadAudioControls();
		ReloadGraphicsControls();
		ReloadInputControls();
		ReloadMiscControls();
	}

	void ReloadInputControls()
	{
		inputContainer.Find("MouseSensitivity").GetComponentInChildren<Slider>().value = CameraController.sensitivityModifier;
	}

	void ReloadMiscControls()
	{
		miscContainer.Find("MaxDebugLogLength").GetComponentInChildren<TMP_InputField>().text = UIController.maxDebugLogLength.ToString();
	}

	void ReloadAudioControls()
	{
		audioContainer.Find("MasterVolume").GetComponentInChildren<Slider>().value = AudioListener.volume;
	}

	void ReloadGraphicsControls()
	{
		graphicsContainer.Find("QualityLevel").GetComponentInChildren<TMP_Dropdown>().value = QualitySettings.GetQualityLevel();
		graphicsContainer.Find("Fullscreen").GetComponentInChildren<Toggle>().isOn = Screen.fullScreenMode == FullScreenMode.FullScreenWindow;
		graphicsContainer.Find("PostProcessing").GetComponentInChildren<Toggle>().isOn = postProcessLayer.enabled;
		graphicsContainer.Find("TextureQuality").GetComponentInChildren<TMP_Dropdown>().value = QualitySettings.globalTextureMipmapLimit;
		graphicsContainer.Find("ShadowResolution").GetComponentInChildren<TMP_Dropdown>().value = (int) QualitySettings.shadowResolution;
		graphicsContainer.Find("ShadowDistance").GetComponentInChildren<Slider>().value = QualitySettings.shadowDistance;
		graphicsContainer.Find("PixelLightCount").GetComponentInChildren<Slider>().value = QualitySettings.pixelLightCount;
		graphicsContainer.Find("VSync").GetComponentInChildren<TMP_Dropdown>().value = QualitySettings.vSyncCount;
		graphicsContainer.Find("AntiAliasing").GetComponentInChildren<TMP_Dropdown>().value = (int) postProcessLayer.antialiasingMode;
		graphicsContainer.Find("AnisotropicFiltering").GetComponentInChildren<TMP_Dropdown>().value = (int) QualitySettings.anisotropicFiltering;
	}

	#region setting handlers
	public void SetMouseSensitivity(float sensitivity)
	{
		PlayerPrefs.SetFloat("Input_MouseSensitivity", sensitivity);
		CameraController.sensitivityModifier = sensitivity;
	}
	public void SetDebugLogLength(string slength) // string for inputfield
	{
		if (int.TryParse(slength, out int length))
		{
			length = Mathf.Max(length, 1);
			PlayerPrefs.SetInt("Misc_MaxDebugLogLength", length);
			UIController.maxDebugLogLength = length;
		}
	}

	public void SetFullscreen(bool fullscreen)
	{
		PlayerPrefs.SetInt("Graphics_Fullscreen", fullscreen ? 1 : 0);
		Screen.fullScreenMode = fullscreen ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed;

		if (fullscreen)
			Screen.SetResolution(Display.main.systemWidth, Display.main.systemHeight, fullscreen);
	}

	public void SetQualityLevel(int qualityLevel)
	{
		PlayerPrefs.SetInt("Graphics_QualityLevel", qualityLevel);
		QualitySettings.SetQualityLevel(qualityLevel);
	}

	public void SetPixelLightCount(float pixelLightCount)
	{
		PlayerPrefs.SetInt("Graphics_PixelLightCount", (int) pixelLightCount);
		QualitySettings.pixelLightCount = (int) pixelLightCount;
	}

	public void SetShadowDistance(float shadowDistance)
	{
		PlayerPrefs.SetFloat("Graphics_ShadowDistance", shadowDistance);
		QualitySettings.shadowDistance = shadowDistance;
	}

	public void SetShadowResolution(int shadowResolution)
	{
		PlayerPrefs.SetInt("Graphics_ShadowResolution", shadowResolution);
		QualitySettings.shadowResolution = (ShadowResolution) shadowResolution;
	}

	public void SetTextureQuality(int textureQuality)
	{
		PlayerPrefs.SetInt("Graphics_TextureQuality", textureQuality);
		QualitySettings.globalTextureMipmapLimit = textureQuality;
	}

	public void SetVSync(int vSync)
	{
		PlayerPrefs.SetInt("Graphics_VSync", vSync);
		QualitySettings.vSyncCount = vSync;
	}

	public void SetAntiAliasing(int antiAliasing)
	{
		PlayerPrefs.SetInt("Graphics_AntiAliasing", antiAliasing);
		QualitySettings.antiAliasing = antiAliasing;
	}

	public void SetAnisotropicFiltering(int anisotropicFiltering)
	{
		PlayerPrefs.SetInt("Graphics_AnisotropicFiltering", anisotropicFiltering);
		QualitySettings.anisotropicFiltering = (AnisotropicFiltering) anisotropicFiltering;
	}

	public void SetPostProcessing(bool postProcessing)
	{
		PlayerPrefs.SetInt("Graphics_PostProcessing", postProcessing ? 1 : 0);
		PostProcessLayer postProcessLayer = Camera.main.GetComponent<PostProcessLayer>();
		if (postProcessLayer != null)
			postProcessLayer.enabled = postProcessing;
	}

	public void SetMasterVolume(float volume)
	{
		PlayerPrefs.SetFloat("Audio_MasterVolume", volume);
		AudioListener.volume = volume;
	}
	#endregion
}
