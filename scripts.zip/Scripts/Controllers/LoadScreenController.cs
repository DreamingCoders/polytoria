using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class LoadScreenController : MonoBehaviour
{
	public static LoadScreenController singleton;

	[SerializeField] Image progressBar;
	[SerializeField] GameObject progressBarContainer;
	[SerializeField] TMP_Text gameName;
	[SerializeField] TMP_Text loadingStatus;

	public bool IsLoadingMap { get; set; }
	public int InstanceCount { get; set; }

	private void Awake()
	{
		singleton = this;
	}

	private void Start()
	{
		if (LaunchController.launchType == NetworkType.Server || LaunchController.isLocal || LaunchController.isSolo) gameObject.SetActive(false);
		Game.GameLoadedLocally += GameLoaded;
	}

	public void GameLoaded()
	{
		gameObject.SetActive(false);
	}

	public void SetStatus(string status)
	{
		loadingStatus.text = status;
	}

	public void SetGameInfo(string name)
	{
		gameName.text = name;
	}

	private void Update()
	{
		if (IsLoadingMap)
		{
			if (!progressBarContainer.activeInHierarchy) progressBarContainer.SetActive(true);

			if (Game.singleton == null) return;

			if (Game.singleton.InstanceCount <= 1)
			{
				loadingStatus.text = $"Loading parts";
				progressBar.fillAmount = 0f;
			}
			else
			{
				loadingStatus.text = $"Loading parts ({Game.singleton.LocalInstanceCount} / {InstanceCount})";
				progressBar.fillAmount = (float) Game.singleton.LocalInstanceCount / InstanceCount;
			}
		}
	}
}
