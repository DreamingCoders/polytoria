using Mirror;
using UnityEngine;

public class CreatorStart : MonoBehaviour
{
	// Start is called before the first frame update
	void Start()
	{
		NetworkManager.singleton.GetComponent<kcp2k.KcpTransport>().Port = 7778;
		NetworkManager.singleton.StartServer();
	}
}
