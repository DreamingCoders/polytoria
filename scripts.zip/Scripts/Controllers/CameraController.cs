using System.Collections.Generic;
using MoonSharp.Interpreter;
using UnityEngine;
using UnityEngine.EventSystems;

[RequireComponent(typeof(Camera))]
public class CameraController : MonoBehaviour
{
	public static float sensitivityModifier = 1f;
	public static CameraController instance;
	public LayerMask clipIgnoreLayers;
	public List<MeshRenderer> disableOnFirstPerson;

	public CameraMode Mode { get; set; }
	public float FOV
	{
		get => cam.fieldOfView; set => cam.fieldOfView = value;
	}
	public bool Orthographic
	{
		get => cam.orthographic; set => cam.orthographic = value;
	}
	public float OrthographicSize
	{
		get => cam.orthographicSize; set => cam.orthographicSize = value;
	}
	public float Distance
	{
		get => distance; set => distance = value;
	}
	public float MinDistance
	{
		get => minDist; set => minDist = value;
	}
	public float MaxDistance
	{
		get => maxDist; set => maxDist = value;
	}
	public float HorizontalSpeed
	{
		get => xSpeed; set => xSpeed = value;
	}
	public float VerticalSpeed
	{
		get => ySpeed; set => ySpeed = value;
	}
	public float ScrollSensitivity
	{
		get => scrollSensitivity; set => scrollSensitivity = value;
	}
	public bool ClipThroughWalls
	{
		get => clipThroughWalls; set => clipThroughWalls = value;
	}

	public float FlySpeed
	{
		get => flySpeed; set => flySpeed = value;
	}
	public float FastFlySpeed
	{
		get => fastFlySpeed; set => fastFlySpeed = value;
	}
	public float FreeLookSensitivity
	{
		get => freeLookSensitivity; set => freeLookSensitivity = value;
	}
	public float LerpSpeed { get; set; } = 15f;
	public bool FollowLerp { get; set; } = false;
	public bool CanLock { get; set; } = true;
	public bool CtrlLocked { get; set; } = false;

	public Vector3 Position
	{
		get => transform.position;
		set => transform.position = value;
	}

	public Vector3 Rotation
	{
		get => transform.eulerAngles;
		set => transform.eulerAngles = value;
	}

	public bool IsFirstPerson => distance == 0;

	bool DoLerp => !IsFirstPerson && FollowLerp;

	// Follow settings
	private Camera cam;
	private Transform target;
	private float distance = 5.0f;
	private float distanceLerp = 0.0f;
	private float xSpeed = 120.0f;
	private float ySpeed = 120.0f;
	private float yMinLimit = -80f;
	private float yMaxLimit = 80f;
	private float distanceMax = 20f;
	private float minDist = 0f;
	private float maxDist = 150f;
	private bool clipThroughWalls = false;
	private float scrollSensitivity = 15f;

	// Freecam settings
	private float flySpeed = 10f;
	private float fastFlySpeed = 100f;
	private float freeLookSensitivity = 3f;

	float x = 0.0f;
	float y = 0.0f;

	bool init = false;
	bool wasLocked = false;
	bool looking = false;
	bool locked = false;
	bool wasFirstPerson = false;



	private void Awake()
	{
		instance = this;
		cam = GetComponent<Camera>();
	}
	void Start()
	{
		Mode = CameraMode.FollowPlayer;

		Vector3 angles = transform.eulerAngles;
		x = angles.y;
		y = angles.x;

		distanceLerp = distance;

		if (LaunchController.launchType == NetworkType.Server) Mode = CameraMode.Free;
	}

	void LateUpdate()
	{
		switch (Mode)
		{
			case CameraMode.FollowPlayer:
				UpdateFollow();
				break;
			case CameraMode.Free:
				UpdateFree();
				break;
			default:
				break;
		}
	}

	void UpdateFollow()
	{
		if (Input.GetKeyDown(KeyCode.LeftControl) && CanLock)
		{
			CtrlLocked = !CtrlLocked;
		}

		float scroll = EventSystem.current.IsPointerOverGameObject() ? 0 : Input.GetAxis("Mouse ScrollWheel");
		if (target)
		{
			locked = IsFirstPerson || CtrlLocked;
			bool changedView = locked != wasLocked;
			wasLocked = locked;

			bool changedFirstPerson = IsFirstPerson != wasFirstPerson;
			wasFirstPerson = IsFirstPerson;


			if (changedFirstPerson)
			{
				foreach (MeshRenderer r in disableOnFirstPerson)
					r.enabled = !IsFirstPerson;
			}


			if (!UIController.Paused && !EventSystem.current.IsPointerOverGameObject() && EventSystem.current.currentSelectedGameObject == null)
			{
				if (!init && ((!locked && Input.GetMouseButtonDown(1)) || (locked && changedView)))
				{
					Cursor.lockState = CursorLockMode.Locked;
					Cursor.visible = false;
					init = true;
				}
				else if (init && !locked && (Input.GetMouseButtonUp(1) || changedView))
				{
					Cursor.lockState = CursorLockMode.None;
					Cursor.visible = true;
					init = false;
				}

				//Only allow camera movement when the cursor is locked and game is focused
				bool cursorLocked = Cursor.lockState == CursorLockMode.Locked;
				int cameraKey = (Input.GetKey(KeyCode.RightArrow)) ? 1 : (Input.GetKey(KeyCode.LeftArrow)) ? -1 : 0;
				bool cameraButton = Input.GetMouseButton(1) || Input.GetMouseButton(2);
				bool cameraControlsActive = (cameraKey != 0 || cameraButton || Input.GetAxis("Camera X") != 0f || Input.GetAxis("Camera Y") != 0f);
				if (cameraControlsActive || (locked && cursorLocked && Application.isFocused))
				{
					x += ((Input.GetAxis("Mouse X") + Input.GetAxis("Camera X")) * sensitivityModifier * xSpeed * 0.02f + (cameraKey * 150f * Time.deltaTime));
					if (cameraButton || locked || Input.GetAxis("Camera Y") != 0f)
						y -= ((Input.GetAxis("Mouse Y") + Input.GetAxis("Camera Y")) * sensitivityModifier * ySpeed * 0.02f);
				}

				y = ClampAngle(y, yMinLimit, yMaxLimit);

				distanceMax -= scroll * scrollSensitivity;
			}

			Quaternion rotation = Quaternion.Euler(y, x, 0);

			if (distanceMax > maxDist) distanceMax = maxDist;
			if (distanceMax < minDist) distanceMax = minDist;
			if (!clipThroughWalls)
			{
				if (Physics.Linecast(target.position, transform.position - transform.forward, out RaycastHit hit, ~clipIgnoreLayers, QueryTriggerInteraction.Ignore))
				{
					if (hit.distance < distanceMax)
						distance = hit.distance + 0.1f;
					else
						distance = distanceMax;
				}
				else
				{
					distance = distanceMax;
				}
			}

			distanceLerp = Mathf.Lerp(distanceLerp, distance, Time.fixedDeltaTime * 15f);
			Vector3 negDistance = new Vector3(0.0f, 0.0f, -distanceLerp);
			Vector3 position = rotation * negDistance + target.position;

			transform.rotation = rotation;

			if (DoLerp)
			{
				transform.position = Vector3.Lerp(transform.position, position, LerpSpeed * Time.fixedDeltaTime);
			}
			else
			{
				transform.position = position;
			}
		}
	}

	void UpdateFree()
	{
		var fastMode = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
		var movementSpeed = fastMode ? fastFlySpeed : flySpeed;

		if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
		{
			transform.position = transform.position + (-transform.right * movementSpeed * Time.deltaTime);
		}

		if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
		{
			transform.position = transform.position + (transform.right * movementSpeed * Time.deltaTime);
		}

		if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
		{
			transform.position = transform.position + (transform.forward * movementSpeed * Time.deltaTime);
		}

		if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
		{
			transform.position = transform.position + (-transform.forward * movementSpeed * Time.deltaTime);
		}

		if (Input.GetKey(KeyCode.E))
		{
			transform.position = transform.position + (transform.up * movementSpeed * Time.deltaTime);
		}

		if (Input.GetKey(KeyCode.Q))
		{
			transform.position = transform.position + (-transform.up * movementSpeed * Time.deltaTime);
		}

		if (Input.GetKey(KeyCode.R) || Input.GetKey(KeyCode.PageUp))
		{
			transform.position = transform.position + (Vector3.up * movementSpeed * Time.deltaTime);
		}

		if (Input.GetKey(KeyCode.F) || Input.GetKey(KeyCode.PageDown))
		{
			transform.position = transform.position + (-Vector3.up * movementSpeed * Time.deltaTime);
		}

		if (looking)
		{
			float newRotationX = transform.localEulerAngles.y + Input.GetAxis("Mouse X") * freeLookSensitivity;
			float newRotationY = transform.localEulerAngles.x - Input.GetAxis("Mouse Y") * freeLookSensitivity;
			transform.localEulerAngles = new Vector3(newRotationY, newRotationX, 0f);
		}

		float axis = Input.GetAxis("Mouse ScrollWheel");
		if (axis != 0)
		{
			var zoomSensitivity = scrollSensitivity;
			transform.position = transform.position + transform.forward * axis * zoomSensitivity;
		}

		if (Input.GetKeyDown(KeyCode.Mouse1))
		{
			StartLooking();
		}
		else if (Input.GetKeyUp(KeyCode.Mouse1))
		{
			StopLooking();
		}
	}

	void StartLooking()
	{
		looking = true;
		Cursor.visible = false;
		Cursor.lockState = CursorLockMode.Locked;
	}

	void StopLooking()
	{
		looking = false;
		Cursor.visible = true;
		Cursor.lockState = CursorLockMode.None;
	}

	void OnDisable()
	{
		StopLooking();
	}

	public void LookAt(Instance target)
	{
		if (target == null) return;
		transform.LookAt(target.transform);
	}

	public void LookAt(Vector3 target)
	{
		transform.LookAt(target);
	}

	[MoonSharpHidden]
	public void SetTarget(Transform target)
	{
		this.target = target;
	}

	static float ClampAngle(float angle, float min, float max)
	{
		if (angle < -360F)
			angle += 360F;
		if (angle > 360F)
			angle -= 360F;
		return Mathf.Clamp(angle, min, max);
	}
}

public enum CameraMode
{
	FollowPlayer,
	Free,
	Scripted
}
