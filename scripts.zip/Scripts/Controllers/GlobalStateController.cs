using UnityEngine;
using UnityEngine.UI;

public class GlobalStateController : MonoBehaviour
{

	public static GlobalStateController instance;
	void Awake()
	{
		instance = this;
	}
	const float ScrollViewSpeed = 15f;

	public Shader partTransparencyShader;
	public Shader partNormalShader;

	void Start()
	{
		ScrollRect[] scrollViews = FindObjectsOfType<ScrollRect>();
		foreach (ScrollRect scrollView in scrollViews)
		{
			scrollView.scrollSensitivity = ScrollViewSpeed;
		}
	}
}
