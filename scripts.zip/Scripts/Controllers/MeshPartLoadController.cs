using System.Collections;
using System.Collections.Generic;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

public class MeshPartLoadController : MonoBehaviour
{
	public static MeshPartLoadController Instance;
	Queue<MeshPartLoadRequest> loadQueue = new Queue<MeshPartLoadRequest>();
	GameObject meshStorage;
	bool loading = false;

	void Awake()
	{
		Instance = this;
	}

	public void LoadMesh(MeshPartLoadRequest request)
	{
		loadQueue.Enqueue(request);

		if (!loading)
		{
			StartCoroutine(LoadMeshCoroutine());
		}
	}

	IEnumerator LoadMeshCoroutine()
	{
		loading = true;

		while (loadQueue.Count > 0)
		{
			MeshPartLoadRequest request = loadQueue.Dequeue();

			{
				GameObject loadedObject = null;

				if (meshStorage == null)
				{
					meshStorage = new GameObject("MeshStorage");
				}

				if (meshStorage.transform.Find(request.assetID.ToString()) != null)
				{
					loadedObject = Instantiate(meshStorage.transform.Find(request.assetID.ToString()).gameObject);
					foreach (Renderer renderer in loadedObject.GetComponentsInChildren<Renderer>())
					{
						renderer.enabled = true;
					}
				}
				else
				{
					string url = null;
					using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/assets/serve-mesh/" + request.assetID))
					{
						yield return uwr.SendWebRequest();
						if (uwr.result == UnityWebRequest.Result.Success)
						{
							JSONNode json = JSON.Parse(uwr.downloadHandler.text);

							if (json["success"].AsBool == true)
							{
								url = json["url"].Value;
							}
							else
							{
								Debug.LogError("Failed to get mesh: " + json["message"]);
							}
						}
					}

					if (!string.IsNullOrEmpty(url))
					{
						loadedObject = new GameObject(request.assetID.ToString());
						var gltf = new GLTFast.GltfImport();
						System.Threading.Tasks.Task<bool> t = gltf.Load(url);

						while (!t.IsCompleted)
						{
							yield return null;
						}

						if (t.Result)
						{
							System.Threading.Tasks.Task<bool> task = gltf.InstantiateMainSceneAsync(loadedObject.transform);
							while (!task.IsCompleted)
							{
								yield return null;
							}
						}


						if (meshStorage.transform.Find(request.assetID.ToString()) == null)
						{
							GameObject cacheObj = Instantiate(loadedObject);
							cacheObj.transform.SetParent(meshStorage.transform);
							cacheObj.name = request.assetID.ToString();

							foreach (Renderer renderer in cacheObj.GetComponentsInChildren<Renderer>())
							{
								renderer.enabled = false;
							}
						}
					}
				}

				if (request.meshPart != null)
				{
					foreach (Transform t in request.meshPart.transform)
					{
						if (t.GetComponent<Instance>() == null)
						{
							Destroy(t.gameObject);
						}
					}

					if (loadedObject != null)
					{
						Bounds bounds = new Bounds();
						Renderer renderer = loadedObject.GetComponentInChildren<Renderer>();

						if (renderer != null)
						{
							bounds = renderer.bounds;
						}

						Renderer[] renderers = loadedObject.GetComponentsInChildren<Renderer>();

						foreach (Renderer r in renderers)
						{
							bounds.Encapsulate(r.bounds);
						}

						foreach (Transform t in loadedObject.transform)
						{
							t.transform.position -= bounds.center;
						}

						if (request.meshPart != null)
						{
							loadedObject.transform.position = request.meshPart.transform.position;
							loadedObject.transform.rotation = request.meshPart.transform.rotation;
							loadedObject.transform.localScale = new Vector3(-1, 1, 1);

							foreach (Transform t in loadedObject.transform)
							{
								t.SetParent(request.meshPart.transform, false);
							}

							Destroy(loadedObject);

							// foreach (MeshCollider col in request.meshPart.GetComponentsInChildren<MeshCollider>())
							// {
							//     col.enabled = true;
							//     col.isTrigger = !request.meshPart.CanCollide;
							// }

							request.meshPart.GetComponent<BoxCollider>().isTrigger = !request.meshPart.CanCollide;

							request.meshPart.GetComponent<BoxCollider>().size = bounds.size;

							if (request.meshPart.isHidden)
							{
								request.meshPart.Hide();
							}
						}
					}
				}
				else
				{
					Destroy(loadedObject);
				}

			}
		}

		loading = false;
	}
}

public struct MeshPartLoadRequest
{
	public int assetID;
	public MeshPart meshPart;

	public MeshPartLoadRequest(int assetID, MeshPart meshPart)
	{
		this.assetID = assetID;
		this.meshPart = meshPart;
	}
}
