using System.Collections;
using System.Collections.Generic;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

public class AppearanceController : MonoBehaviour
{
	public static AppearanceController Instance { get; private set; }
	private Queue<Player> playerQueue = new Queue<Player>();
	bool isProcessing = false;

	private void Awake()
	{
		Instance = this;
	}

	private void Update()
	{
		if (isProcessing) return;
		if (playerQueue.Count == 0) return;
		isProcessing = true;
		Player player = playerQueue.Dequeue();
		StartCoroutine(ProcessPlayerAppearance(player));
	}

	IEnumerator ProcessPlayerAppearance(Player player)
	{
		while (!player.IsLoaded)
			yield return new WaitForEndOfFrame();

		using UnityWebRequest web = UnityWebRequest.Get("https://api.polytoria.com/v1/users/" + player.UserID + "/avatar");
		web.SetRequestHeader("Accept", "application/json");
		if (!LaunchController.isLocal)
			web.SetRequestHeader("Authorization", LaunchController.clientToken);

		yield return web.SendWebRequest();

		if (web.result == UnityWebRequest.Result.Success)
		{
			if (player == null) yield break;
			string response = web.downloadHandler.text;
			JSONNode data = JSON.Parse(response);


			ColorUtility.TryParseHtmlString("#" + data["colors"]["head"], out Color headColor);
			ColorUtility.TryParseHtmlString("#" + data["colors"]["torso"], out Color torsoColor);
			ColorUtility.TryParseHtmlString("#" + data["colors"]["leftArm"], out Color leftArmColor);
			ColorUtility.TryParseHtmlString("#" + data["colors"]["rightArm"], out Color rightArmColor);
			ColorUtility.TryParseHtmlString("#" + data["colors"]["leftLeg"], out Color leftLegColor);
			ColorUtility.TryParseHtmlString("#" + data["colors"]["rightLeg"], out Color rightLegColor);

			Transform headObj = player.transform.Find("Head");
			Transform torsoObj = player.transform.Find("Torso");
			Transform leftArmObj = player.transform.Find("Left Arm Pivot").Find("Left Arm");
			Transform rightArmObj = player.transform.Find("Right Arm Pivot").Find("Right Arm");
			Transform leftLegObj = player.transform.Find("Left Leg Pivot").Find("Left Leg");
			Transform rightLegObj = player.transform.Find("Right Leg Pivot").Find("Right Leg");
			Transform tshirtObj = player.transform.Find("Torso").Find("T-Shirt");

			headObj.GetComponent<Renderer>().materials[0].color = headColor;
			torsoObj.GetComponent<Renderer>().materials[0].color = torsoColor;
			leftArmObj.GetComponent<Renderer>().materials[0].color = leftArmColor;
			rightArmObj.GetComponent<Renderer>().materials[0].color = rightArmColor;
			leftLegObj.GetComponent<Renderer>().materials[0].color = leftLegColor;
			rightLegObj.GetComponent<Renderer>().materials[0].color = rightLegColor;

			foreach (JSONNode item in data["assets"])
			{
				string type = item["type"];
				string path = item["path"];

				if (type == "face")
				{
					ImageCacheController.Instance.GetImage(new ImageCacheKey { url = path, type = ImageType.Asset }, (key, entry) =>
					{
						Texture2D texture = entry.texture;
						texture.wrapMode = TextureWrapMode.Clamp;
						headObj.GetComponent<Renderer>().materials[1].mainTexture = texture;
					});
				}
				else if (type == "shirt")
				{
					ImageCacheController.Instance.GetImage(new ImageCacheKey { url = path, type = ImageType.Asset }, (key, entry) =>
					{
						Texture2D texture = entry.texture;
						leftArmObj.GetComponent<Renderer>().materials[1].mainTexture = texture;
						rightArmObj.GetComponent<Renderer>().materials[1].mainTexture = texture;
						torsoObj.GetComponent<Renderer>().materials[1].mainTexture = texture;
					});
				}
				else if (type == "pants")
				{
					ImageCacheController.Instance.GetImage(new ImageCacheKey { url = path, type = ImageType.Asset }, (key, entry) =>
					{
						Texture2D texture = entry.texture;
						leftLegObj.GetComponent<Renderer>().materials[1].mainTexture = texture;
						rightLegObj.GetComponent<Renderer>().materials[1].mainTexture = texture;
					});
				}
				else if (type == "hat")
				{
					GameObject hat = new GameObject("Hat");
					hat.transform.SetParent(headObj);
					hat.transform.localPosition = Vector3.up * -4.625f;
					hat.transform.localRotation = Quaternion.identity;
					hat.transform.localScale = new Vector3(-0.5f, 0.5f, 0.5f);
					hat.transform.localEulerAngles = Vector3.zero;

					// var gltf = hat.AddComponent<GLTFast.GltfAsset>();
					// gltf.Url = path;

					var gltf = new GLTFast.GltfImport();
					System.Threading.Tasks.Task<bool> t = gltf.Load(path);

					while (!t.IsCompleted)
					{
						yield return null;
					}

					if (t.Result)
					{
						System.Threading.Tasks.Task<bool> task = gltf.InstantiateMainSceneAsync(hat.transform);
						while (!task.IsCompleted)
						{
							yield return null;
						}
					}

					if (player.IsLocalPlayer)
					{
						foreach (MeshRenderer renderer in hat.GetComponentsInChildren<MeshRenderer>())
						{
							CameraController.instance.disableOnFirstPerson.Add(renderer);
						}
					}
				}
			}
		}
		else
		{
			Debug.LogError("Failed to load player data: " + web.error + " " + web.downloadHandler.text);
		}
		yield return new WaitForSeconds(0.5f);
		isProcessing = false;
	}

	public void AddPlayerToQueue(Player player)
	{
		playerQueue.Enqueue(player);
	}
}
