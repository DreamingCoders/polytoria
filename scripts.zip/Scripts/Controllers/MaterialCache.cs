using System.Collections.Generic;
using UnityEngine;

public class MaterialCache : MonoBehaviour
{
	struct MaterialCacheEntry
	{
		public Material Opaque;
		public Material Transparent;
	}
	public static MaterialCache Instance { get; private set; }

	private Dictionary<PartMaterial, MaterialCacheEntry> materials = new Dictionary<PartMaterial, MaterialCacheEntry>();

	private void Awake()
	{
		Instance = this;
	}

	public Material GetMaterial(PartMaterial material, bool isTransparent = false)
	{
		if (!materials.ContainsKey(material))
		{
			MaterialCacheEntry entry = new MaterialCacheEntry();
			Material opaque = Resources.Load<Material>("Materials/Parts/" + material.ToString());
			Material transparent = Instantiate(opaque);
			transparent.shader = Shader.Find("Custom/PartShaderTransparent");
			entry.Opaque = opaque;
			entry.Transparent = transparent;
			materials.Add(material, entry);
		}

		return isTransparent ? materials[material].Transparent : materials[material].Opaque;
	}
}
