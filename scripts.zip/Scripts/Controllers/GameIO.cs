using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;
using Mirror;
using UnityEngine;
using UnityEngine.Networking;

public class GameIO : MonoBehaviour
{
	Game game;
	public static GameIO singleton;
	List<Instance> spawnInstances = new List<Instance>();

	private void Awake()
	{
		singleton = this;
		game = GetComponent<Game>();
	}

	public void Load(int id, Action<bool> callback = null)
	{
		Debug.Log($"Loading place ID {id} from site");
		StartCoroutine(LoadFromSite(id, callback));
	}

	public void LoadFromFile(string path, Action<bool> callback = null)
	{
		Debug.Log($"Loading place file {path}");
		XmlDocument xml = new XmlDocument();
		xml.Load(path);
		LoadXml(xml);
		Resources.UnloadUnusedAssets();
		callback?.Invoke(true);
	}

	public Instance LoadModelFromFile(string path, Instance parent)
	{
		XmlDocument xml = new XmlDocument();
		xml.Load(path);
		return LoadXml(xml, parent);
	}

	public void LoadModelFromSite(int id, Instance parent, Action<Instance> callback = null)
	{
		StartCoroutine(ModelFromSite(id, parent, callback));
	}

	public void ClearDatamodel()
	{
		foreach (Instance i in game.GetChildren())
		{
			Destroy(i.gameObject);
		}
		StartCoroutine(PostClearDatamodel());
	}

	IEnumerator PostClearDatamodel()
	{
		yield return new WaitForEndOfFrame();
		PostMapLoad();
	}

	public void PostMapLoad()
	{
		if (game.FindChildByClass("Environment") == null)
		{
			Instance i = Instantiate(Resources.Load<Instance>("Datamodel/Environment"));
			i.transform.SetParent(transform);
			i.Name = i.ClassName;
			NetworkServer.Spawn(i.gameObject);
		}

		if (game.FindChildByClass("Lighting") == null)
		{
			Instance i = Instantiate(Resources.Load<Instance>("Datamodel/Lighting"));
			i.transform.SetParent(transform);
			i.Name = i.ClassName;
			NetworkServer.Spawn(i.gameObject);
		}

		if (game.FindChildByClass("Players") == null)
		{
			Instance i = Instantiate(Resources.Load<Instance>("Datamodel/Players"));
			i.transform.SetParent(transform);
			i.Name = i.ClassName;
			NetworkServer.Spawn(i.gameObject);
		}

		if (game.FindChildByClass("ScriptService") == null)
		{
			Instance i = Instantiate(Resources.Load<Instance>("Datamodel/ScriptService"));
			i.transform.SetParent(transform);
			i.Name = i.ClassName;
			NetworkServer.Spawn(i.gameObject);
		}
		if (game.FindChildByClass("Hidden") == null)
		{
			Instance i = Instantiate(Resources.Load<Instance>("Datamodel/Hidden"));
			i.transform.SetParent(transform);
			i.Name = i.ClassName;
			NetworkServer.Spawn(i.gameObject);
		}
		if (game.FindChildByClass("PlayerDefaults") == null)
		{
			Instance i = Instantiate(Resources.Load<Instance>("Datamodel/PlayerDefaults"));
			i.transform.SetParent(transform);
			i.Name = i.ClassName;
			NetworkServer.Spawn(i.gameObject);
		}
		if (game.FindChildByClass("PlayerGUI") == null)
		{
			Instance i = Instantiate(Resources.Load<Instance>("Datamodel/PlayerGUI"));
			i.transform.SetParent(transform);
			i.Name = i.ClassName;
			NetworkServer.Spawn(i.gameObject);
		}

		foreach (Instance instance in spawnInstances)
		{
			NetworkServer.Spawn(instance.gameObject);
		}

		spawnInstances.Clear();


		Player[] players = FindObjectsOfType<Player>();
		foreach (Player player in players)
		{
			player.Respawn();
		}

		if (!CreatorController.IsCreator)
		{
			game.FindChildOfType<ScriptService>().RunScripts();
		}

		Resources.UnloadUnusedAssets();

		game.InvokeLoaded();
	}

	public IEnumerator ModelFromSite(int id, Instance parent, Action<Instance> callback)
	{
		using UnityWebRequest uwr = UnityWebRequest.Get($"https://api.polytoria.com/v1/models/get-model?id={id}");
		yield return uwr.SendWebRequest();

		if (uwr.result == UnityWebRequest.Result.Success)
		{
			XmlDocument xml = new XmlDocument();
			xml.LoadXml(uwr.downloadHandler.text);
			Instance i = LoadXml(xml, parent);

			if (callback != null)
			{
				callback(i);
			}
		}
		else
		{
			Debug.LogError("Error while loading model from site: " + uwr.error);
		}
	}


	public IEnumerator LoadFromSite(int id, Action<bool> callback = null)
	{
		string token, tokenType;

		if (CreatorController.IsCreator)
		{
			token = CreatorController.singleton.CreatorToken ?? "unknown";
			tokenType = "creator";
		}
		else
		{
			token = LaunchController.serverToken ?? "unknown";
			tokenType = "server";
		}

		using UnityWebRequest uwr = UnityWebRequest.Get($"https://api.polytoria.com/v1/places/get-place?id={id}&tokenType={tokenType}");
		uwr.SetRequestHeader("Authorization", token);
		uwr.SetRequestHeader("Accept", "application/json, text/xml");
		yield return uwr.SendWebRequest();

		if (uwr.result == UnityWebRequest.Result.Success)
		{
			XmlDocument xml = new XmlDocument();
			xml.LoadXml(uwr.downloadHandler.text);
			LoadXml(xml);
			game.SetGameID(id);
			callback?.Invoke(true);
		}
		else
		{
			callback?.Invoke(false);
			Debug.LogError("Error while loading map from site: " + uwr.error + " " + uwr.downloadHandler.text);
		}

		Resources.UnloadUnusedAssets();
	}

	Instance LoadXml(XmlDocument xml, Instance parent = null)
	{
		if (parent == null) parent = game;
		Instance i = HandleXmlNodes(parent, xml.DocumentElement.ChildNodes);
		if (parent == game) PostMapLoad();
		return i;
	}

	Instance HandleXmlNodes(Instance parent, XmlNodeList nodes)
	{
		Instance spawned = null;
		string[] dataTypes = { "float", "integer", "int", "string", "boolean", "vector3", "color", "vector2" };

		foreach (XmlNode node in nodes)
		{
			if (node.Name == "Item")
			{
				Instance item = null;
				bool instantiate = true;

				switch (node.Attributes["class"].InnerText)
				{
					case "Environment":
						item = parent.FindChildByClass("Environment");

						if (item == null)
						{
							item = Instantiate(Resources.Load<Instance>("Datamodel/Environment"));
							item.Name = item.ClassName;
							item.transform.SetParent(parent.transform);
						}
						else
						{
							instantiate = false;
						}
						break;
					case "ScriptService":
						item = parent.FindChildByClass("ScriptService");

						if (item == null)
						{
							item = Instantiate(Resources.Load<Instance>("Datamodel/ScriptService"));
							item.Name = item.ClassName;
							item.transform.SetParent(parent.transform);
						}
						else
						{
							instantiate = false;
						}
						break;
					case "Players":
						item = parent.FindChildByClass("Players");

						if (item == null)
						{
							item = Instantiate(Resources.Load<Instance>("Datamodel/Players"));
							item.Name = item.ClassName;
							item.transform.SetParent(parent.transform);
						}
						else
						{
							instantiate = false;
						}
						break;
					case "Lighting":
						item = parent.FindChildByClass("Lighting");

						if (item == null)
						{
							item = Instantiate(Resources.Load<Instance>("Datamodel/Lighting"));
							item.Name = item.ClassName;
							item.transform.SetParent(parent.transform);
						}
						else
						{
							instantiate = false;
						}
						break;
					case "Part":
						item = Instantiate(Resources.Load<Part>("Datamodel/Part"));
						break;
					case "Script":
						item = Instantiate(Resources.Load<ScriptInstance>("Datamodel/ScriptInstance"));
						break;
					case "ScriptInstance":
						item = Instantiate(Resources.Load<ScriptInstance>("Datamodel/ScriptInstance"));
						break;
					case "LocalScript":
						item = Instantiate(Resources.Load<LocalScript>("Datamodel/LocalScript"));
						break;
					case "Text3D":
						item = Instantiate(Resources.Load<Text3D>("Datamodel/Text3D"));
						break;
					case "PointLight":
						item = Instantiate(Resources.Load<PointLight>("Datamodel/PointLight"));
						break;
					case "Spotlight":
						item = Instantiate(Resources.Load<Spotlight>("Datamodel/Spotlight"));
						break;
					case "RemoteEvent":
						item = Instantiate(Resources.Load<RemoteEvent>("Datamodel/RemoteEvent"));
						break;
					case "NPC":
						item = Instantiate(Resources.Load<NPC>("Datamodel/NPC"));
						break;
					case "Model":
						item = Instantiate(Resources.Load<Model>("Datamodel/Model"));
						break;
					case "Sound":
						item = Instantiate(Resources.Load<Sound>("Datamodel/Sound"));
						break;
					case "Truss":
						item = Instantiate(Resources.Load<Truss>("Datamodel/Truss"));
						break;
					case "Decal":
						item = Instantiate(Resources.Load<Decal>("Datamodel/Decal"));
						break;
					case "Tool":
						item = Instantiate(Resources.Load<Tool>("Datamodel/Tool"));
						break;
					case "Seat":
						item = Instantiate(Resources.Load<Seat>("Datamodel/Seat"));
						break;
					case "BoolValue":
						item = Instantiate(Resources.Load<BoolValue>("Datamodel/BoolValue"));
						break;
					case "ColorValue":
						item = Instantiate(Resources.Load<ColorValue>("Datamodel/ColorValue"));
						break;
					case "InstanceValue":
						item = Instantiate(Resources.Load<InstanceValue>("Datamodel/InstanceValue"));
						break;
					case "IntValue":
						item = Instantiate(Resources.Load<IntValue>("Datamodel/IntValue"));
						break;
					case "NumberValue":
						item = Instantiate(Resources.Load<NumberValue>("Datamodel/NumberValue"));
						break;
					case "StringValue":
						item = Instantiate(Resources.Load<StringValue>("Datamodel/StringValue"));
						break;
					case "Vector3Value":
						item = Instantiate(Resources.Load<Vector3Value>("Datamodel/Vector3Value"));
						break;
					case "MeshPart":
						item = Instantiate(Resources.Load<MeshPart>("Datamodel/MeshPart"));
						break;
					case "BodyPosition":
						item = Instantiate(Resources.Load<BodyPosition>("Datamodel/BodyPosition"));
						break;
					case "ImageSky":
						item = Instantiate(Resources.Load<ImageSky>("Datamodel/ImageSky"));
						break;
					case "NetworkEvent":
						item = Instantiate(Resources.Load<NetworkEvent>("Datamodel/NetworkEvent"));
						break;
					case "Hidden":
						item = parent.FindChildByClass("Hidden");

						if (item == null)
						{
							item = Instantiate(Resources.Load<Instance>("Datamodel/Hidden"));
							item.Name = item.ClassName;
							item.transform.SetParent(parent.transform);
						}
						else
						{
							instantiate = false;
						}
						break;
					case "PlayerDefaults":
						item = parent.FindChildByClass("PlayerDefaults");

						if (item == null)
						{
							item = Instantiate(Resources.Load<Instance>("Datamodel/PlayerDefaults"));
							item.Name = item.ClassName;
							item.transform.SetParent(parent.transform);
						}
						else
						{
							instantiate = false;
						}
						break;
					case "PlayerGUI":
						item = parent.FindChildByClass("PlayerGUI");

						if (item == null)
						{
							item = Instantiate(Resources.Load<Instance>("Datamodel/PlayerGUI"));
							item.Name = item.ClassName;
							item.transform.SetParent(parent.transform);
						}
						else
						{
							instantiate = false;
						}
						break;
					case "Backpack":
						item = parent.FindChildByClass("Backpack");

						if (item == null)
						{
							item = Instantiate(Resources.Load<Instance>("Datamodel/Backpack"));
							item.Name = item.ClassName;
							item.transform.SetParent(parent.transform);
						}
						else
						{
							instantiate = false;
						}
						break;
					case "GUI":
						item = Instantiate(Resources.Load<Polytoria.Datamodel.GUI>("Datamodel/GUI"));
						break;
					case "UIButton":
						item = Instantiate(Resources.Load<Polytoria.Datamodel.UIButton>("Datamodel/UIButton"));
						break;
					case "UIView":
						item = Instantiate(Resources.Load<Polytoria.Datamodel.UIView>("Datamodel/UIView"));
						break;
					case "UILabel":
						item = Instantiate(Resources.Load<Polytoria.Datamodel.UILabel>("Datamodel/UILabel"));
						break;
					case "UITextInput":
						item = Instantiate(Resources.Load<Polytoria.Datamodel.UITextInput>("Datamodel/UITextInput"));
						break;
					case "UIImage":
						item = Instantiate(Resources.Load<Polytoria.Datamodel.UIImage>("Datamodel/UIImage"));
						break;
					case "UIHorizontalLayout":
						item = Instantiate(Resources.Load<Polytoria.Datamodel.UIHorizontalLayout>("Datamodel/UIHorizontalLayout"));
						break;
					case "UIVerticalLayout":
						item = Instantiate(Resources.Load<Polytoria.Datamodel.UIVerticalLayout>("Datamodel/UIVerticalLayout"));
						break;
				}

				if (item != null)
				{
					spawned = item;
					item.Parent = parent;

					if (instantiate)
						spawnInstances.Add(item);

					HandleXmlNodes(item, node.ChildNodes);
				}
			}
			else if (node.Name == "Properties")
			{
				foreach (XmlNode property in node.ChildNodes)
				{
					if (dataTypes.Contains(property.Name))
					{
						string propertyName = property.Attributes["name"].InnerText;

						#region Compatibility fixes

						if (propertyName.Equals("name", StringComparison.OrdinalIgnoreCase))
						{
							parent.Name = XmlConvertString(property);
							continue;
						}

						if (propertyName == "scale")
							propertyName = "size";

						if (propertyName.Equals("shape", StringComparison.OrdinalIgnoreCase) && property.Name == "string" && parent is Part part)
						{
							part.Shape = XmlConvertString(property) switch
							{
								"cube" => PartShape.Brick,
								"brick" => PartShape.Brick,
								"ball" => PartShape.Ball,
								"sphere" => PartShape.Ball,
								"cylinder" => PartShape.Cylinder,
								"wedge" => PartShape.Wedge,
								_ => PartShape.Brick,
							};

							continue;
						}

						#endregion

						PropertyInfo prop = parent.GetType().GetProperty(propertyName, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance | BindingFlags.SetProperty);

						if (prop != null && prop.CanWrite && prop.GetCustomAttribute(typeof(Archivable)) != null)
						{
							Type t = prop.PropertyType;

							if (t == typeof(float) && property.Name == "float")
							{
								prop.SetValue(parent, XmlConvertFloat(property), null);
							}
							else if ((t == typeof(int) || t.IsEnum) && (property.Name == "int" || property.Name == "integer"))
							{
								prop.SetValue(parent, XmlConvertInt(property), null);
							}
							else if (t == typeof(string) && property.Name == "string")
							{
								prop.SetValue(parent, XmlConvertString(property), null);
							}
							else if (t == typeof(bool) && property.Name == "boolean")
							{
								prop.SetValue(parent, XmlConvertBool(property), null);
							}
							else if (t == typeof(Vector3) && property.Name == "vector3")
							{
								prop.SetValue(parent, XmlConvertVector3(property), null);
							}
							else if (t == typeof(Vector2) && property.Name == "vector2")
							{
								prop.SetValue(parent, XmlConvertVector2(property), null);
							}
							else if (t == typeof(Color) && property.Name == "color")
							{
								prop.SetValue(parent, XmlConvertColor(property), null);
							}
							else if (t == typeof(Color) && property.Name == "string")
							{
								prop.SetValue(parent, XmlConvertColor(property), null);
							}
							else if (t == typeof(string) && (property.Name == "int" || property.Name == "integer"))
							{
								prop.SetValue(parent, XmlConvertInt(property).ToString(), null);
							}
						}
					}
				}
			}
		}

		return spawned;
	}


	public Vector3 XmlConvertVector3(XmlNode property)
	{
		float.TryParse(property["X"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float x);
		float.TryParse(property["Y"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float y);
		float.TryParse(property["Z"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float z);

		if (float.IsNaN(x) || float.IsNaN(y) || float.IsNaN(z))
		{
			return Vector3.one;
		}

		return new Vector3(x, y, z);
	}

	public Vector2 XmlConvertVector2(XmlNode property)
	{
		float.TryParse(property["X"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float x);
		float.TryParse(property["Y"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float y);

		if (float.IsNaN(x) || float.IsNaN(y))
		{
			return Vector2.one;
		}

		return new Vector2(x, y);
	}


	public Color XmlConvertColor(XmlNode property)
	{
		if (property.Name == "string")
		{
			ColorUtility.TryParseHtmlString(property.InnerText, out Color clr);
			return clr;
		}
		else
		{
			float.TryParse(property["R"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float r);
			float.TryParse(property["G"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float g);
			float.TryParse(property["B"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float b);
			float.TryParse(property["A"].InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float a);
			return new Color(r, g, b, a);
		}
	}


	public bool XmlConvertBool(XmlNode property)
	{
		bool.TryParse(property.InnerText, out bool result);
		return result;
	}


	public string XmlConvertString(XmlNode property)
	{
		return property.InnerText;
	}


	public int XmlConvertInt(XmlNode property)
	{
		int.TryParse(property.InnerText, NumberStyles.Integer, new CultureInfo("en-US").NumberFormat, out int result);
		return result;
	}


	public float XmlConvertFloat(XmlNode property)
	{
		float.TryParse(property.InnerText, NumberStyles.Float, new CultureInfo("en-US").NumberFormat, out float result);
		return result;
	}


	public string SaveModelToString(Instance root)
	{
		XmlDocument doc = new XmlDocument();

		XmlDeclaration xmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
		XmlElement docroot = doc.DocumentElement;
		doc.InsertBefore(xmlDeclaration, docroot);
		XmlElement modelElement = doc.CreateElement(string.Empty, "model", string.Empty);
		doc.AppendChild(modelElement);

		SaveHandleChild(doc, root, modelElement);

		using var stringWriter = new StringWriter();
		using var xmlTextWriter = XmlWriter.Create(stringWriter);
		doc.WriteTo(xmlTextWriter);
		xmlTextWriter.Flush();
		return stringWriter.GetStringBuilder().ToString();
	}


	public void SaveModelToFile(Instance root, string path)
	{
		XmlDocument doc = new XmlDocument();

		XmlDeclaration xmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
		XmlElement docroot = doc.DocumentElement;
		doc.InsertBefore(xmlDeclaration, docroot);
		XmlElement modelElement = doc.CreateElement(string.Empty, "model", string.Empty);
		doc.AppendChild(modelElement);

		SaveHandleChild(doc, root, modelElement);

		doc.Save(path);
	}


	public string SaveToString()
	{
		XmlDocument doc = new XmlDocument();

		XmlDeclaration xmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
		XmlElement root = doc.DocumentElement;
		doc.InsertBefore(xmlDeclaration, root);
		XmlElement gameElement = doc.CreateElement(string.Empty, "game", string.Empty);
		doc.AppendChild(gameElement);

		foreach (Instance c in game.GetChildren())
		{
			SaveHandleChild(doc, c, gameElement);
		}

		using var stringWriter = new StringWriter();
		using var xmlTextWriter = XmlWriter.Create(stringWriter);
		doc.WriteTo(xmlTextWriter);
		xmlTextWriter.Flush();
		return stringWriter.GetStringBuilder().ToString();
	}


	public void SaveToFile(string path)
	{
		XmlDocument doc = new XmlDocument();

		XmlDeclaration xmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
		XmlElement root = doc.DocumentElement;
		doc.InsertBefore(xmlDeclaration, root);
		XmlElement gameElement = doc.CreateElement(string.Empty, "game", string.Empty);

		gameElement.SetAttribute("version", Application.version);

		doc.AppendChild(gameElement);

		foreach (Instance c in game.GetChildren())
		{
			SaveHandleChild(doc, c, gameElement);
		}

		doc.Save(path);
	}


	void SaveHandleChild(XmlDocument doc, Instance i, XmlElement parent)
	{
		XmlElement instance = doc.CreateElement("Item");
		XmlElement properties = doc.CreateElement("Properties");
		XmlAttribute classAttr = doc.CreateAttribute("class");

		classAttr.Value = i.ClassName;

		IEnumerable<PropertyInfo> props = i.GetType().GetProperties().Where(prop => prop.IsDefined(typeof(Archivable), false));

		foreach (PropertyInfo property in props)
		{
			if (property.PropertyType == typeof(string))
			{
				SaveString(doc, properties, property.Name, (string) property.GetValue(i));
			}
			else if (property.PropertyType == typeof(float))
			{
				SaveFloat(doc, properties, property.Name, (float) property.GetValue(i));
			}
			else if (property.PropertyType == typeof(int) || property.PropertyType.IsEnum)
			{
				SaveInt(doc, properties, property.Name, (int) property.GetValue(i));
			}
			else if (property.PropertyType == typeof(bool))
			{
				SaveBool(doc, properties, property.Name, (bool) property.GetValue(i));
			}
			else if (property.PropertyType == typeof(Vector3))
			{
				SaveVector3(doc, properties, property.Name, (Vector3) property.GetValue(i));
			}
			else if (property.PropertyType == typeof(Vector2))
			{
				SaveVector2(doc, properties, property.Name, (Vector2) property.GetValue(i));
			}
			else if (property.PropertyType == typeof(Color))
			{
				SaveColor(doc, properties, property.Name, (Color) property.GetValue(i));
			}
		}

		instance.Attributes.Append(classAttr);
		instance.AppendChild(properties);
		parent.AppendChild(instance);

		foreach (Instance child in i.GetChildren())
		{
			SaveHandleChild(doc, child, instance);
		}
	}


	void SaveString(XmlDocument doc, XmlElement properties, string name, string value)
	{
		XmlElement nameProperty = doc.CreateElement("string");
		XmlAttribute namePropertyN = doc.CreateAttribute("name");
		namePropertyN.Value = name;
		nameProperty.Attributes.Append(namePropertyN);
		nameProperty.InnerText = value;
		properties.AppendChild(nameProperty);
	}


	void SaveFloat(XmlDocument doc, XmlElement properties, string name, float value)
	{
		XmlElement nameProperty = doc.CreateElement("float");
		XmlAttribute namePropertyN = doc.CreateAttribute("name");
		namePropertyN.Value = name;
		nameProperty.Attributes.Append(namePropertyN);
		nameProperty.InnerText = value.ToString("F4", CultureInfo.InvariantCulture);
		properties.AppendChild(nameProperty);
	}


	void SaveInt(XmlDocument doc, XmlElement properties, string name, int value)
	{
		XmlElement nameProperty = doc.CreateElement("int");
		XmlAttribute namePropertyN = doc.CreateAttribute("name");
		namePropertyN.Value = name;
		nameProperty.Attributes.Append(namePropertyN);
		nameProperty.InnerText = value.ToString();
		properties.AppendChild(nameProperty);
	}


	void SaveBool(XmlDocument doc, XmlElement properties, string name, bool value)
	{
		XmlElement nameProperty = doc.CreateElement("boolean");
		XmlAttribute namePropertyN = doc.CreateAttribute("name");
		namePropertyN.Value = name;
		nameProperty.Attributes.Append(namePropertyN);
		nameProperty.InnerText = value ? "true" : "false";
		properties.AppendChild(nameProperty);
	}


	void SaveVector3(XmlDocument doc, XmlElement properties, string name, Vector3 value)
	{
		XmlElement nameProperty = doc.CreateElement("vector3");
		XmlAttribute namePropertyN = doc.CreateAttribute("name");
		namePropertyN.Value = name;
		nameProperty.Attributes.Append(namePropertyN);

		XmlElement xProperty = doc.CreateElement("X");
		xProperty.InnerText = value.x.ToString("F4", CultureInfo.InvariantCulture);

		XmlElement yProperty = doc.CreateElement("Y");
		yProperty.InnerText = value.y.ToString("F4", CultureInfo.InvariantCulture);

		XmlElement zProperty = doc.CreateElement("Z");
		zProperty.InnerText = value.z.ToString("F4", CultureInfo.InvariantCulture);

		nameProperty.AppendChild(xProperty);
		nameProperty.AppendChild(yProperty);
		nameProperty.AppendChild(zProperty);

		properties.AppendChild(nameProperty);
	}

	void SaveVector2(XmlDocument doc, XmlElement properties, string name, Vector2 value)
	{
		XmlElement nameProperty = doc.CreateElement("vector2");
		XmlAttribute namePropertyN = doc.CreateAttribute("name");
		namePropertyN.Value = name;
		nameProperty.Attributes.Append(namePropertyN);

		XmlElement xProperty = doc.CreateElement("X");
		xProperty.InnerText = value.x.ToString("F4", CultureInfo.InvariantCulture);

		XmlElement yProperty = doc.CreateElement("Y");
		yProperty.InnerText = value.y.ToString("F4", CultureInfo.InvariantCulture);

		nameProperty.AppendChild(xProperty);
		nameProperty.AppendChild(yProperty);

		properties.AppendChild(nameProperty);
	}


	void SaveColor(XmlDocument doc, XmlElement properties, string name, Color value)
	{
		XmlElement nameProperty = doc.CreateElement("color");
		XmlAttribute namePropertyN = doc.CreateAttribute("name");
		namePropertyN.Value = name;
		nameProperty.Attributes.Append(namePropertyN);

		XmlElement xProperty = doc.CreateElement("R");
		xProperty.InnerText = value.r.ToString("F4", CultureInfo.InvariantCulture);

		XmlElement yProperty = doc.CreateElement("G");
		yProperty.InnerText = value.g.ToString("F4", CultureInfo.InvariantCulture);

		XmlElement zProperty = doc.CreateElement("B");
		zProperty.InnerText = value.b.ToString("F4", CultureInfo.InvariantCulture);

		XmlElement aProperty = doc.CreateElement("A");
		aProperty.InnerText = value.a.ToString("F4", CultureInfo.InvariantCulture);

		nameProperty.AppendChild(xProperty);
		nameProperty.AppendChild(yProperty);
		nameProperty.AppendChild(zProperty);
		nameProperty.AppendChild(aProperty);

		properties.AppendChild(nameProperty);
	}
}
