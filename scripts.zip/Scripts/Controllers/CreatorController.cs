using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Battlehub.UIControls;
using HSVPicker;
using Mirror;
using Polytoria.Datamodel;
using RLD;
using SimpleFileBrowser;
using SimpleJSON;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Networking;
using UnityEngine.UI;

public class CreatorController : NetworkBehaviour
{
	[SerializeField] string testCreatorToken;

	public static CreatorController singleton;
	public static bool IsCreator = false;
	public static string externalScriptFolder;

	private static System.Random random = new System.Random();

	public VirtualizingTreeView TreeView;
	public CreatorPropertyGrid PropertyGrid;
	public Image[] activateButtons;
	public ColorPicker colorPicker;
	public Image[] colorDisplay;
	public Canvas canvas;
	public RectTransform landing;
	public RectTransform materialSelector;
	public RectTransform publishModal;
	public RectTransform contextMenu;
	public ColorPicker propertyColorPicker;
	public TMP_Text statusBar;
	public GameObject confirmExit;

	float moveSnap = 1.0f;
	float rotateSnap = 45.0f;
	bool moveSnapEnabled = true, rotateSnapEnabled = true;

	public float autoSaveInterval = 600f;

	private PaintType paintType;
	private Color defaultButtonClr;

	Dictionary<string, BaseScript> externalScriptFiles = new Dictionary<string, BaseScript>();
	FileSystemWatcher watcher;

	Color paintColor = new Color(163 / 255f, 162 / 255f, 165 / 255f);
	PartMaterial paintMaterial = PartMaterial.SmoothPlastic;

	int userID, gameID;

	private static string saveLocation = "";
	private Vector3 mouseDownPosition;

	//static bool allowQuit = false;

	public string CreatorToken { get; private set; }

	List<Instance> selectionQueue = new List<Instance>();

	private static bool WantsToQuit()
	{
		return true;

		/*
         * gone until mirror fixes da bug
         * if (allowQuit)
        {
            return true;
        } else
        {

            singleton.PromptExit();
            return false;
        }*/
	}

	public void PromptExit()
	{
		confirmExit.SetActive(true);
	}

	public void DoExit()
	{
		//allowQuit = true;
		Application.Quit();
	}

	private void Awake()
	{
		IsCreator = true;
		singleton = this;
		RLDApp.Get.Initialized += OnAppInitialized;
		RTObjectSelection.Get.Changed += OnObjectSelectionChanged;
		Application.wantsToQuit += WantsToQuit;
		landing.gameObject.SetActive(true);
	}

	private void OnPostDragEnd(Gizmo gizmo, int handleId)
	{
		PropertyGrid.Clear();
		if (RTObjectSelection.Get.SelectedObjects.Count > 0)
		{
			List<Instance> instances = new List<Instance>();
			foreach (GameObject go in RTObjectSelection.Get.SelectedObjects)
			{
				Instance instance = go.GetComponent<Instance>();
				if (instance != null)
				{
					instances.Add(instance);
				}
			}
			PropertyGrid.SetPropertyGridItems(instances);
		}
	}

	private void PropertyGrid_ValueChanged(object obj, PropertyInfo propertyInfo)
	{
		if (obj is Instance instance)
		{
			if (propertyInfo.Name == "Name")
			{
				VirtualizingItemContainer virtualizingItemContainer = TreeView.GetItemContainer(instance);

				if (virtualizingItemContainer is VirtualizingTreeViewItem item)
				{
					item.transform.Find("Background").Find("ItemLayout").Find("Label").GetComponent<TMP_Text>().text = instance.Name;
				}
			}
			else if (instance is DynamicInstance di)
			{
				if (propertyInfo.Name == "Position" || propertyInfo.Name == "Size" || propertyInfo.Name == "Rotation" || propertyInfo.Name == "LocalPosition" || propertyInfo.Name == "LocalRotation")
				{
					RTObjectSelectionGizmos.Get.WorkGizmo.Transform.Position3D = di.Position;
					RTObjectSelectionGizmos.Get.WorkGizmo.Transform.Rotation3D = di.transform.rotation;
					RTObjectSelectionGizmos.Get.GetGizmoById(ObjectSelectionGizmoId.BoxScaleGizmo).BoxGizmo.FitBoxToTargetHierarchy();
				}
			}
		}
	}

	private void GameLoaded()
	{
		RTObjectSelection.Get.ClearSelection(false);
		ObjectSelectEntireHierarchy.Get.SetActive(false);
		TreeView.Items = new List<Instance>
		{
			Game.singleton
		};
	}

	private void OnAppInitialized()
	{
		// ObjectSelectEntireHierarchy.Get.IgnoreObjectGroups = true;

		RTObjectSelectionGizmos.Get.GetGizmoById(ObjectSelectionGizmoId.MoveGizmo).PostDragEnd += OnPostDragEnd;
		RTObjectSelectionGizmos.Get.GetGizmoById(ObjectSelectionGizmoId.RotationGizmo).PostDragEnd += OnPostDragEnd;
		RTObjectSelectionGizmos.Get.GetGizmoById(ObjectSelectionGizmoId.BoxScaleGizmo).PostDragEnd += OnPostDragEnd;
	}

	void Start()
	{
		var args = GetCommandLineArgs();
		if (!Application.isEditor)
		{
			if (args.TryGetValue("-token", out string token))
			{
				CreatorToken = token;
			}
		}
		else
		{
			CreatorToken = testCreatorToken;
		}

		QualitySettings.vSyncCount = 1;
		Application.targetFrameRate = 144;

		StartCoroutine(CheckToken());

		DirectoryInfo tempDir = new DirectoryInfo(Application.temporaryCachePath);

		foreach (FileInfo file in tempDir.GetFiles())
		{
			file.Delete();
		}

		foreach (DirectoryInfo directory in tempDir.GetDirectories())
		{
			directory.Delete(true);
		}

		Game.singleton.Loaded += GameLoaded;

		StartCoroutine(LoadStarterPlaces());
		RectTransform cont = materialSelector.gameObject.GetComponentInChildren<ScrollRect>().content;
		RectTransform materialOption = Resources.Load<RectTransform>("UI/MaterialEntry");

		foreach (string mat in System.Enum.GetNames(typeof(PartMaterial)))
		{
			RectTransform entry = Instantiate(materialOption, cont);
			entry.gameObject.GetComponentInChildren<TMP_Text>().text = mat;
			if (mat != PartMaterial.SmoothPlastic.ToString() && mat != PartMaterial.Neon.ToString())
			{
				Texture2D tex = Resources.Load<Texture2D>("Textures/Materials/" + mat + "/albedo");
				Sprite sprite = Sprite.Create(tex, new Rect(0f, 0f, tex.width, tex.height), Vector3.one / 2);
				entry.Find("Image").GetComponent<Image>().sprite = sprite;
			}

			entry.GetComponent<Button>().onClick.AddListener(delegate { paintMaterial = (PartMaterial) System.Enum.Parse(typeof(PartMaterial), mat); materialSelector.gameObject.SetActive(false); });
		}

		materialSelector.gameObject.SetActive(false);

		TreeView.ItemDataBinding += OnItemDataBinding;
		TreeView.SelectionChanged += OnTreeSelectionChanged;
		TreeView.ItemExpanding += OnItemExpanding;
		TreeView.ItemBeginDrag += OnItemBeginDrag;
		TreeView.ItemDrop += OnItemDrop;
		TreeView.ItemBeginDrop += OnItemBeginDrop;
		TreeView.ItemEndDrag += OnItemEndDrag;
		TreeView.ItemDoubleClick += OnItemDoubleClick;

		externalScriptFolder = Application.temporaryCachePath + "/scripteditor";

		Directory.CreateDirectory(externalScriptFolder);

		watcher = new FileSystemWatcher(externalScriptFolder);
		watcher.Filter = "*.lua";
		watcher.NotifyFilter = NotifyFilters.Attributes
						 | NotifyFilters.CreationTime
						 | NotifyFilters.DirectoryName
						 | NotifyFilters.FileName
						 | NotifyFilters.LastAccess
						 | NotifyFilters.LastWrite
						 | NotifyFilters.Security
						 | NotifyFilters.Size;

		watcher.EnableRaisingEvents = true;
		watcher.IncludeSubdirectories = true;
		watcher.Changed += ScriptEditedExternally;

		canvas.transform.Find("BottomBar").GetComponentInChildren<TMP_Text>().text = "Polytoria Creator v" + Application.version;

		GameIO.singleton.PostMapLoad();

		DiscordController.Instance.UpdateActivity(new Discord.Activity
		{
			Details = "In Creator",
			State = "Working on Untitled",
			Assets =
			{
				LargeImage = "creating",
				LargeText = "Polytoria Creator"
			},
			Timestamps =
			{
				Start = DateTimeOffset.Now.ToUnixTimeSeconds()
			}
		});

		StartCoroutine(AutoSaveLoop());
	}

	public void DeleteSelection()
	{
		List<GameObject> objectsToDelete = new List<GameObject>();
		List<Instance> instancesToDelete = new List<Instance>();

		foreach (Instance instance in TreeView.SelectedItems)
		{
			if (instance.CanReparent)
			{
				instancesToDelete.Add(instance);
				objectsToDelete.Add(instance.gameObject);
			}
		}

		if (objectsToDelete.Count == 0) return;

		ObjectSelectionSnapshot objectSelectionSnapshot = new ObjectSelectionSnapshot();
		ObjectSelectionSnapshot preDeleteSnapshot = objectSelectionSnapshot;
		preDeleteSnapshot.Snapshot();

		RTObjectSelection.Get.ClearSelection(true);

		var deleteSelectedAction = new DeleteSelectedObjectsAction(objectsToDelete, preDeleteSnapshot);
		deleteSelectedAction.Execute();

		foreach (Instance i in instancesToDelete)
		{
			TreeView.RemoveChild(i.Parent, i);
		}
	}

	public void DuplicateSelection()
	{
		List<Instance> selection = new List<Instance>();
		foreach (Instance instance in TreeView.SelectedItems)
		{
			Instance i = instance.Clone();
			if (i != null)
			{
				selection.Add(i);
			}
		}


		if (selection.Count > 0)
		{
			TreeView.Collapse(selection[0].Parent);
			TreeView.Expand(selection[0].Parent);
		}
	}

	public void SetStatusBarMessage(string message)
	{
		statusBar.text = message;
	}

	IEnumerator CheckToken()
	{
		if (CreatorToken == null)
		{
			RelaunchCreator();
			yield break;
		}

		SetStatusBarMessage("Authenticating...");

		using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/creator/token-data"))
		{
			uwr.SetRequestHeader("Authorization", CreatorToken);
			yield return uwr.SendWebRequest();

			if (uwr.result == UnityWebRequest.Result.Success)
			{
				JSONNode data = JSON.Parse(uwr.downloadHandler.text);
				if (data["success"] == null)
				{
					if (data["token"] != CreatorToken)
					{
						RelaunchCreator();
						yield break;
					}

					userID = data["userID"];
					gameID = data["placeID"] ?? 0;

					SetStatusBarMessage("");

					if (gameID != 0)
					{
						SetStatusBarMessage("Loading place with ID " + gameID + "...");

						GameIO.singleton.Load(gameID, (result) =>
						{
							SetStatusBarMessage("");
						});

						landing.gameObject.SetActive(false);
					}
				}
				else
				{
					RelaunchCreator();
					yield break;
				}
			}
			else
			{
				Debug.LogError(uwr.error);
				Debug.LogError(uwr.downloadHandler.text);
			}
		}
	}

	private Dictionary<string, string> GetCommandLineArgs()
	{
		Dictionary<string, string> argDictionary = new Dictionary<string, string>();

		var args = System.Environment.GetCommandLineArgs();

		for (int i = 0; i < args.Length; ++i)
		{
			var arg = args[i].ToLower();
			if (arg.StartsWith("-"))
			{
				var value = i < args.Length - 1 ? args[i + 1].ToLower() : null;
				value = (value?.StartsWith("-") ?? false) ? null : value;
				if (!argDictionary.ContainsKey(arg))
					argDictionary.Add(arg, value);
			}
		}
		return argDictionary;
	}

	void RelaunchCreator()
	{
		Debug.Log("Relaunching creator...");
		Application.OpenURL("https://polytoria.com/create");
		Application.Quit();
	}

	public void GroupSelection()
	{
		List<Instance> selection = GetSelectedInstances();
		if (selection.Count == 0) return;

		int lowestLevel = int.MaxValue;
		Bounds b = new Bounds();
		foreach (Instance instance in selection)
		{
			if (instance is DynamicInstance di)
			{
				if (di.GetComponent<Renderer>())
				{

					if (b.extents == Vector3.zero)
					{
						b = instance.GetComponent<Renderer>().bounds;
					}
					else
					{
						b.Encapsulate(instance.GetComponent<Renderer>().bounds);
					}
				}
				else if (di.GetComponent<Collider>())
				{
					if (b.extents == Vector3.zero)
					{
						b = instance.GetComponent<Collider>().bounds;
					}
					else
					{
						b.Encapsulate(instance.GetComponent<Collider>().bounds);
					}
				}
			}


			int level = instance.DescendantLevel;
			if (level < lowestLevel)
				lowestLevel = level;
		}

		if (lowestLevel == 1) return; // children of game

		List<Instance> topLevel = selection.Where(i => i.DescendantLevel == lowestLevel).ToList();

		Model m = (Model) Instance.New("Model", topLevel[0].Parent);
		m.Position = b.center;
		foreach (Instance i in topLevel)
		{
			i.Parent = m;
		}

		RTObjectSelection.Get.ClearSelection(false);
		RTObjectSelection.Get.AppendObjects(new List<GameObject>() { m.gameObject }, false);

		TreeView.Collapse(m.Parent);
		TreeView.Expand(m.Parent);
	}

	public void UngroupSelection()
	{
		List<Instance> selection = GetSelectedInstances();
		if (selection.Count == 0) return;

		int lowestLevel = int.MaxValue;

		foreach (Instance instance in selection)
		{
			int level = instance.DescendantLevel;
			if (level < lowestLevel)
				lowestLevel = level;
		}

		List<Instance> topLevel = selection.Where(i => i.DescendantLevel == lowestLevel).ToList();
		List<GameObject> ungrouped = new List<GameObject>();

		Instance temp = null;

		foreach (Model m in topLevel)
		{
			foreach (Instance i in m.GetChildren())
			{
				temp = i;
				i.Parent = m.Parent;
				ungrouped.Add(i.gameObject);
			}
			TreeView.RemoveChild(m.Parent, m);
			m.Destroy();
		}

		if (temp != null)
		{
			TreeView.Collapse(temp.Parent);
			TreeView.Expand(temp.Parent);
		}

		RTObjectSelection.Get.ClearSelection(false);
		RTObjectSelection.Get.AppendObjects(ungrouped, false);
	}

	public void ExportModel()
	{
		List<Instance> selection = GetSelectedInstances();

		foreach (Instance item in selection)
		{
			if (item is Model m)
			{
				FileBrowser.SetFilters(true, new FileBrowser.Filter("Polytoria Model Files", ".ptmd"));
				FileBrowser.SetDefaultFilter(".ptmd");
				StartCoroutine(ShowExportModelDialog());
				return;
			}
		}
	}

	IEnumerator ShowExportModelDialog()
	{
		yield return FileBrowser.WaitForSaveDialog(FileBrowser.PickMode.Files, false, null, null, "Export Model", "Export");

		if (FileBrowser.Success)
		{
			DoExportModel(FileBrowser.Result[0]);
		}
	}

	static void DoExportModel(string path) // dont remove otherwise it bugs il2cpp
	{
		if (path != "" && path != null)
		{
			Model m = (Model) GetSelectedInstances().Where(i => i is Model).First();
			GameIO.singleton.SaveModelToFile(m, path);
		}
	}

	public void ExportGLTF()
	{
		FileBrowser.SetFilters(true, new FileBrowser.Filter("GLTF Files", ".glb"));
		FileBrowser.SetDefaultFilter(".glb");
		StartCoroutine(ShowExportGLTFDialog());
	}

	IEnumerator ShowExportGLTFDialog()
	{
		yield return FileBrowser.WaitForSaveDialog(FileBrowser.PickMode.Files, false, null, null, "Export GLTF", "Export");

		if (FileBrowser.Success)
		{
			DoExportGLTF(FileBrowser.Result[0]);
		}
	}

	static void DoExportGLTF(string path)
	{
		if (path != "" && path != null)
		{
			List<Transform> transforms = new List<Transform>();
			Environment e = Game.singleton.FindChildOfType<Environment>();

			// foreach (Instance i in e.gameObject.GetComponentsInChildren<Instance>())
			// {
			//     if (i is Part) {
			//         transforms.Add(i.transform);
			//     }
			// }

			// var exporter = new GLTFSceneExporter(new[] { e.transform }, null);
			// string dir = Path.GetDirectoryName(path);
			// string filename = Path.GetFileNameWithoutExtension(path);
			// exporter.SaveGLB(dir, filename);
		}
	}

	public void PublishModel()
	{
		StartCoroutine(DoPublishModel());
	}

	IEnumerator DoPublishModel()
	{
		List<Instance> selection = GetSelectedInstances();

		foreach (Instance item in selection)
		{
			if (item is Model m)
			{
				string export = GameIO.singleton.SaveModelToString(m);

				WWWForm form = new WWWForm();
				form.AddField("id", 0);
				form.AddField("data", export);
				form.AddField("token", CreatorToken);

				using (UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/creator/upload-model", form))
				{
					uwr.SetRequestHeader("Authorization", CreatorToken);
					yield return uwr.SendWebRequest();

					if (uwr.result == UnityWebRequest.Result.Success)
					{
						var data = JSON.Parse(uwr.downloadHandler.text);

						if (data["success"] == true)
						{
							Application.OpenURL(data["link"]);
						}
						else
						{
							Debug.LogError(data["error"]);
						}
					}
				}

				yield break;
			}
		}

		yield return 0;
	}

	public void ImportModel()
	{
		FileBrowser.SetFilters(true, new FileBrowser.Filter("Polytoria Model Files", ".ptmd"));
		FileBrowser.SetDefaultFilter(".ptmd");
		StartCoroutine(ShowImportModelDialog());
	}

	IEnumerator ShowImportModelDialog()
	{
		yield return FileBrowser.WaitForLoadDialog(FileBrowser.PickMode.Files, false, null, null, "Import Model", "Import");

		if (FileBrowser.Success)
		{
			DoImportModel(FileBrowser.Result);
		}
	}

	static void DoImportModel(string[] paths)
	{
		if (paths.Length > 0)
		{
			Instance par = Game.singleton.FindChildOfType<Environment>();
			Instance spawned = GameIO.singleton.LoadModelFromFile(paths[0], par);

			if (spawned is Model model)
			{
				RTObjectSelection.Get.ClearSelection(false);
				RTObjectSelection.Get.SetSelectedObjects(new List<GameObject> { model.gameObject }, false);
				RTFocusCamera.Get.Focus(RTObjectSelection.Get.GetWorldAABB());
			}

			singleton.TreeView.Collapse(par);
			singleton.TreeView.Expand(par);
		}
	}

	public void ToolboxModelAdded(Model i)
	{
		RTObjectSelection.Get.ClearSelection(false);
		RTObjectSelection.Get.SetSelectedObjects(new List<GameObject> { i.gameObject }, false);
		RTFocusCamera.Get.Focus(RTObjectSelection.Get.GetWorldAABB());

		TreeView.Collapse(i.Parent);
		TreeView.Expand(i.Parent);
	}

	public static List<Instance> GetSelectedInstances()
	{
		List<Instance> selection = new List<Instance>();

		foreach (GameObject item in RTObjectSelection.Get.SelectedObjects)
		{
			Instance i = item.GetComponent<Instance>();
			if (i != null) selection.Add(i);
		}

		return selection;
	}

	IEnumerator LoadStarterPlaces()
	{
		List<ThumbnailImageTarget> images = new List<ThumbnailImageTarget>();

		RectTransform template = Resources.Load<RectTransform>("UI/TemplateEntry");

		using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/creator/get-starter-places"))
		{
			Transform container = landing.Find("Container").Find("Templates").GetComponentInChildren<ScrollRect>().content;
			yield return uwr.SendWebRequest();

			if (uwr.result == UnityWebRequest.Result.Success)
			{
				JSONNode result = JSON.Parse(uwr.downloadHandler.text);

				foreach (JSONNode node in result)
				{
					RectTransform entry = Instantiate(template, container);
					entry.GetComponentInChildren<TMP_Text>().text = node["Name"];
					entry.GetComponent<Button>().onClick.AddListener(delegate { GameIO.singleton.Load(node["ID"]); CloseStartScreen(); });

					images.Add(new ThumbnailImageTarget { Url = node["iconUrl"], Target = entry.Find("Thumbnail").Find("Image").GetComponent<Image>() });
				}
			}
		}

		using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/creator/get-places"))
		{
			Transform container = landing.Find("Container").Find("YourPlaces").GetComponentInChildren<ScrollRect>().content;
			uwr.SetRequestHeader("Authorization", CreatorToken);
			yield return uwr.SendWebRequest();

			if (uwr.result == UnityWebRequest.Result.Success)
			{
				JSONNode result = JSON.Parse(uwr.downloadHandler.text);

				foreach (JSONNode node in result)
				{
					RectTransform entry = Instantiate(template, container);
					entry.GetComponentInChildren<TMP_Text>().text = node["name"];
					entry.GetComponent<Button>().onClick.AddListener(delegate { GameIO.singleton.Load(node["id"]); CloseStartScreen(); });

					images.Add(new ThumbnailImageTarget { Url = node["iconUrl"], Target = entry.Find("Thumbnail").Find("Image").GetComponent<Image>() });
				}
			}
		}

		StartCoroutine(LoadThumbnailImages(images));
	}

	public void ClearWorkspace()
	{
		RTObjectSelection.Get.ClearSelection(false);
		GameIO.singleton.ClearDatamodel();
		TreeView.Collapse(Game.singleton);
		TreeView.Expand(Game.singleton);
		Camera.main.transform.position = new Vector3(0, 1, -10);
		Camera.main.transform.rotation = Quaternion.identity;
		string oldSave = saveLocation;
		saveLocation = "";

		if (saveLocation != oldSave)
		{
			Discord.Activity ac = DiscordController.Instance.Activity;
			ac.State = "Working on Untitled";
			ac.Timestamps.Start = DateTimeOffset.Now.ToUnixTimeSeconds();
			DiscordController.Instance.UpdateActivity(ac);
		}
	}

	public void CloseStartScreen()
	{
		landing.gameObject.SetActive(false);
	}

	private void ScriptEditedExternally(object sender, FileSystemEventArgs e)
	{
		Debug.Log(Path.GetFullPath(e.FullPath));
		externalScriptFiles.TryGetValue(Path.GetFullPath(e.FullPath), out BaseScript script);

		if (script != null)
		{
			script.source = File.ReadAllText(e.FullPath);
		}
	}

	void EditScript(BaseScript script)
	{
		if (true /* Replace with setting later */)
		{
			string path = null;

			foreach (KeyValuePair<string, BaseScript> kvp in externalScriptFiles)
			{
				if (kvp.Value == script)
				{
					path = kvp.Key;
					break;
				}
			}

			if (path == null)
			{
				string scriptFolder = externalScriptFolder;

				if (!Directory.Exists(scriptFolder))
				{
					Directory.CreateDirectory(scriptFolder);
				}

				path = Path.GetFullPath(Path.Combine(scriptFolder, script.Name + "_" + RandomString(16) + ".lua"));

				StreamWriter writer = File.CreateText(path);
				writer.Write(script.source);
				writer.Close();

				externalScriptFiles.Add(path, script);
			}

			if (!File.Exists(path))
			{
				StreamWriter writer = File.CreateText(path);
				writer.Write(script.source);
				writer.Close();
			}

			Application.OpenURL("file://" + path);
		}
		else
		{
			// Open in built in editor
		}
	}

	public void PublishGame()
	{
		StartCoroutine(DoPublish());
	}

	IEnumerator DoPublish()
	{
		using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/creator/get-places"))
		{
			uwr.SetRequestHeader("Authorization", CreatorToken);
			yield return uwr.SendWebRequest();

			if (uwr.result == UnityWebRequest.Result.Success)
			{
				publishModal.gameObject.SetActive(true);

				var games = JSON.Parse(uwr.downloadHandler.text);
				Button btnPrefab = Resources.Load<Button>("UI/PublishEntry");
				RectTransform btnContainer = publishModal.GetComponentInChildren<ScrollRect>().content;

				foreach (Transform child in btnContainer)
				{
					Destroy(child.gameObject);
				}

				bool first = true;

				List<ThumbnailImageTarget> thumbnails = new List<ThumbnailImageTarget>();

				foreach (JSONNode game in games)
				{
					Button butt = Instantiate(btnPrefab);
					butt.transform.SetParent(btnContainer, false);
					butt.GetComponentInChildren<TMP_Text>().text = game["name"];
					thumbnails.Add(new ThumbnailImageTarget { Url = game["iconUrl"], Target = butt.transform.Find("Mask").Find("Icon").GetComponent<Image>() });
					butt.onClick.AddListener(() => { SetPublishModalSelectedGame(game); });

					if (first)
					{
						SetPublishModalSelectedGame(game);
						first = false;
					}
				}

				StartCoroutine(LoadThumbnailImages(thumbnails));
			}
			else
			{
				Debug.LogError(uwr.error);
			}
		}
	}

	IEnumerator LoadThumbnailImages(List<ThumbnailImageTarget> thumbnails)
	{
		foreach (ThumbnailImageTarget thumbnail in thumbnails)
		{
			Image target = thumbnail.Target;
			using (UnityWebRequest twr = UnityWebRequestTexture.GetTexture(thumbnail.Url))
			{
				yield return twr.SendWebRequest();

				if (twr.result != UnityWebRequest.Result.Success)
				{
					Texture2D texture = Resources.Load<Texture2D>("Textures/game_unavail");
					Sprite s = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one / 2);
					target.sprite = s;
				}
				else
				{
					Texture2D wwwTexture = DownloadHandlerTexture.GetContent(twr);
					Texture2D texture = new Texture2D(wwwTexture.width, wwwTexture.height, wwwTexture.format, true);
					texture.LoadImage(twr.downloadHandler.data);
					texture.Apply(true);
					Sprite s = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one / 2);
					target.sprite = s;
				}
			}
		}
	}

	public void SetPublishModalSelectedGame(JSONNode game)
	{
		Transform contents = publishModal.Find("RightPanel");
		StartCoroutine(LoadThumbnailImage(game["iconUrl"], contents.Find("Mask").Find("Icon").GetComponent<Image>()));
		contents.Find("Title").GetComponent<TMP_Text>().text = game["name"];

		string createdTxt = DateTime.Parse(game["createdAt"]).ToString("D");
		string updatedTxt = "-";

		if (game["updatedAt"] != null && game["updatedAt"] != "")
		{
			updatedTxt = DateTime.Parse(game["updatedAt"]).ToString("D");
		}


		contents.Find("Details").GetComponent<TMP_Text>().text = createdTxt + "\n" + updatedTxt;

		contents.Find("PublishBtn").GetComponent<Button>().onClick.RemoveAllListeners();
		contents.Find("PublishBtn").GetComponent<Button>().onClick.AddListener(() => { PublishGameOverwrite(game["id"]); });

	}

	IEnumerator LoadThumbnailImage(string src, Image target)
	{
		using (UnityWebRequest twr = UnityWebRequestTexture.GetTexture(src))
		{
			yield return twr.SendWebRequest();

			if (twr.result != UnityWebRequest.Result.Success)
			{
				Texture2D texture = Resources.Load<Texture2D>("Textures/game_unavail");
				Sprite s = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one / 2);
				target.sprite = s;
			}
			else
			{
				Texture2D wwwTexture = DownloadHandlerTexture.GetContent(twr);
				Texture2D texture = new Texture2D(wwwTexture.width, wwwTexture.height, wwwTexture.format, true);
				texture.LoadImage(twr.downloadHandler.data);
				texture.Apply(true);
				Sprite s = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one / 2);
				target.sprite = s;
			}
		}
	}

	public void TestGame()
	{
		const string chars = "abcdefghijklmnopqrstuvwxyz0123456789";
		string name = new string(Enumerable.Repeat(chars, 10).Select(s => s[(new System.Random()).Next(s.Length)]).ToArray());
		string fileName = Application.temporaryCachePath + "/" + name + ".ptm";
		GameIO.singleton.SaveToFile(fileName);
		Application.OpenURL("polytoria://test/" + CreatorToken + "/" + fileName);
	}

	public void PublishGameOverwrite(int id)
	{
		StartCoroutine(PublishLevelToID(id));
	}

	IEnumerator PublishLevelToID(int id)
	{
		publishModal.gameObject.SetActive(false);
		yield return new WaitForEndOfFrame();

		string export = GameIO.singleton.SaveToString();

		WWWForm form = new WWWForm();
		form.AddField("id", id);
		form.AddField("token", CreatorToken);
		form.AddBinaryData("file", System.Text.Encoding.UTF8.GetBytes(export), "level.ptm", "text/xml");

		using (UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/creator/upload-place", form))
		{
			uwr.SetRequestHeader("Authorization", CreatorToken);
			yield return uwr.SendWebRequest();

			if (uwr.result == UnityWebRequest.Result.Success)
			{
				var data = JSON.Parse(uwr.downloadHandler.text);

				if (data["errors"] == null)
				{
					Application.OpenURL(data["link"]);
					SetStatusBarMessage("Place published successfully");
				}
				else
				{
					Debug.LogError(data["errors"]);
					SetStatusBarMessage("Failed to publish place!");
				}
			}
			else
			{
				Debug.LogError(uwr.downloadHandler.text);
				SetStatusBarMessage("Failed to publish place!");
			}
		}

		yield return 0;
	}


	public static string RandomString(int length)
	{
		const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		return new string(Enumerable.Repeat(chars, length)
		  .Select(s => s[random.Next(s.Length)]).ToArray());
	}

	public void FileOpen()
	{
		FileBrowser.SetFilters(true, new FileBrowser.Filter("Polytoria Game Files", ".poly"), new FileBrowser.Filter("Polytoria Legacy Game Files", ".ptm", ".spm"));
		FileBrowser.SetDefaultFilter(".poly");
		StartCoroutine(ShowOpenDialog());
		// var extensions = new[] {
		//     new ExtensionFilter("Polytoria Game Files", "poly"),
		//     new ExtensionFilter("Polytoria Legacy Game Files", "ptm", "spm"),
		// };

		// if (Application.platform == RuntimePlatform.OSXPlayer)
		// {
		//     StandaloneFileBrowser.OpenFilePanelAsync("Open File", "", extensions, false, DoLoadMap);
		// }
		// else
		// {
		//     DoLoadMap(StandaloneFileBrowser.OpenFilePanel("Open File", "", extensions, false));
		// }
	}

	IEnumerator ShowOpenDialog()
	{
		yield return FileBrowser.WaitForLoadDialog(FileBrowser.PickMode.Files, false, null, null, "Open", "Open");

		if (FileBrowser.Success)
		{
			DoLoadMap(FileBrowser.Result);
		}
	}

	IEnumerator AutoSaveLoop()
	{
		while (true)
		{
			yield return new WaitForSeconds(autoSaveInterval);
			SetStatusBarMessage("Autosaving...");
			yield return new WaitForEndOfFrame();

			string path = System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments) + "\\Polytoria Creator\\Autosave\\";
			if (!Directory.Exists(path))
			{
				Directory.CreateDirectory(path);
			}
			DateTime time = DateTime.Now;
			string formattedTime = time.ToString("yyyy-MM-dd-hhmmss");

			string placeName = "";

			if (saveLocation != "" && saveLocation != null)
			{
				placeName = Path.GetFileNameWithoutExtension(saveLocation) + "-";
			}

			string filename = "AutoSave-" + placeName + formattedTime + ".poly";
			filename = Path.Combine(path, filename);
			GameIO.singleton.SaveToFile(filename);

			SetStatusBarMessage($"Autosaved to \"{filename}\"");
		}

	}

	static void DoLoadMap(string[] paths)
	{
		if (paths.Length > 0)
		{
			string oldSave = saveLocation;
			saveLocation = paths[0];
			singleton.TreeView.Collapse(Game.singleton);
			RTObjectSelection.Get.ClearSelection(false);
			singleton.StartCoroutine(singleton.LoadMapFromFile(paths[0]));

			if (saveLocation != oldSave)
			{
				Discord.Activity ac = DiscordController.Instance.Activity;
				ac.State = "Working on " + Path.GetFileNameWithoutExtension(saveLocation);
				ac.Timestamps.Start = DateTimeOffset.Now.ToUnixTimeSeconds();
				DiscordController.Instance.UpdateActivity(ac);
			}
		}
	}

	IEnumerator LoadMapFromFile(string path)
	{
		SetStatusBarMessage("Loading place file...");
		RTObjectSelection.Get.ClearSelection(false);
		GameIO.singleton.ClearDatamodel();
		yield return new WaitForEndOfFrame();
		GameIO.singleton.LoadFromFile(path, (r) =>
		{
			SetStatusBarMessage("");
		});
		yield return new WaitForEndOfFrame();
		TreeView.Collapse(Game.singleton);
		TreeView.Expand(Game.singleton);
	}

	public void FileSave(bool saveAs)
	{
		if (string.IsNullOrEmpty(saveLocation) || saveAs)
		{
			// var extensions = new[] {
			//     new ExtensionFilter("Polytoria Game Files", "poly"),
			//     new ExtensionFilter("Polytoria Legacy Game Files", "ptm", "spm"),
			//     new ExtensionFilter("All Files", "*"),
			// };

			// if (Application.platform == RuntimePlatform.OSXPlayer)
			// {
			//     StandaloneFileBrowser.SaveFilePanelAsync("Save File", "", "", extensions, DoSaveFile);
			// }
			// else
			// {
			//     DoSaveFile(StandaloneFileBrowser.SaveFilePanel("Save File", "", "", extensions));
			// }

			FileBrowser.SetFilters(true, new FileBrowser.Filter("Polytoria Game Files", ".poly"), new FileBrowser.Filter("Polytoria Legacy Game Files", ".ptm", ".spm"));
			FileBrowser.SetDefaultFilter(".poly");
			StartCoroutine(ShowSaveDialog());
		}
		else
		{
			SetStatusBarMessage("Saving...");
			GameIO.singleton.SaveToFile(saveLocation);
			SetStatusBarMessage("Saved as \"" + Path.GetFileName(saveLocation) + "\" at " + DateTime.Now.ToString("HH:mm:ss"));
		}
	}

	IEnumerator ShowSaveDialog()
	{
		yield return FileBrowser.WaitForSaveDialog(FileBrowser.PickMode.Files, false, null, null, "Save", "Save");

		if (FileBrowser.Success)
		{
			DoSaveFile(FileBrowser.Result[0]);
		}
	}

	static void DoSaveFile(string path)
	{
		string oldSave = saveLocation;
		saveLocation = path;

		if (path != "" && path != null)
		{
			CreatorController.singleton.SetStatusBarMessage("Saving...");
			GameIO.singleton.SaveToFile(path);
			CreatorController.singleton.SetStatusBarMessage("Saved as \"" + Path.GetFileName(path) + "\" at " + DateTime.Now.ToString("HH:mm:ss"));

			if (saveLocation != oldSave)
			{
				Discord.Activity ac = DiscordController.Instance.Activity;
				ac.State = "Working on " + Path.GetFileNameWithoutExtension(saveLocation);
				ac.Timestamps.Start = DateTimeOffset.Now.ToUnixTimeSeconds();
				DiscordController.Instance.UpdateActivity(ac);
			}
		}
	}

	public void SetMoveSnapEnabled(bool enabled)
	{
		float snap = moveSnap;
		moveSnapEnabled = enabled;
		if (!enabled)
		{
			snap = 0f;
		}

		RTObjectSelectionGizmos.Get.BoxScaleGizmoSettings3D.SetXSnapStep(snap);
		RTObjectSelectionGizmos.Get.BoxScaleGizmoSettings3D.SetYSnapStep(snap);
		RTObjectSelectionGizmos.Get.BoxScaleGizmoSettings3D.SetZSnapStep(snap);

		RTObjectSelectionGizmos.Get.MoveGizmoSettings3D.SetXSnapStep(snap);
		RTObjectSelectionGizmos.Get.MoveGizmoSettings3D.SetYSnapStep(snap);
		RTObjectSelectionGizmos.Get.MoveGizmoSettings3D.SetZSnapStep(snap);
	}

	public void SetMoveSnapSize(string snapString)
	{
		moveSnap = float.Parse(snapString);
		SetMoveSnapEnabled(moveSnapEnabled);
	}

	public void SetRotateSnapEnabled(bool enabled)
	{
		float snap = rotateSnap;
		rotateSnapEnabled = enabled;
		if (!enabled)
		{
			snap = 0f;
		}

		RTObjectSelectionGizmos.Get.RotationGizmoSettings3D.SetAxisSnapStep(0, snap);
		RTObjectSelectionGizmos.Get.RotationGizmoSettings3D.SetAxisSnapStep(1, snap);
		RTObjectSelectionGizmos.Get.RotationGizmoSettings3D.SetAxisSnapStep(2, snap);
	}

	public void SetRotateSnapSize(string snapString)
	{
		rotateSnap = float.Parse(snapString);
		SetRotateSnapEnabled(rotateSnapEnabled);
	}

	public void SetActiveGizmo(string name)
	{
		int gizmoID = 0;

		foreach (Image button in activateButtons)
		{
			button.color = defaultButtonClr;
		}

		switch (name)
		{
			case "Select":
				gizmoID = ObjectSelectionGizmoId.None;
				RTObjectSelection.Get.SetEnabled(true);
				paintType = PaintType.None;
				activateButtons[0].color = new Color(0.1f, 0.1f, 0.1f);
				break;
			case "Move":
				gizmoID = ObjectSelectionGizmoId.MoveGizmo;
				RTObjectSelection.Get.SetEnabled(true);
				paintType = PaintType.None;
				activateButtons[1].color = new Color(0.1f, 0.1f, 0.1f);
				break;
			case "Rotate":
				gizmoID = ObjectSelectionGizmoId.RotationGizmo;
				RTObjectSelection.Get.SetEnabled(true);
				paintType = PaintType.None;
				activateButtons[2].color = new Color(0.1f, 0.1f, 0.1f);
				break;
			case "Scale":
				gizmoID = ObjectSelectionGizmoId.BoxScaleGizmo;
				RTObjectSelection.Get.SetEnabled(true);
				paintType = PaintType.None;
				activateButtons[3].color = new Color(0.1f, 0.1f, 0.1f);
				break;
			case "Paint":
				paintType = PaintType.Color;
				activateButtons[4].color = new Color(0.1f, 0.1f, 0.1f);
				RTObjectSelection.Get.SetEnabled(false);
				break;
			case "PaintMaterial":
				paintType = PaintType.Material;
				activateButtons[5].color = new Color(0.1f, 0.1f, 0.1f);
				RTObjectSelection.Get.SetEnabled(false);
				break;
		}

		RTObjectSelectionGizmos.Get.SetWorkGizmo(gizmoID);
	}

	private void Update()
	{
		if (selectionQueue.Count != 0)
		{
			List<GameObject> newSelection = selectionQueue.Select(i => i.gameObject).ToList();
			RTObjectSelection.Get.ClearSelection(true);
			RTObjectSelection.Get.AppendObjects(newSelection, true);
			selectionQueue.Clear();
		}
		if (Input.GetMouseButtonDown(1))
		{
			mouseDownPosition = Input.mousePosition;
		}

		if (Input.GetMouseButtonUp(1))
		{
			if (mouseDownPosition == Input.mousePosition)
			{
				ShowContextMenu();
			}
		}

		if (Input.GetKeyDown(KeyCode.Delete) && (EventSystem.current.currentSelectedGameObject == null || EventSystem.current.currentSelectedGameObject.GetComponent<InputField>() == null || EventSystem.current.currentSelectedGameObject.GetComponent<TMP_InputField>() == null))
		{
			DeleteSelection();
		}


		if (paintType == PaintType.None)
		{
			RTObjectSelection.Get.SelectedObjects.ForEach(i =>
			{
				Part p = i.GetComponent<Part>();
				if (p) p.RecalculateUVs();
			});
		}
		else
		{
			if (Input.GetMouseButtonDown(0) && !colorPicker.gameObject.activeInHierarchy && !IsPointerOverUIObject())
			{
				Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

				if (Physics.Raycast(ray, out RaycastHit hit))
				{
					Transform objectHit = hit.transform;
					Part p = objectHit.gameObject.GetComponent<Part>();

					if (p != null)
					{
						if (paintType == PaintType.Color)
						{
							p.Color = paintColor;
						}
						else
						{
							p.Material = paintMaterial;
						}

					}
				}
			}
		}

	}

	void ShowContextMenu()
	{
		contextMenu.gameObject.SetActive(true);
		contextMenu.position = new Vector2(Input.mousePosition.x, Input.mousePosition.y) + new Vector2(contextMenu.sizeDelta.x / 2, -contextMenu.sizeDelta.y / 2);
	}

	public void SetPaintColor(Color c)
	{
		paintColor = c;
		for (int i = 0; i < colorDisplay.Length; i++)
		{
			colorDisplay[i].color = c;
		}
	}

	public void ToggleColorPicker()
	{
		if (!colorPicker.gameObject.activeInHierarchy)
			colorPicker.gameObject.SetActive(true);
	}

	public void ToggleMaterialPicker()
	{
		if (!materialSelector.gameObject.activeInHierarchy)
			materialSelector.gameObject.SetActive(true);
	}


	#region TreeView
	private void OnItemDataBinding(object sender, VirtualizingTreeViewItemDataBindingArgs e)
	{
		if (e.Item is Instance dataItem)
		{
			TMP_Text text = e.ItemPresenter.GetComponentInChildren<TMP_Text>(true);
			text.text = dataItem.Name;
			Image icon = e.ItemPresenter.GetComponentsInChildren<Image>()[4];
			Sprite iconRes;

			iconRes = Resources.Load<Sprite>("TreeViewIcons/" + dataItem.ClassName);
			if (iconRes == null)
				iconRes = Resources.Load<Sprite>("TreeViewIcons/object");

			icon.sprite = iconRes;

			e.HasChildren = dataItem.GetChildren().Length > 0;
		}
	}

	private void OnItemBeginDrop(object sender, ItemDropCancelArgs e) { }
	private void OnItemBeginDrag(object sender, ItemArgs e) { }
	private void OnItemEndDrag(object sender, ItemArgs e) { }

	private void OnItemExpanding(object sender, VirtualizingItemExpandingArgs e)
	{
		Instance dataItem = (Instance) e.Item;
		if (dataItem.GetChildren().Length > 0)
		{
			e.Children = dataItem.GetChildren();
		}
	}

	private void OnTreeSelectionChanged(object sender, SelectionChangedArgs e)
	{
		PropertyGrid.Clear();
		if (TreeView.SelectedItemsCount > 0)
		{
			List<Instance> selectedItems = new List<Instance>();
			foreach (Instance i in TreeView.SelectedItems)
			{
				selectedItems.Add(i);
			}
			PropertyGrid.SetPropertyGridItems(selectedItems);
		}

		List<GameObject> selectedObjects = new List<GameObject>();

		foreach (Instance i in e.NewItems)
		{
			if (i is DynamicInstance)
			{
				selectedObjects.Add(i.gameObject);
			}
		}

		RTObjectSelection.Get.SetSelectedObjects(selectedObjects, false);
		selectionQueue.Clear();
	}

	private List<Instance> ChildrenOf(Instance parent)
	{
		if (parent == null)
		{
			return Game.singleton.GetChildrenAsList();
		}
		return parent.GetChildrenAsList();
	}

	private void OnItemDrop(object sender, ItemDropArgs e)
	{
		if (e.DropTarget == null)
		{
			return;
		}

		Transform dropT = ((Instance) e.DropTarget).transform;
		Instance dropTarget = dropT.GetComponent<Instance>();

		if (dropTarget == null)
		{
			return;
		}

		if (e.Action == ItemDropAction.SetLastChild)
		{
			for (int i = 0; i < e.DragItems.Length; ++i)
			{
				Instance ins = (Instance) e.DragItems[i];
				if (!ins.CanReparent) continue;
				Transform dragT = ins.transform;
				ins.Parent = dropTarget;
				dragT.SetAsLastSibling();
			}
		}

		else if (e.Action == ItemDropAction.SetNextSibling)
		{
			for (int i = e.DragItems.Length - 1; i >= 0; --i)
			{
				Instance ins = (Instance) e.DragItems[i];
				if (!ins.CanReparent) continue;
				ins.Parent = dropTarget;
				Transform dragT = ((Instance) e.DragItems[i]).transform;
				int dropTIndex = dropT.GetSiblingIndex();
				if (dragT.parent != dropT.parent)
				{
					ins.Parent = dropTarget;
					dragT.SetSiblingIndex(dropTIndex + 1);
				}
				else
				{
					int dragTIndex = dragT.GetSiblingIndex();
					if (dropTIndex < dragTIndex)
					{
						dragT.SetSiblingIndex(dropTIndex + 1);
					}
					else
					{
						dragT.SetSiblingIndex(dropTIndex);
					}
				}
			}
		}

		else if (e.Action == ItemDropAction.SetPrevSibling)
		{
			for (int i = 0; i < e.DragItems.Length; ++i)
			{
				Instance ins = (Instance) e.DragItems[i];
				if (!ins.CanReparent) continue;
				ins.Parent = dropTarget;
				Transform dragT = ((Instance) e.DragItems[i]).transform;
				if (dragT.parent != dropT.parent)
				{
					ins.Parent = dropTarget;
				}

				int dropTIndex = dropT.GetSiblingIndex();
				int dragTIndex = dragT.GetSiblingIndex();
				if (dropTIndex > dragTIndex)
				{
					dragT.SetSiblingIndex(dropTIndex - 1);
				}
				else
				{
					dragT.SetSiblingIndex(dropTIndex);
				}
			}
		}

		for (int j = 0; j < e.DragItems.Length; j++)
		{
			Instance i = (Instance) e.DragItems[j];

			if (!i.CanReparent)
			{
				TreeView.Items = new List<Instance>() { Game.singleton };
				TreeView.SelectedItems = null;
				return;
			}
		}
	}

	private void OnItemDoubleClick(object sender, ItemArgs e)
	{
		for (int i = 0; i < e.Items.Length; ++i)
		{
			Instance dataItem = (Instance) e.Items[i];

			if (dataItem is BaseScript script)
			{
				EditScript(script);
			}
		}
	}
	#endregion

	private void OnObjectSelectionChanged(ObjectSelectionChangedEventArgs args)
	{
		List<GameObject> selectedObjects = RTObjectSelection.Get.SelectedObjects;
		List<Instance> selectedInstances = new List<Instance>();

		foreach (GameObject gameObject in selectedObjects)
		{
			Instance instance = gameObject.GetComponent<Instance>();

			if (instance != null)
			{
				Instance parentModel = instance.Parent;
				Model topMostModel = null;

				while (parentModel != null)
				{
					if (parentModel is Model)
					{
						topMostModel = parentModel as Model;
					}

					parentModel = parentModel.Parent;
				}

				if (topMostModel != null)
				{
					selectedInstances.Add(topMostModel);
				}
				else
				{
					selectedInstances.Add(instance);
				}
			}
		}

		TreeView.SelectedItems = selectedInstances;
		// RTObjectSelection.Get.ClearSelection(false);
		// RTObjectSelection.Get.AppendObjects(selectedInstances.Select(x => x.gameObject).ToList(), false);

		selectionQueue = new List<Instance>(selectedInstances);
	}

	public void CloseContextMenu()
	{
		contextMenu.gameObject.SetActive(false);
	}

	public void AddPart(string shape)
	{
		PartShape partShape = PartShape.Brick;

		switch (shape)
		{
			case "brick":
				partShape = PartShape.Brick;
				break;
			case "ball":
				partShape = PartShape.Ball;
				break;
			case "cylinder":
				partShape = PartShape.Cylinder;
				break;
			case "wedge":
				partShape = PartShape.Wedge;
				break;
		}

		AddPart(partShape);
	}

	public void SelectChildren()
	{
		if (TreeView.SelectedItemsCount == 0) return;
		IEnumerable selection = TreeView.SelectedItems;
		List<Instance> newSelection = new List<Instance>();

		foreach (Instance instance in selection)
		{
			foreach (Instance child in instance.GetChildren())
			{
				newSelection.Add(child);
			}

			TreeView.Expand(instance);
		}

		TreeView.SelectedItems = newSelection;
	}

	public void Undo()
	{
		RTUndoRedo.Get.Undo();
	}

	public void Redo()
	{
		RTUndoRedo.Get.Redo();
	}

	public void AddTruss()
	{
		AddInstance("Truss");
	}

	public Instance AddInstance(string className, Instance parent = null, bool ignorePlacement = false)
	{
		Instance instance = Instance.New(className, parent);

		TreeView.AddChild(instance.Parent, instance);

		if (ignorePlacement)
		{
			TreeView.SelectedItems = new List<Instance> { instance };
		}

		TreeView.Expand(Game.singleton);
		TreeView.Expand(instance.Parent);

		if (!ignorePlacement && instance is DynamicInstance)
		{
			DynamicInstance d = (DynamicInstance) instance;
			Ray ray = Camera.main.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));
			Vector3 pos = Camera.main.transform.position + (Camera.main.transform.forward * 20f);

			if (Physics.Raycast(ray, out RaycastHit hit, 20f))
			{
				pos = hit.point + new Vector3(0, d.Size.y / 2, 0);
			}
			else
			{
				Plane hPlane = new Plane(Vector3.up, Vector3.zero);

				if (hPlane.Raycast(ray, out float dist))
				{
					pos = ray.GetPoint(dist) + new Vector3(0, d.Size.y / 2, 0);
				}
			}

			d.Position = new Vector3(Mathf.Round(pos.x), Mathf.Max(0f + (d.Size.y / 2), pos.y), Mathf.Round(pos.z));

			RTObjectSelection.Get.ClearSelection(false);
			RTObjectSelection.Get.SetSelectedObjects(new List<GameObject> { d.gameObject }, false);
			RTFocusCamera.Get.Focus(RTObjectSelection.Get.GetWorldAABB());
		}

		NetworkServer.Spawn(instance.gameObject);

		return instance;
	}

	public void AddPart(PartShape shape = PartShape.Brick, string name = "Brick")
	{
		Part part = (Part) Instance.New("Part");
		part.Name = name;

		NetworkServer.Spawn(part.gameObject);

		if (shape == PartShape.Brick)
			part.Size = new Vector3(4, 1, 2);
		else
			part.Size = new Vector3(2, 2, 2);

		part.Color = new Color(163 / 255f, 162 / 255f, 165 / 255f);
		part.Shape = shape;

		Ray ray = Camera.main.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));
		Vector3 pos = Camera.main.transform.position + (Camera.main.transform.forward * 20f);

		if (Physics.Raycast(ray, out RaycastHit hit, 20f))
		{
			pos = hit.point + new Vector3(0, part.Size.y / 2, 0);
		}
		else
		{
			Plane hPlane = new Plane(Vector3.up, Vector3.zero);

			if (hPlane.Raycast(ray, out float dist))
			{
				pos = ray.GetPoint(dist) + new Vector3(0, part.Size.y / 2, 0);
			}
		}

		part.Position = new Vector3(Mathf.Round(pos.x), Mathf.Max(0f + (part.Size.y / 2), pos.y), Mathf.Round(pos.z));

		TreeView.AddChild(part.Parent, part);

		TreeView.Expand(Game.singleton);
		TreeView.Expand(part.Parent);

		RTObjectSelection.Get.ClearSelection(false);
		RTObjectSelection.Get.SetSelectedObjects(new List<GameObject> { part.gameObject }, false);
		RTFocusCamera.Get.Focus(RTObjectSelection.Get.GetWorldAABB());
	}

	public void AddScript()
	{
		Instance parent = Game.singleton.FindChildByClass("ScriptService");
		AddInstance("ScriptInstance", parent, true);
	}
	public void AddSound()
	{
		AddInstance("Sound");
	}

	public void AddLocalScript()
	{
		Instance parent = Game.singleton.FindChildByClass("ScriptService");
		AddInstance("LocalScript", parent, true);
	}

	public void AddRemoteEvent()
	{
		Instance parent = Game.singleton.FindChildByClass("ScriptService");
		AddInstance("RemoteEvent", parent, true);
	}
	public Instance Add(string instanceClass, string parentClass)
	{
		Instance parent = Game.singleton.FindChildByClass(parentClass);
		return AddInstance(instanceClass, parent, true);
	}
	public void AddUI(string instanceClass)
	{
		PlayerGUI parent = Game.singleton.FindChildByClass("PlayerGUI") as PlayerGUI;
		if (parent == null) return;
		Polytoria.Datamodel.GUI gui = parent.FindChildByClass("GUI") as Polytoria.Datamodel.GUI;
		if (gui == null)
		{
			gui = (Polytoria.Datamodel.GUI) Add("GUI", "PlayerGUI");
		}
		AddInstance(instanceClass, gui);
	}

	public void AddSeat(string name = "Seat")
	{
		Seat seat = (Seat) Instance.New("Seat");
		seat.Name = name;

		NetworkServer.Spawn(seat.gameObject);

		seat.Size = new Vector3(2, 1, 2);

		seat.Color = new Color(163 / 255f, 162 / 255f, 165 / 255f);

		Ray ray = Camera.main.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));
		Vector3 pos = Camera.main.transform.position + (Camera.main.transform.forward * 20f);

		if (Physics.Raycast(ray, out RaycastHit hit, 20f))
		{
			pos = hit.point + new Vector3(0, seat.Size.y / 2, 0);
		}
		else
		{
			Plane hPlane = new Plane(Vector3.up, Vector3.zero);

			if (hPlane.Raycast(ray, out float dist))
			{
				pos = ray.GetPoint(dist) + new Vector3(0, seat.Size.y / 2, 0);
			}
		}

		seat.Position = new Vector3(Mathf.Round(pos.x), Mathf.Max(0f + (seat.Size.y / 2), pos.y), Mathf.Round(pos.z));

		TreeView.AddChild(seat.Parent, seat);

		TreeView.Expand(Game.singleton);
		TreeView.Expand(seat.Parent);

		RTObjectSelection.Get.ClearSelection(false);
		RTObjectSelection.Get.SetSelectedObjects(new List<GameObject> { seat.gameObject }, false);
		RTFocusCamera.Get.Focus(RTObjectSelection.Get.GetWorldAABB());
	}

	public static bool IsPointerOverUIObject()
	{
		PointerEventData eventDataCurrentPosition = new PointerEventData(EventSystem.current)
		{
			position = new Vector2(Input.mousePosition.x, Input.mousePosition.y)
		};
		List<RaycastResult> results = new List<RaycastResult>();
		EventSystem.current.RaycastAll(eventDataCurrentPosition, results);
		return results.Count > 0;
	}

	public enum PaintType
	{
		None,
		Color,
		Material
	}

	struct ThumbnailImageTarget
	{
		public string Url { get; set; }
		public Image Target { get; set; }
	}
}
