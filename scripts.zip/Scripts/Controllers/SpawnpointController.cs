using System.Collections.Generic;
using UnityEngine;

public static class SpawnpointController
{
	static List<Part> spawns;

	public static Vector3 GetDefaultSpawnPosition() => Vector3.up * 5f;
	public static void AddSpawn(Part p)
	{
		if (spawns == null)
		{
			spawns = new List<Part>();
		}

		if (!spawns.Contains(p))
		{
			spawns.Add(p);
		}
	}

	public static void RemoveSpawn(Part p)
	{
		if (spawns == null)
		{
			spawns = new List<Part>();
		}

		if (spawns.Contains(p))
		{
			spawns.Remove(p);
		}
	}

	public static Transform GetSpawnPosition()
	{
		if (spawns == null) spawns = new List<Part>();
		if (spawns.Count == 0)
		{
			return null;
		}

		return spawns[Random.Range(0, spawns.Count)].transform;
	}
}
