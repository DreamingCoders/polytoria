using Battlehub.UIControls.MenuControl;
using RLD;
using UnityEngine;

public class CreatorMenuCmdController : MonoBehaviour
{
	public void OnValidateCmd(MenuItemValidationArgs args) { }

	private void Update()
	{
		if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.LeftCommand) || Input.GetKey(KeyCode.RightControl) || Input.GetKey(KeyCode.RightCommand))
		{
			if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
			{
				if (Input.GetKeyDown(KeyCode.S)) CreatorController.singleton.FileSave(true);
				if (Input.GetKeyDown(KeyCode.G)) CreatorController.singleton.UngroupSelection();
			}

			if (Input.GetKeyDown(KeyCode.O)) CreatorController.singleton.FileOpen();
			if (Input.GetKeyDown(KeyCode.S)) CreatorController.singleton.FileSave(false);
			if (Input.GetKeyDown(KeyCode.N)) CreatorController.singleton.ClearWorkspace();
			if (Input.GetKeyDown(KeyCode.P)) CreatorController.singleton.PublishGame();
			if (Input.GetKeyDown(KeyCode.G)) CreatorController.singleton.GroupSelection();
			if (Input.GetKeyDown(KeyCode.D)) CreatorController.singleton.DuplicateSelection();
		}

		if (Input.GetKeyDown(KeyCode.F5))
		{
			CreatorController.singleton.TestGame();
		}
	}

	public void OnCmd(string cmd)
	{
		if (cmd.StartsWith("File"))
		{
			switch (cmd)
			{
				case "FileOpen":
					CreatorController.singleton.FileOpen();
					break;
				case "FileSave":
					CreatorController.singleton.FileSave(false);
					break;
				case "FileSaveAs":
					CreatorController.singleton.FileSave(true);
					break;
				case "FileNew":
					CreatorController.singleton.ClearWorkspace();
					break;
				case "FilePublish":
					CreatorController.singleton.PublishGame();
					break;
				case "FileExit":
					CreatorController.singleton.PromptExit();
					break;
				case "FileExportGLTF":
					CreatorController.singleton.ExportGLTF();
					break;
			}
		}
		else if (cmd.StartsWith("Edit"))
		{
			string action = cmd.Replace("Edit", "");

			switch (action)
			{
				case "Undo":
					RTUndoRedo.Get.Undo();
					break;
				case "Redo":
					RTUndoRedo.Get.Redo();
					break;
				case "Delete":
					CreatorController.singleton.DeleteSelection();
					break;
				case "Duplicate":
					CreatorController.singleton.DuplicateSelection();
					break;
				case "Group":
					CreatorController.singleton.GroupSelection();
					break;
				case "Ungroup":
					CreatorController.singleton.UngroupSelection();
					break;
			}
		}
		else if (cmd.StartsWith("Insert"))
		{
			string insert = cmd.Replace("Insert", "");

			switch (insert)
			{
				case "BrickPart":
					CreatorController.singleton.AddPart(PartShape.Brick, "Brick");
					break;
				case "SpherePart":
					CreatorController.singleton.AddPart(PartShape.Ball, "Sphere");
					break;
				case "CylinderPart":
					CreatorController.singleton.AddPart(PartShape.Cylinder, "Cylinder");
					break;
				case "WedgePart":
					CreatorController.singleton.AddPart(PartShape.Wedge, "Wedge");
					break;
				case "Script":
					CreatorController.singleton.AddScript();
					break;
				case "LocalScript":
					CreatorController.singleton.AddLocalScript();
					break;
				case "RemoteEvent":
					CreatorController.singleton.AddRemoteEvent();
					break;
				case "GUI":
					CreatorController.singleton.Add("GUI", "PlayerGUI");
					break;
				case "Label":
					CreatorController.singleton.AddUI("UILabel");
					break;
				case "Field":
					CreatorController.singleton.AddUI("UIView");
					break;
				case "Button":
					CreatorController.singleton.AddUI("UIButton");
					break;
				case "Image":
					CreatorController.singleton.AddUI("UIImage");
					break;
				case "Input":
					CreatorController.singleton.AddUI("UITextInput");
					break;
				case "HorizontalLayout":
					CreatorController.singleton.AddUI("UIHorizontalLayout");
					break;
				case "VerticalLayout":
					CreatorController.singleton.AddUI("UIVerticalLayout");
					break;
				default:
					CreatorController.singleton.AddInstance(cmd.Substring("Insert".Length));
					break;
			}
		}
		else if (cmd.StartsWith("Model"))
		{
			string model = cmd.Replace("Model", "");

			switch (model)
			{
				case "Import":
					CreatorController.singleton.ImportModel();
					break;
				case "Export":
					CreatorController.singleton.ExportModel();
					break;
				case "Publish":
					CreatorController.singleton.PublishModel();
					break;
			}
		}
		else if (cmd.StartsWith("Tools"))
		{
			string tools = cmd.Replace("Tools", "");

			switch (tools)
			{
				case "Test":
					CreatorController.singleton.TestGame();
					break;
			}
		}
	}
}
