using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class HotbarController : MonoBehaviour
{
	public static HotbarController singleton;
	RectTransform hotbarItem;

	Dictionary<Tool, RectTransform> tools = new Dictionary<Tool, RectTransform>();

	private void Awake()
	{
		singleton = this;
	}

	private void Start()
	{
		hotbarItem = Resources.Load<RectTransform>("UI/HotbarItem");
	}

	public void ToolLinked(Tool tool, Instance parent)
	{
		if (Game.singleton.isServer && !LaunchController.isSolo) return;
		Players plrs = Game.singleton.FindChildOfType<Players>();
		if (plrs == null || plrs.LocalPlayer == null) return;
		if (parent != null && parent.IsDescendantOf(plrs.LocalPlayer))
		{
			if (!tools.ContainsKey(tool))
			{
				if (tools.Count >= 9) return;

				RectTransform slot = Instantiate(hotbarItem, transform);
				slot.Find("Name").GetComponent<TMP_Text>().text = tool.Name;

				int index = slot.GetSiblingIndex();
				slot.Find("HotbarSlot").GetComponent<TMP_Text>().text = (index + 1).ToString();

				tools.Add(tool, slot);
			}
		}
		else
		{
			if (tools.ContainsKey(tool))
			{
				Destroy(tools[tool].gameObject);
				tools.Remove(tool);
			}
		}
	}

	private void Update()
	{
		if (Game.singleton == null) return;
		if (Game.singleton.isServer && !LaunchController.isSolo) return;
		List<Tool> remove = new List<Tool>();
		foreach (KeyValuePair<Tool, RectTransform> kvp in tools)
		{
			RectTransform slot = kvp.Value;
			Tool tool = kvp.Key;

			if (tool == null || !(tool.Parent is Player || tool.Parent is Backpack))
			{
				remove.Add(tool);
				continue;
			}

			slot.Find("Name").GetComponent<TMP_Text>().text = tool.Name;

			int index = slot.GetSiblingIndex();
			slot.Find("HotbarSlot").GetComponent<TMP_Text>().text = (index + 1).ToString();

			if (tool.Parent is Player)
			{
				slot.GetComponent<Image>().color = new Color(0, 0, 0, 120f / 255f);
			}
			else
			{
				slot.GetComponent<Image>().color = new Color(0, 0, 0, 70f / 255f);
			}

			if (Input.GetKeyDown(KeyCode.Alpha1 + index))
			{
				Players plrs = Game.singleton.FindChildOfType<Players>();
				if (plrs.LocalPlayer.Health > 0f)
					EquipTool(tool);
			}
		}

		foreach (Tool tool1 in remove)
		{
			Destroy(tools[tool1].gameObject);
			tools.Remove(tool1);
		}
	}

	void EquipTool(Tool tool)
	{
		Game.singleton.FindChildOfType<Players>().LocalPlayer.EquipTool(tool);
	}
}
