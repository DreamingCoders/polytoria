using Discord;
using UnityEngine;

public class DiscordController : MonoBehaviour
{
	public static DiscordController Instance { get; private set; }
	public Activity Activity => currentActivity;

	private Discord.Discord discord;
	private ActivityManager activityManager;
	private Activity currentActivity;
	private void Awake()
	{
		Instance = this;
	}

	void Start()
	{
		DontDestroyOnLoad(gameObject);

		try
		{
			discord = new Discord.Discord(715468601540476959, (ulong) CreateFlags.NoRequireDiscord);
			activityManager = discord.GetActivityManager();
		}
		catch { }
	}

	public void UpdateActivity(Activity activity)
	{
		if (activityManager == null || discord == null) return;
		currentActivity = activity;
		activityManager.UpdateActivity(activity, (res) =>
		{
			if (res != Result.Ok)
			{
				if (res != Result.NotRunning)
					Debug.LogError("Unable to update Discord RPC activity: " + res.ToString());
			}
		});
	}

	private void Update()
	{
		if (activityManager == null || discord == null) return;
		discord.RunCallbacks();
	}

	private void OnDestroy()
	{
		if (discord != null)
			discord.Dispose();
	}
}
