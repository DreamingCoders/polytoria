using System;
using System.Collections;
using System.Collections.Generic;
using SimpleJSON;
using TMPro;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class UIController : MonoBehaviour
{
	public static int maxDebugLogLength = 8192;
	public static UIController singleton;
	public event Action Resetted;
	public Color selectedBtnColor;
	public Color unselectedBtnColor;
	public Color healthBarGreen, healthBarRed;
	public MenuTabPair[] tabs;
	public TMP_Text GameName;

	readonly DateTime timeWhenStarted = DateTime.Now;

	public RectTransform Leaderboard { get; private set; }
	public RectTransform LeaderboardContent { get; private set; }
	public RectTransform UserTag { get; private set; }
	public RectTransform PauseMenu { get; private set; }
	public RectTransform ChatButton { get; private set; }
	public RectTransform InventoryButton { get; private set; }
	public RectTransform DebugConsole { get; private set; }
	public Image PauseMenuImg { get; private set; }
	public RectTransform PauseMenuChild { get; private set; }
	public Canvas Canvas { get; private set; }
	public TMP_InputField ChatBar { get; private set; }
	public static bool Paused { get; private set; }
	public static bool ConsoleOpen { get; private set; }

	public Image HealthbarCont { get; private set; }
	public Image Healthbar { get; private set; }
	public Image HealthbarHeart { get; private set; }
	public TMP_Text HealthbarHeartText { get; private set; }

	public UIStaminaBar StaminaBar { get; private set; }
	RectTransform leaderboardEntry;
	RectTransform main;
	RectTransform alwaysOnTop;
	RectTransform logsParent;
	RectTransform playerListMenu;
	GameObject playerListMenuEntry;
	GameObject debugLogMessageTemplate;
	MenuButtonAnimation menuController;

	TMP_Text overviewUsername, timePlaying, playerCount, instanceCount, debugLogs;

	[SerializeField] TMP_Text localText;
	[SerializeField] RectTransform pauseMenu;
	[SerializeField] RectTransform disconnectScreen;

	private CursorLockMode lockState;

	string localUsername;

	private void Awake()
	{
		singleton = this;
	}

	private void Start()
	{
		Canvas = GetComponent<Canvas>();

		main = (RectTransform) transform.Find("Main");
		PauseMenu = pauseMenu;

		alwaysOnTop = (RectTransform) transform.Find("AlwaysOnTop");
		PauseMenuImg = PauseMenu.GetComponent<Image>();
		PauseMenuChild = (RectTransform) PauseMenu.transform.Find("Menu");
		PauseMenu.gameObject.SetActive(true);
		overviewUsername = PauseMenuChild.Find("Overview").Find("Username").GetComponent<TMP_Text>();
		timePlaying = PauseMenuChild.Find("Overview").Find("TimePlaying").GetComponent<TMP_Text>();
		playerCount = PauseMenuChild.Find("Overview").Find("PlayerCount").GetComponent<TMP_Text>();
		instanceCount = PauseMenuChild.Find("Overview").Find("InstanceCount").GetComponent<TMP_Text>();
		leaderboardEntry = Resources.Load<RectTransform>("UI/LeaderboardEntry");

		PauseMenuImg.color = new Color(0, 0, 0, 0);
		PauseMenuChild.anchoredPosition3D = new Vector3(0, Screen.height * Canvas.GetComponent<CanvasScaler>().scaleFactor * 2, 0);
		Leaderboard = (RectTransform) main.Find("Leaderboard");
		LeaderboardContent = (RectTransform) Leaderboard.Find("Viewport").Find("Content");
		UserTag = (RectTransform) main.Find("UserTag");

		HealthbarCont = main.Find("Healthbar").GetComponent<Image>();
		Healthbar = main.Find("Healthbar/Fill").GetComponent<Image>();
		HealthbarHeart = main.Find("Healthbar/Heart").GetComponent<Image>();
		HealthbarHeartText = main.Find("Healthbar/Heart/HealthAmount").GetComponent<TMP_Text>();
		StaminaBar = main.Find("Healthbar/Stamina").GetComponent<UIStaminaBar>();

		ChatBar = main.Find("Chat").Find("Input").GetComponent<TMP_InputField>();
		ChatButton = (RectTransform) alwaysOnTop.Find("ChatButton");
		InventoryButton = (RectTransform) alwaysOnTop.Find("InventoryButton");
		DebugConsole = (RectTransform) main.Find("Console");
		DebugConsole.position = new Vector2(DebugConsole.position.x, Screen.height + DebugConsole.rect.size.y);
		menuController = GetComponentInChildren<MenuButtonAnimation>();
		playerListMenu = PauseMenuChild.Find("Player List").Find("Scroll View").GetComponent<ScrollRect>().content;
		debugLogMessageTemplate = Resources.Load<GameObject>("UI/DebugLogMessage");
		playerListMenuEntry = Resources.Load<GameObject>("UI/PlayerListEntry");
		logsParent = DebugConsole.GetComponentInChildren<ScrollRect>().content;
		debugLogs = logsParent.Find("DebugLogMessage").GetComponent<TMP_Text>();

		localText.enabled = LaunchController.isLocal;

		SetActiveMenuTab(0);

		SetConsoleOpen(false);
	}

	public void SetActiveMenuTab(int index)
	{
		for (int i = 0; i < tabs.Length; i++)
		{
			tabs[i].button.GetComponent<Image>().color = unselectedBtnColor;
			tabs[i].container.gameObject.SetActive(false);
		}

		tabs[index].button.GetComponent<Image>().color = selectedBtnColor;
		tabs[index].container.gameObject.SetActive(true);
	}

	public enum HudButton
	{
		Chat,
		Inventory
	}
	public void SetButtonFocused(HudButton type, bool focused)
	{
		switch (type)
		{
			case HudButton.Chat:
				ChatButton.Find("Focus").gameObject.SetActive(focused);
				break;
			case HudButton.Inventory:
				InventoryButton.Find("Focus").gameObject.SetActive(focused);
				break;
		}
	}

	private bool lbOpen = true;

	private void ToggleLeaderboard()
	{
		lbOpen = !lbOpen;
		LeanTween.moveX(UserTag, lbOpen ? -20 : UserTag.sizeDelta.x, lbOpen ? 0.35f : 0.5f).setEase(LeanTweenType.easeOutExpo);
		LeanTween.moveX(Leaderboard, lbOpen ? -20 : Leaderboard.sizeDelta.x, lbOpen ? 0.5f : 0.35f).setEase(LeanTweenType.easeOutBack);
	}

	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.Escape) || Input.GetButtonDown("Menu"))
		{
			TogglePaused();
		}

		if (Input.GetKeyDown(KeyCode.Tab))
		{
			ToggleLeaderboard();
		}

		if (Input.GetKeyDown(KeyCode.F8))
		{
			ToggleConsole();
		}

		if (Input.GetKeyDown(KeyCode.F1) || Input.GetButtonDown("View"))
		{
			Canvas.enabled = !Canvas.enabled;
		}

		UpdateTimer();
		UpdatePlayerCount();
		UpdateInstanceCount();
	}

	void UpdateInstanceCount()
	{
		if (Game.singleton != null)
			instanceCount.text = Game.singleton.LocalInstanceCount.ToString("#,##0") + " instances";
	}

	void UpdateTimer()
	{
		TimeSpan timeSpan = DateTime.Now - timeWhenStarted;

		string label = timeSpan.Seconds + "s";

		if (timeSpan.Minutes != 0)
		{
			label = timeSpan.Minutes + "m " + label;
		}

		if (timeSpan.Hours != 0)
		{
			label = timeSpan.Hours + "h " + label;
		}

		timePlaying.text = "Playing for " + label;
	}

	void UpdatePlayerCount()
	{
		if (Game.singleton != null && playerCount != null)
			playerCount.text = Game.singleton.PlayersConnected + " players in server";
	}

	public void ResetCharacter()
	{
		Resetted?.Invoke();
		TogglePaused();
	}

	public void ExitGame()
	{
		Application.Quit();
	}

	public void TogglePaused()
	{
		SetPaused(!Paused);
	}

	private bool PauseDebounce = false;

	public void SetPaused(bool paused)
	{
		if (PauseDebounce) return;
		PauseDebounce = true;
		menuController.SetOpen(paused);
		void pauseUpdateDelegate(float val)
		{
			PauseMenuImg.color = new Color(0, 0, 0, val);
		}
		PauseMenuImg.raycastTarget = paused;
		if (paused)
		{
			SetConsoleOpen(false);
			//Preserve lock state
			lockState = Cursor.lockState;
			Cursor.lockState = CursorLockMode.None;
			Cursor.visible = true;
			PauseMenu.gameObject.SetActive(true);
			LeanTween.value(PauseMenu.gameObject, 0, 0.5f, 0.5f).setOnUpdate(pauseUpdateDelegate).setOnComplete(() =>
			{
				Paused = true;
				PauseDebounce = false;
			});
			LeanTween.moveY(PauseMenuChild, 0f, 0.5f).setEase(LeanTweenType.easeOutExpo);
			LeanTween.moveX(Leaderboard, Leaderboard.sizeDelta.x, 0.5f).setEase(LeanTweenType.easeOutExpo);
			LeanTween.moveX(UserTag, UserTag.sizeDelta.x, 0.5f).setEase(LeanTweenType.easeOutExpo);
			LeanTween.moveY(ChatButton, ChatButton.sizeDelta.y, 0.3f).setEase(LeanTweenType.linear);
			LeanTween.moveY(InventoryButton, InventoryButton.sizeDelta.y, 0.2f).setEase(LeanTweenType.linear);
		}
		else
		{
			Cursor.lockState = lockState;
			LeanTween.value(PauseMenu.gameObject, 0.5f, 0, 0.5f).setOnUpdate(pauseUpdateDelegate).setOnComplete(() =>
			{
				PauseMenu.gameObject.SetActive(false);
				Paused = false;
				PauseDebounce = false;
			});
			LeanTween.moveY(PauseMenuChild, Screen.height * Canvas.GetComponent<CanvasScaler>().scaleFactor * 2, 0.75f).setEase(LeanTweenType.easeOutExpo);
			LeanTween.moveX(Leaderboard, lbOpen ? -20 : Leaderboard.sizeDelta.x, 0.5f).setEase(LeanTweenType.easeOutExpo);
			LeanTween.moveX(UserTag, lbOpen ? -20 : UserTag.sizeDelta.x, 0.5f).setEase(LeanTweenType.easeOutExpo);
			LeanTween.moveY(ChatButton, -10, 0.3f).setEase(LeanTweenType.linear);
			LeanTween.moveY(InventoryButton, -10, 0.2f).setEase(LeanTweenType.linear);

		}
	}

	public void SetGameInfo(string gameName)
	{
		GameName.text = gameName;
	}

	private readonly Dictionary<string, Sprite> badgeIcons = new Dictionary<string, Sprite>();
	public Sprite GetLeaderboardBadgeIcon(string badgeName)
	{
		if (badgeIcons.ContainsKey(badgeName))
			return badgeIcons[badgeName];
		Sprite icon = Resources.Load<Sprite>("LeaderboardIcons/icon_" + badgeName);
		badgeIcons.Add(badgeName, icon);
		return icon;
	}

	public void AddLeaderboardUser(Player player)
	{
		if (LeaderboardUsers.ContainsKey(player.Name)) return;
		string username = player.Name;
		int userId = player.UserID;
		if (username == localUsername) return;
		RectTransform entry = Instantiate(leaderboardEntry, LeaderboardContent);
		RectTransform playerListEntry = (RectTransform) Instantiate(playerListMenuEntry, playerListMenu).transform;
		LeaderboardUsers.Add(username, entry.gameObject);
		PlayerListUsers.Add(username, playerListEntry.gameObject);
		entry.Find("Username").GetComponent<TMP_Text>().text = username;
		string pleUsername = username;
		playerListEntry.Find("Username").GetComponent<TMP_Text>().text = pleUsername;
		playerListEntry.Find("Username").GetComponent<Button>().onClick.AddListener(delegate { Application.OpenURL("https://polytoria.com/user/" + userId); });
		playerListEntry.Find("Mask").GetComponent<Button>().onClick.AddListener(delegate { Application.OpenURL("https://polytoria.com/user/" + userId); });
		//playerListEntry.Find("FriendButton").GetComponent<Button>().onClick.AddListener(delegate { Game.singleton.SendFriendRequest(userId); });
		playerListEntry.Find("ReportButton").GetComponent<Button>().onClick.AddListener(delegate { Application.OpenURL("https://polytoria.com/report/user/" + userId); });
		StartCoroutine(LoadLeaderboardThumbnail(entry, playerListEntry, player));
	}

	IEnumerator LoadLeaderboardThumbnail(RectTransform _lbEntry, RectTransform _plEntry, Player player)
	{
		while (!player.IsLoaded)
		{
			yield return new WaitForSeconds(0.1f);
		}

		string url = "https://api.polytoria.com/v1/users/" + player.UserID;
		using UnityWebRequest uwr = UnityWebRequest.Get(url);
		yield return uwr.SendWebRequest();

		if (uwr.result != UnityWebRequest.Result.Success)
		{
			Debug.LogError(uwr.error);
		}
		else
		{
			if (_plEntry == null) yield break;
			JSONNode user = JSON.Parse(uwr.downloadHandler.text);
			string pleUsername = player.Name;

			string badge = "empty";
			string mt = user["membershipType"];
			switch (mt)
			{
				case "plus":
					badge = "plus";
					pleUsername = player.Name + "\n<size=16><color=#30BEE5>Plus</color></size>";
					break;
				case "plusDeluxe":
					badge = "plusdx";
					pleUsername = player.Name + "\n<size=16><color=#A330E5>Plus Deluxe</color></size>";
					break;
			}
			if (player.IsCreator)
			{
				badge = "creator";
				pleUsername = player.Name + "\n<size=16><color=#a961ff>Place Creator</color></size>";
			}
			if (player.IsAdmin)
			{
				badge = "staff";
				pleUsername = player.Name + "\n<size=16><color=#ffaaaa>Polytoria Admin</color></size>";
			}
			if (player.UserID == 3)
			{
				badge = "burrito";
			}
			if (player.UserID == 2677)
			{
				badge = "brix";
			}
			Transform t = _plEntry.Find("Username");
			if (t == null)
				yield break;
			t.GetComponent<TMP_Text>().text = pleUsername;
			if (badge != "empty")
			{
				_lbEntry.Find("Icon").GetComponent<Image>().sprite = GetLeaderboardBadgeIcon(badge);
				_lbEntry.Find("Icon").gameObject.SetActive(true);
			}

			Button reportBtn = _plEntry.Find("ReportButton").GetComponent<Button>();
			Button uerBtn = _plEntry.Find("Username").GetComponent<Button>();
			Button maskBtn = _plEntry.Find("Mask").GetComponent<Button>();
			//temp fix for fixing report button
			reportBtn.onClick.RemoveAllListeners();
			uerBtn.onClick.RemoveAllListeners();
			maskBtn.onClick.RemoveAllListeners();
			reportBtn.onClick.AddListener(delegate { Application.OpenURL("https://polytoria.com/report/user/" + player.UserID); });
			uerBtn.onClick.AddListener(delegate { Application.OpenURL("https://polytoria.com/user/" + player.UserID); });
			maskBtn.onClick.AddListener(delegate { Application.OpenURL("https://polytoria.com/user/" + player.UserID); });

			using UnityWebRequest twr = UnityWebRequestTexture.GetTexture(user["thumbnail"]["icon"]);
			yield return twr.SendWebRequest();

			if (twr.result != UnityWebRequest.Result.Success)
			{
				Debug.LogError(twr.error);
			}
			else
			{
				Texture2D wwwTexture = DownloadHandlerTexture.GetContent(twr);
				Texture2D texture = new Texture2D(wwwTexture.width, wwwTexture.height, wwwTexture.format, true);
				texture.LoadImage(twr.downloadHandler.data);
				texture.Apply(true);
				Sprite s = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one / 2);

				if (_lbEntry != null)
					_lbEntry.Find("Mask").Find("Avatar").GetComponent<Image>().sprite = s;

				if (_plEntry != null)
					_plEntry.Find("Mask").Find("Avatar").GetComponent<Image>().sprite = s;

				//temp fix for fixing report button
				reportBtn.onClick.RemoveAllListeners();
				reportBtn.onClick.AddListener(delegate { Application.OpenURL("https://polytoria.com/report/user/" + player.UserID); });

			}
		}
	}
	Dictionary<string, GameObject> LeaderboardUsers = new Dictionary<string, GameObject>();
	Dictionary<string, GameObject> PlayerListUsers = new Dictionary<string, GameObject>();

	public void RemoveLeaderboardUser(string username)
	{
		if (LeaderboardUsers.ContainsKey(username))
		{
			Destroy(LeaderboardUsers[username]);
			LeaderboardUsers.Remove(username);
		}
		if (PlayerListUsers.ContainsKey(username))
		{
			Destroy(PlayerListUsers[username]);
			PlayerListUsers.Remove(username);
		}
	}

	public void SetUserCard(int userId, string username)
	{
		main.Find("UserTag").Find("Username").GetComponent<TMP_Text>().text = username;
		overviewUsername.text = username;
		RemoveLeaderboardUser(username);
		localUsername = username;
		StartCoroutine(LoadThumbnail(userId));
	}

	public void ReceiveChat(string username, string message, Color usernameColor)
	{
		ChatWindow.instance.PushChat(username, message, usernameColor);
	}

	public void DebugLog(string message, bool error)
	{
		string time = DateTime.Now.ToString("HH:mm:ss");

		string txt = "[" + time + "]: " + message;
		if (error)
		{
			txt = "<color=red>" + txt + "</color>";
		}
		debugLogs.text += "\n" + txt;
		debugLogs.text = debugLogs.text.Substring(Math.Max(0, debugLogs.text.Length - maxDebugLogLength));
		LayoutRebuilder.ForceRebuildLayoutImmediate(logsParent);
	}

	public void SetHealthFilled(float fill)
	{
		Healthbar.fillAmount = fill;

		Color col = Color.HSVToRGB(Mathf.Lerp(0, 113, Mathf.Clamp01(fill * 1.333f)) / 360f, 75 / 100f, 91 / 100f);//Color.Lerp(healthBarRed, healthBarGreen, Mathf.Clamp01(fill * 1.3f));
		HealthbarCont.color = col;
		Healthbar.color = col;
		HealthbarHeart.color = col;
	}
	public void SetStaminaFilled(float fill, bool exhausted)
	{
		StaminaBar.SetFill(fill, exhausted);
	}

	public void ToggleConsole()
	{
		SetConsoleOpen(!ConsoleOpen);
	}

	public void OpenConsoleFromPauseMenu()
	{
		SetConsoleOpen(true);
		SetPaused(false);
	}

	private bool ConsoleDebounce = false;
	public void SetConsoleOpen(bool open)
	{
		if (ConsoleDebounce) return;
		ConsoleDebounce = true;
		if (open)
		{
			DebugConsole.gameObject.SetActive(true);
			LeanTween.moveY(DebugConsole, 0f, .5f).setEase(LeanTweenType.easeOutExpo).setOnComplete(() =>
			{
				ConsoleOpen = true;
				ConsoleDebounce = false;
			});
		}
		else
		{
			LeanTween.moveY(DebugConsole, Screen.height + DebugConsole.rect.size.y, .5f).setEase(LeanTweenType.easeOutExpo).setOnComplete(() =>
			{
				ConsoleOpen = false;
				DebugConsole.gameObject.SetActive(false);
				ConsoleDebounce = false;
			});
		}
	}

	IEnumerator LoadThumbnail(int userId)
	{
		using UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/users/" + userId);
		yield return uwr.SendWebRequest();

		if (uwr.result != UnityWebRequest.Result.Success)
		{
			Debug.LogError(uwr.error);
		}
		else
		{
			JSONNode user = JSON.Parse(uwr.downloadHandler.text);
			using (UnityWebRequest twr = UnityWebRequestTexture.GetTexture(user["thumbnail"]["icon"]))
			{
				yield return twr.SendWebRequest();

				if (twr.result != UnityWebRequest.Result.Success)
				{
					Debug.LogError(twr.error);
				}
				else
				{
					Texture2D wwwTexture = DownloadHandlerTexture.GetContent(twr);
					Texture2D texture = new Texture2D(wwwTexture.width, wwwTexture.height, wwwTexture.format, true);
					texture.LoadImage(twr.downloadHandler.data);
					texture.Apply(true);
					Sprite s = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one / 2);
					main.Find("UserTag").Find("Mask").Find("Avatar").GetComponent<Image>().sprite = s;
				}
			}

			using (UnityWebRequest twr = UnityWebRequestTexture.GetTexture(user["thumbnail"]["avatar"]))
			{
				yield return twr.SendWebRequest();

				if (twr.result != UnityWebRequest.Result.Success)
				{
					Debug.LogError(twr.error);
				}
				else
				{
					Texture2D wwwTexture = FlipTexture(DownloadHandlerTexture.GetContent(twr));
					Texture2D texture = new Texture2D(wwwTexture.width, wwwTexture.height, wwwTexture.format, true);
					texture.LoadImage(twr.downloadHandler.data);
					texture.Apply(true);
					Sprite s = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.one / 2);
					overviewUsername.transform.parent.Find("AvatarContainer").Find("Avatar").GetComponent<Image>().sprite = s;
				}
			}
		}
	}

	Texture2D FlipTexture(Texture2D original)
	{
		Texture2D flipped = new Texture2D(original.width, original.height);

		int xN = original.width;
		int yN = original.height;


		for (int i = 0; i < xN; i++)
		{
			for (int j = 0; j < yN; j++)
			{
				flipped.SetPixel(xN - i - 1, j, original.GetPixel(i, j));
			}
		}
		flipped.Apply();

		return flipped;
	}

	public void ShowDisconnectMessage(string reason)
	{
		disconnectScreen.gameObject.SetActive(true);
		disconnectScreen.Find("MessageBox").GetComponentInChildren<TMP_Text>().text = reason;
	}
}

[Serializable]
public struct MenuTabPair
{
	public Button button;
	public RectTransform container;
}
