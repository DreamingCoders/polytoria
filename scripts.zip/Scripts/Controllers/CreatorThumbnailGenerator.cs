using System.Collections.Generic;
using System.Linq;
using RLD;
using UnityEngine;
using UnityEngine.UI;

public class CreatorThumbnailGenerator : MonoBehaviour
{
	[SerializeField] RawImage preview;
	[SerializeField] int width = 420;
	[SerializeField] int height = 420;
	[SerializeField] float _padding = 0.1f;

	[SerializeField] Camera thumbnailCamera;

	Dictionary<GameObject, int> oldLayers = new Dictionary<GameObject, int>();

	public Texture2D GenerateThumbnail(Instance instance)
	{
		RTObjectSelection.Get.ClearSelection(true);
		Texture2D result = null;

		Bounds bounds = new Bounds();
		List<Renderer> renderers = instance.GetComponentsInChildren<Renderer>().ToList();
		bool hasBounds = false;

		for (int i = 0; i < renderers.Count; i++)
		{
			Renderer r = renderers[i];
			if (r.enabled)
			{
				if (!hasBounds)
				{
					bounds = r.bounds;
					hasBounds = true;
				}
				else
				{
					bounds.Encapsulate(r.bounds);
				}
			}
		}

		SetLayer(instance, LayerMask.NameToLayer("Thumbnail"));
		thumbnailCamera.gameObject.SetActive(true);

		PositionCamera(thumbnailCamera, bounds, _padding);

		RenderTexture tex = RenderTexture.GetTemporary(width, height, 16);
		RenderTexture activeRt = RenderTexture.active;
		RenderTexture.active = tex;
		GL.Clear(true, true, new Color(thumbnailCamera.backgroundColor.r, thumbnailCamera.backgroundColor.g, thumbnailCamera.backgroundColor.b));

		thumbnailCamera.targetTexture = tex;

		thumbnailCamera.Render();

		thumbnailCamera.targetTexture = null;

		result = new Texture2D(width, height, TextureFormat.RGBA32, false);
		result.ReadPixels(new Rect(0, 0, width, height), 0, 0, false);
		result.Apply(tex);

		RenderTexture.active = activeRt;
		RenderTexture.ReleaseTemporary(tex);
		thumbnailCamera.gameObject.SetActive(false);

		SetLayer(instance, -1);

		return result;
	}

	void SetLayer(Instance i, int layer)
	{
		if (layer == -1)
		{
			i.gameObject.layer = oldLayers[i.gameObject];
			oldLayers.Remove(i.gameObject);
		}
		else
		{
			oldLayers.Add(i.gameObject, i.gameObject.layer);
			i.gameObject.layer = layer;
		}

		foreach (Instance child in i.GetChildren())
		{
			SetLayer(child, layer);
		}
	}

	public void PositionCamera(Camera camera, Bounds bounds, float padding = 0f)
	{
		Transform cameraTR = camera.transform;

		Vector3 cameraDirection = cameraTR.forward;
		float aspect = camera.aspect;

		if (padding != 0f)
			bounds.size *= 1f + padding * 2f;

		Vector3 boundsCenter = bounds.center;
		Vector3 boundsExtents = bounds.extents;
		Vector3 boundsSize = 2f * boundsExtents;

		Vector3 point = boundsCenter + boundsExtents;

		Vector3[] boundingBoxPoints = new Vector3[8];
		boundingBoxPoints[0] = point;
		point.x -= boundsSize.x;
		boundingBoxPoints[1] = point;
		point.y -= boundsSize.y;
		boundingBoxPoints[2] = point;
		point.x += boundsSize.x;
		boundingBoxPoints[3] = point;
		point.z -= boundsSize.z;
		boundingBoxPoints[4] = point;
		point.x -= boundsSize.x;
		boundingBoxPoints[5] = point;
		point.y += boundsSize.y;
		boundingBoxPoints[6] = point;
		point.x += boundsSize.x;
		boundingBoxPoints[7] = point;

		if (camera.orthographic)
		{
			cameraTR.position = boundsCenter;

			float minX = float.PositiveInfinity, minY = float.PositiveInfinity;
			float maxX = float.NegativeInfinity, maxY = float.NegativeInfinity;

			for (int i = 0; i < boundingBoxPoints.Length; i++)
			{
				Vector3 localPoint = cameraTR.InverseTransformPoint(boundingBoxPoints[i]);
				if (localPoint.x < minX)
					minX = localPoint.x;
				if (localPoint.x > maxX)
					maxX = localPoint.x;
				if (localPoint.y < minY)
					minY = localPoint.y;
				if (localPoint.y > maxY)
					maxY = localPoint.y;
			}

			float distance = boundsExtents.magnitude + 1f;
			camera.orthographicSize = Mathf.Max(maxY - minY, (maxX - minX) / aspect) * 0.5f;
			cameraTR.position = boundsCenter - cameraDirection * distance;
		}
		else
		{
			Vector3 cameraUp = cameraTR.up, cameraRight = cameraTR.right;

			float verticalFOV = camera.fieldOfView * 0.5f;
			float horizontalFOV = Mathf.Atan(Mathf.Tan(verticalFOV * Mathf.Deg2Rad) * aspect) * Mathf.Rad2Deg;

			Vector3 topFrustumPlaneNormal = Quaternion.AngleAxis(90f + verticalFOV, -cameraRight) * cameraDirection;
			Vector3 bottomFrustumPlaneNormal = Quaternion.AngleAxis(90f + verticalFOV, cameraRight) * cameraDirection;
			Vector3 rightFrustumPlaneNormal = Quaternion.AngleAxis(90f + horizontalFOV, cameraUp) * cameraDirection;
			Vector3 leftFrustumPlaneNormal = Quaternion.AngleAxis(90f + horizontalFOV, -cameraUp) * cameraDirection;

			int leftmostPoint = -1, rightmostPoint = -1, topmostPoint = -1, bottommostPoint = -1;
			for (int i = 0; i < boundingBoxPoints.Length; i++)
			{
				if (leftmostPoint < 0 && IsOutermostPointInDirection(i, leftFrustumPlaneNormal, boundingBoxPoints))
					leftmostPoint = i;
				if (rightmostPoint < 0 && IsOutermostPointInDirection(i, rightFrustumPlaneNormal, boundingBoxPoints))
					rightmostPoint = i;
				if (topmostPoint < 0 && IsOutermostPointInDirection(i, topFrustumPlaneNormal, boundingBoxPoints))
					topmostPoint = i;
				if (bottommostPoint < 0 && IsOutermostPointInDirection(i, bottomFrustumPlaneNormal, boundingBoxPoints))
					bottommostPoint = i;
			}

			Ray horizontalIntersection = GetPlanesIntersection(new Plane(leftFrustumPlaneNormal, boundingBoxPoints[leftmostPoint]), new Plane(rightFrustumPlaneNormal, boundingBoxPoints[rightmostPoint]));
			Ray verticalIntersection = GetPlanesIntersection(new Plane(topFrustumPlaneNormal, boundingBoxPoints[topmostPoint]), new Plane(bottomFrustumPlaneNormal, boundingBoxPoints[bottommostPoint]));

			Vector3 closestPoint1, closestPoint2;
			FindClosestPointsOnTwoLines(horizontalIntersection, verticalIntersection, out closestPoint1, out closestPoint2);

			cameraTR.position = Vector3.Dot(closestPoint1 - closestPoint2, cameraDirection) < 0 ? closestPoint1 : closestPoint2;
		}
	}

	private static void FindClosestPointsOnTwoLines(Ray line1, Ray line2, out Vector3 closestPointLine1, out Vector3 closestPointLine2)
	{
		Vector3 line1Direction = line1.direction;
		Vector3 line2Direction = line2.direction;

		float a = Vector3.Dot(line1Direction, line1Direction);
		float b = Vector3.Dot(line1Direction, line2Direction);
		float e = Vector3.Dot(line2Direction, line2Direction);

		float d = a * e - b * b;

		Vector3 r = line1.origin - line2.origin;
		float c = Vector3.Dot(line1Direction, r);
		float f = Vector3.Dot(line2Direction, r);

		float s = (b * f - c * e) / d;
		float t = (a * f - c * b) / d;

		closestPointLine1 = line1.origin + line1Direction * s;
		closestPointLine2 = line2.origin + line2Direction * t;
	}

	private static Ray GetPlanesIntersection(Plane p1, Plane p2)
	{
		Vector3 p3Normal = Vector3.Cross(p1.normal, p2.normal);
		float det = p3Normal.sqrMagnitude;

		return new Ray(((Vector3.Cross(p3Normal, p2.normal) * p1.distance) + (Vector3.Cross(p1.normal, p3Normal) * p2.distance)) / det, p3Normal);
	}

	private static bool IsOutermostPointInDirection(int pointIndex, Vector3 direction, Vector3[] boundingBoxPoints)
	{
		Vector3 point = boundingBoxPoints[pointIndex];
		for (int i = 0; i < boundingBoxPoints.Length; i++)
		{
			if (i != pointIndex && Vector3.Dot(direction, boundingBoxPoints[i] - point) > 0)
				return false;
		}

		return true;
	}

	public void TestRender()
	{
		List<Instance> selectedInstances = CreatorController.GetSelectedInstances();
		if (selectedInstances.Count == 0) return;
		Texture2D dddd = GenerateThumbnail(selectedInstances[0]);
		preview.texture = dddd;
	}
}
