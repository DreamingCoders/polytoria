using System.Collections;
using System.Collections.Generic;
using System.Linq;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

public class ImageCacheController : MonoBehaviour
{
	public static ImageCacheController Instance { get; private set; }
	static Dictionary<ImageCacheKey, ImageCacheEntry> cache = new Dictionary<ImageCacheKey, ImageCacheEntry>();
	Queue<ImageCacheKey> loadQueue = new Queue<ImageCacheKey>();
	Texture2D fallback;
	bool loading;

	private void Awake()
	{
		if (Instance == null)
		{
			Instance = this;
		}
		else
		{
			Destroy(gameObject);
		}

		fallback = Resources.Load<Texture2D>("Textures/white");
	}

	public void GetImage(ImageCacheKey key, System.Action<ImageCacheKey, ImageCacheEntry> callback)
	{
		if (cache.TryGetValue(key, out ImageCacheEntry entry))
		{
			if (entry.loaded)
			{
				callback(key, entry);
			}
			else
			{
				StartCoroutine(WaitForImage(key, callback));
			}
		}
		else
		{
			cache.Add(key, new ImageCacheEntry());
			loadQueue.Enqueue(key);
			StartCoroutine(WaitForImage(key, callback));
		}
	}

	IEnumerator WaitForImage(ImageCacheKey key, System.Action<ImageCacheKey, ImageCacheEntry> callback)
	{
		float time = Time.realtimeSinceStartup;
		while (true)
		{
			if (Time.realtimeSinceStartup > time + 300f)
			{
				callback(key, new ImageCacheEntry { texture = fallback });
				break;
			}

			if (cache.TryGetValue(key, out ImageCacheEntry entry))
			{
				if (entry.loaded)
				{
					callback(key, entry);
					break;
				}
			}
			yield return null;
		}
	}

	private void Update()
	{
		if (loading) return;
		if (loadQueue.Count == 0) return;

		loading = true;
		ImageCacheKey key = loadQueue.Dequeue();
		StartCoroutine(LoadImage(key));
	}

	IEnumerator LoadImage(ImageCacheKey key, int tries = 0)
	{
		string url = key.url;

		if (string.IsNullOrEmpty(url))
		{
			using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/assets/serve/" + key.id + "/" + key.type))
			{
				Debug.Log(key.type);
				Debug.Log("That was the type");
				yield return uwr.SendWebRequest();
				if (uwr.result != UnityWebRequest.Result.Success)
				{
					if (tries > 3)
					{
						cache[key].texture = fallback;
					}
					else
					{
						yield return new WaitForSeconds(2f);
						yield return LoadImage(key, tries + 1);
					}
				}
				else
				{
					JSONNode data = JSON.Parse(uwr.downloadHandler.text);
					if (data["success"].AsBool == true)
					{
						url = data["url"].Value;
					}
					else
					{
						if (tries > 3)
						{
							cache[key].texture = fallback;
						}
						else
						{
							yield return new WaitForSeconds(2f);
							yield return LoadImage(key, tries + 1);
						}
					}
				}
			}
		}

		using (UnityWebRequest www = UnityWebRequestTexture.GetTexture(url))
		{
			yield return www.SendWebRequest();
			if (www.result != UnityWebRequest.Result.Success)
			{
				if (tries > 3)
				{
					cache[key].texture = fallback;
				}
				else
				{
					yield return new WaitForSeconds(2f);
					yield return LoadImage(key, tries + 1);
				}
			}
			else
			{
				cache[key].texture = DownloadHandlerTexture.GetContent(www);
				cache[key].hasTransparency = cache[key].texture.GetPixels32().Any(c => c.a != 255 && c.a != 0);
			}

			cache[key].loaded = true;
			loading = false;
		}

		yield return null;
	}
}

public class ImageCacheEntry
{
	public Texture2D texture;
	public bool loaded;
	public bool hasTransparency;
}

public struct ImageCacheKey
{
	public string id;
	public string url;
	public ImageType type;

	public override bool Equals(object obj)
	{
		if (obj is ImageCacheKey)
		{
			ImageCacheKey other = (ImageCacheKey) obj;
			return other.id == id && other.type == type && other.url == url;
		}

		return false;
	}

	public override int GetHashCode()
	{
		int hash = 0;
		if (id != null)
		{
			hash = hash ^ id.GetHashCode();
		}
		hash = hash ^ type.GetHashCode();
		if (url != null)
		{
			hash = hash ^ url.GetHashCode();
		}
		return hash;
	}
}

public enum ImageType
{
	Asset = 0,
	AssetThumbnail,
	PlaceThumbnail,
	UserAvatar,
	UserAvatarHeadshot,
	GuildIcon
}
