using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LaunchController : MonoBehaviour
{
	public static LaunchController singleton;
	public static NetworkType launchType = NetworkType.Client;
	public static string clientToken;
	public static string serverToken;
	public static bool isSolo = false;
	public static string soloMapPath;

	public static string soloUserName;

	public static int soloUserID;

	public static int soloID;

	public static bool isLocal;
	public static int localGameId;
	public static int localUserId;
	public static string localMapPath;

	[SerializeField] NetworkType editorLaunchType;
	[SerializeField] string testToken;
	[SerializeField] bool doPlaySolo;
	[SerializeField] string playSoloTestMap;
	[SerializeField] string playSoloTestUserName;
	[SerializeField] int playSoloTestUserID;
	[SerializeField] bool doLocal;
	[SerializeField] int testLocalUserId;
	[SerializeField] int testLocalGameId;
	[SerializeField] string testLocalMapPath;
	[SerializeField] string testMobileLaunchURI;

	void Start()
	{
		Application.targetFrameRate = 144;
		singleton = this;
		try
		{
			DirectoryInfo tempDir = new DirectoryInfo(Application.temporaryCachePath);

			foreach (FileInfo file in tempDir.GetFiles())
			{
				file.Delete();
			}

			foreach (DirectoryInfo directory in tempDir.GetDirectories())
			{
				directory.Delete(true);
			}
		}
		catch (System.Exception e)
		{
			Debug.LogError("Failed to clear temp directory: " + e.Message);
		}

		if (Application.isMobilePlatform)
		{
			if (Application.isEditor)
			{
				OnDeepLinkActivated(testMobileLaunchURI);
			}
			else
			{
				Application.deepLinkActivated += OnDeepLinkActivated;
			}
		}
		else if (!Application.isEditor)
		{
			var args = GetCommandLineArgs();

			if (args.TryGetValue("-network", out string mlapiValue))
			{
				switch (mlapiValue)
				{
					case "server":
						launchType = NetworkType.Server;
						break;
					case "client":
						launchType = NetworkType.Client;
						break;
				}

				Debug.Log("Network mode set to " + launchType.ToString());
			}
#if !PRODUCTION_CLIENT
			if (args.ContainsKey("-local"))
			{
				isLocal = true;
				Debug.Log("Set to local");
			}
#endif

			if (args.TryGetValue("-solo", out soloMapPath))
			{
				launchType = NetworkType.Host;
				isSolo = true;
				Debug.Log("Launching in solo mode");
			}

			if (launchType == NetworkType.Client)
			{
				if (args.TryGetValue("-token", out string token))
				{
					clientToken = token;
				}
				else if (isLocal && args.TryGetValue("-userid", out string uid))
				{
					if (!int.TryParse(uid, out localUserId))
					{
						Debug.LogError("User ID in invalid format");
						Application.Quit();
					}
					else
					{
						isLocal = true;
						Debug.Log("Local user ID set to " + localUserId);
					}
				}
				else
				{
					Application.OpenURL("https://polytoria.com/places");
					Application.Quit();
				}
			}
			else if (launchType == NetworkType.Server)
			{
				if (args.TryGetValue("-token", out string token))
				{
					serverToken = token;
				}
				else if (isLocal)
				{
#if !PRODUCTION_CLIENT
					if (args.TryGetValue("-gameid", out string gid))
					{
						if (!int.TryParse(gid, out localGameId))
						{
							Debug.LogError("Game ID in invalid format");
							Application.Quit();
						}
						else
						{
							Debug.Log("Starting local server with gameID " + localGameId);
						}
					}
					else if (args.TryGetValue("-gamefile", out localMapPath))
					{
						Debug.Log("Starting local server with map file " + localMapPath);
					}
					else
					{
						Debug.LogError("Local server map parameters missing");
						Application.Quit();
					}
#else
                    Application.Quit();
                    return;
#endif
				}
				else
				{
					Debug.LogError("No valid launch parameters, quitting...");
					Application.Quit();
				}
			}
		}
		else
		{
			if (doPlaySolo)
			{
				launchType = NetworkType.Host;
				isSolo = true;
				soloMapPath = Path.GetFullPath(playSoloTestMap);
				clientToken = testToken;
				soloUserName = playSoloTestUserName;
				soloUserID = playSoloTestUserID;
			}
			else
			{
				launchType = editorLaunchType;

				if (launchType == NetworkType.Client)
				{
					if (doLocal)
					{
#if PRODUCTION_CLIENT
                        Application.Quit();
                        return;
#else
						localUserId = testLocalUserId;
						isLocal = true;
#endif
					}
					else
					{
						clientToken = testToken;
					}

				}
				else if (launchType == NetworkType.Server)
				{
#if PRODUCTION_CLIENT
                    Application.Quit();
                    return;
#else
					if (doLocal)
					{
						localGameId = testLocalGameId;
						localMapPath = testLocalMapPath;
						isLocal = true;
					}
					else
					{
						serverToken = testToken;
					}

#endif
				}
			}
		}

		SceneManager.LoadScene("MainGameScene");
	}

	public void LaunchAs(NetworkType netType, string token)
	{
		if (netType == NetworkType.Client)
		{
			clientToken = token;
		}
		else
		{
			serverToken = token;
		}

		SceneManager.LoadScene("MainScene");
	}

	private Dictionary<string, string> GetCommandLineArgs()
	{
		Dictionary<string, string> argDictionary = new Dictionary<string, string>();

		var args = System.Environment.GetCommandLineArgs();

		for (int i = 0; i < args.Length; ++i)
		{
			var arg = args[i];
			if (arg.StartsWith("-"))
			{
				var value = i < args.Length - 1 ? args[i + 1] : null;
				value = (value?.StartsWith("-") ?? false) ? null : value;

				argDictionary.Add(arg, value);
			}
		}
		return argDictionary;
	}

	private void OnDeepLinkActivated(string uri)
	{
		string url = Application.isEditor ? testMobileLaunchURI : Application.absoluteURL;

		if (url.StartsWith("polytoria://"))
		{
			string[] args = url.Replace("polytoria://", "").Split('/');
			string token = args[1];
			LaunchAs(NetworkType.Client, token);
		}
		else
		{
			Application.OpenURL("https://polytoria.com/places");
			Application.Quit();
		}
	}
}

public enum NetworkType
{
	Host = 0,
	Server,
	Client
}
