using System.Collections;
using Mirror;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

/*
	Documentation: https://mirror-networking.gitbook.io/docs/components/network-authenticators
	API Reference: https://mirror-networking.com/docs/api/Mirror.NetworkAuthenticator.html
*/

public class PTAuthenticator : NetworkAuthenticator
{
	#region Messages

	public struct AuthRequestMessage : NetworkMessage
	{
		public string clientToken;
		public int localUserId;
	}

	public struct AuthResponseMessage : NetworkMessage
	{
		public byte code;
		public string message;
		public int instanceCount;
	}

	#endregion

	#region Server

	/// <summary>
	/// Called on server from StartServer to initialize the Authenticator
	/// <para>Server message handlers should be registered in this method.</para>
	/// </summary>
	public override void OnStartServer()
	{
		// register a handler for the authentication request we expect from client
		NetworkServer.RegisterHandler<AuthRequestMessage>(OnAuthRequestMessage, false);
	}

	/// <summary>
	/// Called on server from OnServerConnectInternal when a client needs to authenticate
	/// </summary>
	/// <param name="conn">Connection to client.</param>
	public override void OnServerAuthenticate(NetworkConnectionToClient conn) { }

	/// <summary>
	/// Called on server when the client's AuthRequestMessage arrives
	/// </summary>
	/// <param name="conn">Connection to client.</param>
	/// <param name="msg">The message payload</param>
	public void OnAuthRequestMessage(NetworkConnectionToClient conn, AuthRequestMessage msg)
	{
		StartCoroutine(ValidateToken(conn, msg));
	}

	public IEnumerator ValidateToken(NetworkConnectionToClient conn, AuthRequestMessage msg)
	{
		AuthResponseMessage authResponseMessage = new AuthResponseMessage();
		authResponseMessage.instanceCount = Game.singleton.instanceCount;
		bool approve = false;
		JSONNode tokenData = null;

		if (!LaunchController.isSolo && !LaunchController.isLocal)
		{
			WWWForm form = new WWWForm();
			form.AddField("token", msg.clientToken);

			using UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/game/server/validate", form);
			uwr.SetRequestHeader("Authorization", LaunchController.serverToken);
			yield return uwr.SendWebRequest();

			if (uwr.result == UnityWebRequest.Result.Success)
			{
				tokenData = JSON.Parse(uwr.downloadHandler.text);
				Debug.Log("BRUHHHH");
				Debug.Log(tokenData);

				approve = true;
				authResponseMessage.code = 100;
				authResponseMessage.message = "Success";

			}
			else
			{
				Debug.LogError("200 Authentication Failed: " + uwr.error);

				authResponseMessage.code = 200;
				authResponseMessage.message = "Authentication Failed";
			}
		}
		else
		{
			Debug.Log("Show me the car fax");
			approve = true;
			authResponseMessage.code = 100;
			authResponseMessage.message = "Success";

			if (LaunchController.isLocal)
			{
				Debug.Log("Maury went local Z0mg");
				using UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/users/find?id=" + msg.localUserId);
				yield return uwr.SendWebRequest();

				if (uwr.result == UnityWebRequest.Result.Success)
				{
					tokenData = JSON.Parse(uwr.downloadHandler.text)["user"];
					Debug.Log(tokenData); // get polytorias acc
				}
				else
				{
					Debug.Log("HUH");
					tokenData = JSON.Parse("{\"id\": 1,\"username\": \"Error in PTAuthenticator.cs\"}");
				}
			}
			else
			{
				//Debug.Log()
				Debug.Log("YES");
				tokenData = JSON.Parse("{\"id\": 1,\"username\": \"Polytoria\"}");
				Debug.Log(tokenData);
			}
		}

		conn.Send(authResponseMessage);

		if (approve)
		{
			Debug.Log("TEST");
			Debug.Log(msg.clientToken);
			PTNetworkManager.instance.AddUserForConnID(conn.connectionId, new AuthUserData(tokenData["id"], tokenData["username"], msg.clientToken));
			ServerAccept(conn);
		}
		else
		{
			ServerReject(conn);
			StartCoroutine(DelayedDisconnect(conn, 1));
		}
	}

	public IEnumerator DelayedDisconnect(NetworkConnectionToClient conn, float waitTime)
	{
		yield return new WaitForSeconds(waitTime);
		conn.Disconnect();
	}

	#endregion

	#region Client

	/// <summary>
	/// Called on client from StartClient to initialize the Authenticator
	/// <para>Client message handlers should be registered in this method.</para>
	/// </summary>
	public override void OnStartClient()
	{
		// register a handler for the authentication response we expect from server
		NetworkClient.RegisterHandler<AuthResponseMessage>(OnAuthResponseMessage, false);
	}

	/// <summary>
	/// Called on client from OnClientConnectInternal when a client needs to authenticate
	/// </summary>
	public override void OnClientAuthenticate()
	{
		LoadScreenController.singleton.SetStatus("Authenticating");
		AuthRequestMessage authRequestMessage = new AuthRequestMessage
		{
			clientToken = LaunchController.clientToken,
			localUserId = 1
			//localUserId = LaunchController.localUserId // only used locally
		};
		NetworkClient.Send(authRequestMessage);
	}

	/// <summary>
	/// Called on client when the server's AuthResponseMessage arrives
	/// </summary>
	/// <param name="msg">The message payload</param>
	public void OnAuthResponseMessage(AuthResponseMessage msg)
	{
		if (msg.code == 100)
		{
			ClientAccept();
			LoadScreenController.singleton.IsLoadingMap = true;
			LoadScreenController.singleton.InstanceCount = msg.instanceCount;
		}
		else
		{
			Debug.LogError(msg.message + " (ID=" + msg.code + ")");
			LoadScreenController.singleton.SetStatus("Authentication failed: " + msg.message);
			//HudController.singleton.ShowDisconnectMessage(msg.message + " (ID=" + msg.code + ")");
		}
	}

	#endregion
}
