using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Mirror;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

/*
	Documentation: https://mirror-networking.gitbook.io/docs/components/network-manager
	API Reference: https://mirror-networking.com/docs/api/Mirror.NetworkManager.html
*/

public class PTNetworkManager : NetworkManager
{
	Dictionary<int, AuthUserData> playerConnData = new Dictionary<int, AuthUserData>();
	Dictionary<int, Player> playerPrefabs = new Dictionary<int, Player>();
	public static PTNetworkManager instance;

	[Range(1f, 60f)]
	[SerializeField] float serverHeartbeatRate = 10f;

	[Range(1, 100)]
	[SerializeField] int maxServerTimeout = 6;

	int emptyServerPings = 0;

	/// <summary>
	/// Runs on both Server and Client
	/// Networking is NOT initialized when this fires
	/// </summary>
	public override void Awake()
	{
		instance = this;
		playerPrefab = Resources.Load<GameObject>("Datamodel/Player");
		base.Awake();
	}

	#region Unity Callbacks

	public override void OnValidate()
	{
		base.OnValidate();
	}

	/// <summary>
	/// Runs on both Server and Client
	/// Networking is NOT initialized when this fires
	/// </summary>
	public override void Start()
	{
		base.Start();
	}

	/// <summary>
	/// Runs on both Server and Client
	/// </summary>
	public override void LateUpdate()
	{
		base.LateUpdate();
	}

	/// <summary>
	/// Runs on both Server and Client
	/// </summary>
	public override void OnDestroy()
	{
		base.OnDestroy();
	}

	#endregion

	#region Start & Stop

	/// <summary>
	/// Set the frame rate for a headless server.
	/// <para>Override if you wish to disable the behavior or set your own tick rate.</para>
	/// </summary>
	public override void ConfigureHeadlessFrameRate()
	{
		base.ConfigureHeadlessFrameRate();
	}

	/// <summary>
	/// called when quitting the application by closing the window / pressing stop in the editor
	/// </summary>
	public override void OnApplicationQuit()
	{
		base.OnApplicationQuit();
	}

	#endregion

	#region Scene Management

	/// <summary>
	/// This causes the server to switch scenes and sets the networkSceneName.
	/// <para>Clients that connect to this server will automatically switch to this scene. This is called automatically if onlineScene or offlineScene are set, but it can be called from user code to switch scenes again while the game is in progress. This automatically sets clients to be not-ready. The clients must call NetworkClient.Ready() again to participate in the new scene.</para>
	/// </summary>
	/// <param name="newSceneName"></param>
	public override void ServerChangeScene(string newSceneName)
	{
		base.ServerChangeScene(newSceneName);
	}

	/// <summary>
	/// Called from ServerChangeScene immediately before SceneManager.LoadSceneAsync is executed
	/// <para>This allows server to do work / cleanup / prep before the scene changes.</para>
	/// </summary>
	/// <param name="newSceneName">Name of the scene that's about to be loaded</param>
	public override void OnServerChangeScene(string newSceneName) { }

	/// <summary>
	/// Called on the server when a scene is completed loaded, when the scene load was initiated by the server with ServerChangeScene().
	/// </summary>
	/// <param name="sceneName">The name of the new scene.</param>
	public override void OnServerSceneChanged(string sceneName) { }

	/// <summary>
	/// Called from ClientChangeScene immediately before SceneManager.LoadSceneAsync is executed
	/// <para>This allows client to do work / cleanup / prep before the scene changes.</para>
	/// </summary>
	/// <param name="newSceneName">Name of the scene that's about to be loaded</param>
	/// <param name="sceneOperation">Scene operation that's about to happen</param>
	/// <param name="customHandling">true to indicate that scene loading will be handled through overrides</param>
	public override void OnClientChangeScene(string newSceneName, SceneOperation sceneOperation, bool customHandling) { }

	/// <summary>
	/// Called on clients when a scene has completed loaded, when the scene load was initiated by the server.
	/// <para>Scene changes can cause player objects to be destroyed. The default implementation of OnClientSceneChanged in the NetworkManager is to add a player object for the connection if no player object exists.</para>
	/// </summary>
	public override void OnClientSceneChanged()
	{
		base.OnClientSceneChanged();
	}

	#endregion

	#region Server System Callbacks

	/// <summary>
	/// Called on the server when a new client connects.
	/// <para>Unity calls this on the Server when a Client connects to the Server. Use an override to tell the NetworkManager what to do when a client connects to the server.</para>
	/// </summary>
	/// <param name="conn">Connection from client.</param>
	public override void OnServerConnect(NetworkConnectionToClient conn) { }

	/// <summary>
	/// Called on the server when a client is ready.
	/// <para>The default implementation of this function calls NetworkServer.SetClientReady() to continue the network setup process.</para>
	/// </summary>
	/// <param name="conn">Connection from client.</param>
	public override void OnServerReady(NetworkConnectionToClient conn)
	{
		base.OnServerReady(conn);
	}

	/// <summary>
	/// Called on the server when a client adds a new player with ClientScene.AddPlayer.
	/// <para>The default implementation for this function creates a new player object from the playerPrefab.</para>
	/// </summary>
	/// <param name="conn">Connection from client.</param>
	public override void OnServerAddPlayer(NetworkConnectionToClient conn)
	{
		Transform startPos = SpawnpointController.GetSpawnPosition();

		GameObject player = startPos != null
			? Instantiate(playerPrefab, startPos.position + Vector3.up * 5f, startPos.rotation)
			: Instantiate(playerPrefab);

		player.name = $"Player [connId={conn.connectionId}]";
		Player p = player.GetComponent<Player>();
		NetworkServer.AddPlayerForConnection(conn, player);
		playerPrefabs.Add(conn.connectionId, p);
		string token = "unknown";

		if (!LaunchController.isSolo)
		{
			AuthUserData udat = GetUserDataFromConnID(conn.connectionId);
			p.Name = udat.Username;
			p.SetUserID(udat.ID);
			token = udat.Token;

			foreach (KeyValuePair<int, Player> kvp in playerPrefabs)
			{
				if (kvp.Key == conn.connectionId)
					continue;

				if (kvp.Value.UserID == p.UserID)
				{
					kvp.Value.Kick("You have been kicked because you logged in from another location.");
					break;
				}
			}

			ClientConnected(p.UserID);
		}
		else
		{
			if (Application.isEditor && (LaunchController.soloUserName != string.Empty || LaunchController.soloUserID != 0))
			{
				p.Name = LaunchController.soloUserName;
				p.SetUserID(LaunchController.soloUserID);
			}
			else
			{
				p.Name = "Player";
				//p.SetUserID(1144); // Player
				p.SetUserID(5); // Dummy
			}
		}

		Backpack backpack = Instantiate(Resources.Load<Backpack>("Datamodel/Backpack"), p.transform);
		backpack.name = "Backpack";
		NetworkServer.Spawn(backpack.gameObject);

		p.SetLoaded(token);
	}

	/// <summary>
	/// Called on the server when a client disconnects.
	/// <para>This is called on the Server when a Client disconnects from the Server. Use an override to decide what should happen when a disconnection is detected.</para>
	/// </summary>
	/// <param name="conn">Connection from client.</param>
	public override void OnServerDisconnect(NetworkConnectionToClient conn)
	{
#if !PRODUCTION_CLIENT
		if (playerPrefabs.TryGetValue(conn.connectionId, out Player player))
		{
			ClientDisconnected(player.UserID);
			playerConnData.Remove(conn.connectionId);
			playerPrefabs.Remove(conn.connectionId);
		}

		if (NetworkServer.connections.Count == 0)
		{
			ShutdownServer();
		}
#endif
		base.OnServerDisconnect(conn);
	}

	/// <summary>
	/// Called on server when transport raises an exception.
	/// <para>NetworkConnection may be null.</para>
	/// </summary>
	/// <param name="conn">Connection of the client...may be null</param>
	/// <param name="exception">Exception thrown from the Transport.</param>
	public override void OnServerError(NetworkConnectionToClient conn, TransportError transportError, string message) { }

	#endregion

	#region Client System Callbacks

	/// <summary>
	/// Called on the client when connected to a server.
	/// <para>The default implementation of this function sets the client as ready and adds a player. Override the function to dictate what happens when the client connects.</para>
	/// </summary>
	public override void OnClientConnect()
	{
		base.OnClientConnect();
	}

	/// <summary>
	/// Called on clients when disconnected from a server.
	/// <para>This is called on the client when it disconnects from the server. Override this function to decide what happens when the client disconnects.</para>
	/// </summary>
	public override void OnClientDisconnect()
	{
		base.OnClientDisconnect();
		if (!Player.kicked)
			UIController.singleton.ShowDisconnectMessage("You have lost connection to the server.");
	}

	/// <summary>
	/// Called on clients when a servers tells the client it is no longer ready.
	/// <para>This is commonly used when switching scenes.</para>
	/// </summary>
	public override void OnClientNotReady() { }

	/// <summary>
	/// Called on client when transport raises an exception.</summary>
	/// </summary>
	/// <param name="exception">Exception thrown from the Transport.</param>
	public override void OnClientError(TransportError transportError, string message) { }

	#endregion

	#region Start & Stop Callbacks

	// Since there are multiple versions of StartServer, StartClient and StartHost, to reliably customize
	// their functionality, users would need override all the versions. Instead these callbacks are invoked
	// from all versions, so users only need to implement this one case.

	/// <summary>
	/// This is invoked when a host is started.
	/// <para>StartHost has multiple signatures, but they all cause this hook to be called.</para>
	/// </summary>
	public override void OnStartHost() { }

	/// <summary>
	/// This is invoked when a server is started - including when a host is started.
	/// <para>StartServer has multiple signatures, but they all cause this hook to be called.</para>
	/// </summary>
	public override void OnStartServer()
	{
		if (CreatorController.IsCreator) return;

		if (!LaunchController.isSolo)
		{
			StartCoroutine(HeartbeatLoop());
		}
	}

	public void ClientConnected(int userID)
	{
		Dictionary<string, string> data = new Dictionary<string, string>();
		data.Add("userID", userID.ToString());

		StartCoroutine(LogEvent(ServerEventType.ClientConnected, data));
	}

	public void ClientDisconnected(int userID)
	{
		Dictionary<string, string> data = new Dictionary<string, string>();
		data.Add("userID", userID.ToString());

		StartCoroutine(LogEvent(ServerEventType.ClientDisconnected, data));
	}

	public void ShutdownServer()
	{
		StartCoroutine(LogEvent(ServerEventType.ServerStopped, null, true));
	}

	IEnumerator LogEvent(ServerEventType eventType, Dictionary<string, string> data = null, bool shutdownOnComplete = false)
	{
		if (LaunchController.isSolo || LaunchController.isLocal) yield break;
#if !PRODUCTION_CLIENT
		string eventName = eventType.ToString();
		eventName = char.ToLower(eventName[0]) + eventName.Substring(1);

		WWWForm form = new WWWForm();
		form.AddField("eventType", eventName);

		if (data != null)
		{
			foreach (KeyValuePair<string, string> row in data)
			{
				form.AddField(row.Key, row.Value);
			}
		}

		using (UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/game/server/event", form))
		{
			uwr.SetRequestHeader("Authorization", LaunchController.serverToken);
			yield return uwr.SendWebRequest();

			Debug.Log("Sent server event " + eventType.ToString() + ", status = " + uwr.responseCode + " data = " + uwr.downloadHandler.text);
		}

		if (shutdownOnComplete == true)
		{
			Application.Quit();
		}
#endif
	}

	IEnumerator HeartbeatLoop()
	{
		if (LaunchController.isLocal) yield break;

		while (true)
		{
			if (numPlayers == 0)
			{
				if (emptyServerPings >= maxServerTimeout)
				{
					Debug.Log("No players, shutting down.");
					ShutdownServer();
					yield break;
				}
				else
				{
					emptyServerPings++;
				}
			}
			else
			{
				emptyServerPings = 0;
			}

			// JSONNode data = new JSONObject();
			// JSONNode players = new JSONArray();
			// foreach (int userID in PTNetworkManager.instance.GetConnectedUserIDs()) {
			// 	players.Add(userID);
			// }
			// players.Add(0);
			// data.Add("players", players);
			// Debug.Log("Sending " + data.ToString());

			List<int> playerIDs = new List<int>(PTNetworkManager.instance.GetConnectedUserIDs());
			// List<int> playerIDs = new List<int> {
			// 	1,2,3,4,5
			// };

			using (UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/game/server/heartbeat", "[" + string.Join(",", playerIDs) + "]", "application/json"))
			{
				uwr.SetRequestHeader("Authorization", LaunchController.serverToken);
				uwr.SetRequestHeader("Accept", "application/json");
				yield return uwr.SendWebRequest();

				JSONNode response = JSON.Parse(uwr.downloadHandler.text);

				foreach (JSONNode removeNode in response["remove"])
				{
					if (removeNode.IsNumber)
					{
						int removeID = removeNode.AsInt;
						Debug.Log("Removing player " + removeID);
						Player plr = Game.singleton.FindChildOfType<Players>().GetPlayerByID(removeID);

						if (plr != null)
						{
							plr.Kick();
						}
					}
				}

				Debug.Log("Players in game: " + numPlayers);
			}

			yield return new WaitForSeconds(serverHeartbeatRate);
		}
	}

	enum ServerEventType
	{
		ServerStarted,
		ServerStopped,
		ClientConnected,
		ClientDisconnected
	}

	/// <summary>
	/// This is invoked when the client is started.
	/// </summary>
	public override void OnStartClient() { }

	/// <summary>
	/// This is called when a host is stopped.
	/// </summary>
	public override void OnStopHost() { }

	/// <summary>
	/// This is called when a server is stopped - including when a host is stopped.
	/// </summary>
	public override void OnStopServer() { }

	/// <summary>
	/// This is called when a client is stopped.
	/// </summary>
	public override void OnStopClient() { }

	#endregion

	public Player GetPlayerPrefab(int connId)
	{
		playerPrefabs.TryGetValue(connId, out Player player);
		return player;
	}

	public void AddUserForConnID(int connId, AuthUserData userData)
	{
		if (playerConnData.ContainsKey(connId))
		{
			playerConnData[connId] = userData;
		}
		else
		{
			playerConnData.Add(connId, userData);
		}
	}

	public AuthUserData GetUserDataFromConnID(int connId)
	{
		playerConnData.TryGetValue(connId, out AuthUserData data);

		return data;
	}

	public List<int> GetConnectedUserIDs()
	{
		return playerConnData.Values.Select(i => i.ID).ToList();
	}
}

public struct AuthUserData
{
	public int ID { get; set; }
	public string Username { get; set; }
	public string Token { get; set; }
	public AuthUserData(int id, string username, string token)
	{
		ID = id;
		Username = username;
		Token = token;
	}
}
