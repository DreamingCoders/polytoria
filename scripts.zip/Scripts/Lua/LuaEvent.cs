using System.Collections.Generic;
using MoonSharp.Interpreter;

public class LuaEvent
{
	List<DynValue> callbacks;

	public LuaEvent()
	{
		callbacks = new List<DynValue>();
	}

	public void Connect(DynValue func)
	{
		if (!callbacks.Contains(func)) callbacks.Add(func);
	}

	public void Disconnect(DynValue func)
	{
		if (callbacks.Contains(func)) callbacks.Remove(func);
	}

	[MoonSharpHidden]
	public void Invoke(params object[] par)
	{
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();
		List<DynValue> cb = new List<DynValue>(callbacks); // copy to prevent exception

		if (ss != null)
		{
			foreach (DynValue func in cb)
			{
				ss.CallFunc(func, par);
			}
		}
	}
}
