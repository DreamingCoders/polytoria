using System.Linq;
using SimpleJSON;
public class LuaJSON
{
	public static JSONNode Parse(string aJSON)
	{
		return JSON.Parse(aJSON);
	}

	public static JSONNode[] GetChildrenAsArray(JSONNode json)
	{
		return json.Children.ToArray();
	}
}
