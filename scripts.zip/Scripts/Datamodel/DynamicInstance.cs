using System;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;

public class DynamicInstance : Instance
{
	public float transformSendInterval;
	protected event Action TransformChanged;
	protected virtual bool DoTransformSync => lifetime < 0.5f || SyncMode == SyncMode.ForceSync;
	Rigidbody _rb;
	bool syncPhysics;

	[MoonSharpHidden] public SyncMode SyncMode { get; set; }
	[SyncVar(hook = nameof(SyncSetPosition))] Vector3 position;
	[SyncVar(hook = nameof(SyncSetRotation))] Vector3 rotation;
	[SyncVar(hook = nameof(SyncSetSize))] Vector3 size;


	[SerializeField] bool syncVelocity = true;
	[SerializeField] float velocitySensitivity = 0.1f;
	[SerializeField] bool syncAngularVelocity = true;
	[SerializeField] float angularVelocitySensitivity = 0.1f;

	protected float lifetime = 0f;

	[CreatorProperty, Archivable]
	public Vector3 Position
	{
		get => transform.position;
		set
		{
			transform.position = position = value;
			TransformChanged?.Invoke();
		}
	}

	[CreatorProperty, Archivable]
	public Vector3 Rotation
	{
		get => transform.eulerAngles;
		set
		{
			transform.eulerAngles = rotation = value;
			TransformChanged?.Invoke();
		}
	}

	[CreatorProperty, Archivable]
	public Vector3 LocalPosition
	{
		get => transform.localPosition;
		set
		{
			transform.localPosition = value;
			position = transform.position;
			TransformChanged?.Invoke();
		}
	}

	[CreatorProperty, Archivable]
	public Vector3 LocalRotation
	{
		get => transform.localEulerAngles;
		set
		{
			transform.localEulerAngles = value;
			rotation = transform.eulerAngles;
			TransformChanged?.Invoke();
		}
	}

	const float MIN_SIZE = 0.01f;

	[CreatorProperty, Archivable]
	public Vector3 Size
	{
		get => transform.lossyScale;
		set
		{
			transform.localScale = Vector3.one;
			transform.localScale = Vector3.Max(new Vector3(MIN_SIZE, MIN_SIZE, MIN_SIZE), new Vector3(Mathf.Abs(value.x / transform.lossyScale.x), Mathf.Abs(value.y / transform.lossyScale.y), Mathf.Abs(value.z / transform.lossyScale.z)));
			size = value;
			TransformChanged?.Invoke();
		}
	}

	[CreatorProperty, Archivable]
	public Vector3 LocalSize
	{
		get => transform.localScale;
		set
		{
			transform.localScale = value;
			size = transform.lossyScale;
			TransformChanged?.Invoke();
		}
	}

	public Vector3 Forward => transform.forward;
	public Vector3 Right => transform.right;
	public Vector3 Up => transform.up;

	double lastServerSendTime;

	[SyncVar(hook = nameof(OnVelocityChanged))]
	Vector3 _velocity;

	[SyncVar(hook = nameof(OnAngularVelocityChanged))]
	Vector3 _angularVelocity;

	[SyncVar(hook = nameof(OnIsKinematicChanged))]
	bool _isKinematic;

	[SyncVar(hook = nameof(OnUseGravityChanged))]
	bool _useGravity;

	[SyncVar(hook = nameof(OnuDragChanged))]
	float _drag;

	[SyncVar(hook = nameof(OnAngularDragChanged))]
	float _angularDrag;

	readonly ClientSyncState previousValue = new ClientSyncState();

	bool IgnoreSync => isServer;

	Vector3 lastPos, lastRot, lastSize;

	void OnVelocityChanged(Vector3 _, Vector3 newValue)
	{
		if (IgnoreSync)
			return;

		_rb.velocity = newValue;
	}


	void OnAngularVelocityChanged(Vector3 _, Vector3 newValue)
	{
		if (IgnoreSync)
			return;

		_rb.angularVelocity = newValue;
	}

	void OnIsKinematicChanged(bool _, bool newValue)
	{
		if (IgnoreSync)
			return;

		_rb.isKinematic = newValue;
	}

	void OnUseGravityChanged(bool _, bool newValue)
	{
		if (IgnoreSync)
			return;

		_rb.useGravity = newValue;
	}

	void OnuDragChanged(float _, float newValue)
	{
		if (IgnoreSync)
			return;

		_rb.drag = newValue;
	}

	void OnAngularDragChanged(float _, float newValue)
	{
		if (IgnoreSync)
			return;

		_rb.angularDrag = newValue;
	}

	protected override void Awake()
	{
		base.Awake();

		_rb = GetComponent<Rigidbody>();

		if (_rb)
		{
			syncPhysics = true;
		}
	}

	protected override void Start()
	{
		base.Start();

		if (CreatorController.IsCreator) return;

		if (!isServer)
		{
			Position = position;
			Rotation = rotation;
			Size = size;
		}
	}

	protected virtual void Update()
	{
		if (CreatorController.IsCreator) return;
		lifetime += Time.deltaTime;

		if (SyncMode != SyncMode.None)
		{
			if (DoTransformSync)
			{
				if (lastPos != Position || lastRot != Rotation || lastSize != Size)
				{
					UpdateTransform();
					lastPos = Position;
					lastRot = Rotation;
					lastSize = Size;
				}

				lastServerSendTime = NetworkTime.localTime;
			}
		}
	}

	#region network sync
	void SyncPhysics()
	{
		Vector3 currentVelocity = syncVelocity ? _rb.velocity : default;
		Vector3 currentAngularVelocity = syncAngularVelocity ? _rb.angularVelocity : default;

		bool velocityChanged = syncVelocity && ((previousValue.velocity - currentVelocity).sqrMagnitude > velocitySensitivity * velocitySensitivity);
		bool angularVelocityChanged = syncAngularVelocity && ((previousValue.angularVelocity - currentAngularVelocity).sqrMagnitude > angularVelocitySensitivity * angularVelocitySensitivity);

		if (velocityChanged)
		{
			_velocity = currentVelocity;
			previousValue.velocity = currentVelocity;
		}

		if (angularVelocityChanged)
		{
			_angularVelocity = currentAngularVelocity;
			previousValue.angularVelocity = currentAngularVelocity;
		}

		_isKinematic = _rb.isKinematic;
		_useGravity = _rb.useGravity;
		_drag = _rb.drag;
		_angularDrag = _rb.angularDrag;
	}

	void UpdateTransform()
	{
		if ((isClient && !netIdentity.isOwned) || (isServer && netIdentity.connectionToClient != null)) return;

		if (syncPhysics)
			SyncPhysics();

		position = Position;
		rotation = Rotation;
		size = Size;

		if (isServer)
		{
			RpcSyncTransform(transform.position, transform.rotation, transform.localScale);
		}
		else
		{
			CmdSyncTransform(transform.position, transform.rotation, transform.localScale);
		}
	}

	[MoonSharpHidden]
	public void SyncTransformRecursively()
	{
		if (isServer)
		{
			foreach (DynamicInstance inst in GetChildrenOfType<DynamicInstance>())
			{
				UpdateTransform();
				inst.SyncTransformRecursively();
			}
		}
	}

	[ClientRpc(includeOwner = false)]
	protected void RpcSyncTransform(Vector3 position, Quaternion rotation, Vector3 size)
	{
		if (netIdentity.isOwned) return;
		transform.position = position;
		transform.rotation = rotation;
		transform.localScale = size;
	}

	[Command(requiresAuthority = false)]
	protected void CmdSyncTransform(Vector3 position, Quaternion rotation, Vector3 size, NetworkConnectionToClient sender = null)
	{
		if (sender == netIdentity.connectionToClient)
		{
			transform.position = position;
			transform.rotation = rotation;
			transform.localScale = size;

			RpcSyncTransform(position, rotation, size);
		}
	}

	void SyncSetPosition(Vector3 oldPosition, Vector3 position)
	{
		Position = position;
	}

	void SyncSetRotation(Vector3 oldRotation, Vector3 rotation)
	{
		Rotation = rotation;
	}

	void SyncSetSize(Vector3 oldSize, Vector3 size)
	{
		Size = size;
	}

	[Command(requiresAuthority = false)]
	void CmdRequestTransform(NetworkConnectionToClient sender = null)
	{
		SetTransformTargetRpc(sender, Position, Rotation, Size);
	}

	[TargetRpc]
	void SetTransformTargetRpc(NetworkConnection target, Vector3 position, Vector3 rotation, Vector3 scale)
	{
		Position = position;
		Rotation = rotation;
		Size = scale;
	}

	[ClientRpc(includeOwner = false)]
	protected void RpcSyncPosition(Vector3 position)
	{
		transform.position = position;
	}

	[ClientRpc(includeOwner = false)]
	protected void RpcSyncRotation(Quaternion rotation)
	{
		transform.rotation = rotation;
	}
	#endregion

	#region scripting api

	public void LookAt(Vector3 target, Vector3 worldUp)
	{
		transform.LookAt(target, worldUp);
		Rotation = transform.rotation.eulerAngles;
	}

	public void LookAt(Vector3 target)
	{
		LookAt(target, Vector3.up);
	}

	public void LookAt(DynamicInstance target)
	{
		LookAt(target.Position);
	}

	public void Translate(Vector3 translation)
	{
		transform.Translate(translation);
	}

	#endregion
}

public class ClientSyncState
{
	public float nextSyncTime;
	public Vector3 velocity;
	public Vector3 angularVelocity;
	public bool isKinematic;
	public bool useGravity;
	public float drag;
	public float angularDrag;
}

public enum SyncMode
{
	Default,
	ForceSync,
	None
}
