using Mirror;
using UnityEngine;

namespace Polytoria.Datamodel
{
	public class PlayerGUI : Instance
	{
		CanvasGroup canvasGroup;
		[SyncVar(hook = nameof(SyncSetInteractable))] bool interactable = true;
		[SyncVar(hook = nameof(SyncSetOpacity))] float opacity = 1f;

		[Archivable, CreatorProperty]
		public bool Interactable
		{
			get => interactable;
			set
			{
				canvasGroup.interactable = interactable = value;
			}
		}

		[Archivable, CreatorProperty]
		public float Opacity
		{
			get => opacity;
			set
			{
				canvasGroup.alpha = opacity = value;
			}
		}

		private void SyncSetInteractable(bool oldValue, bool newValue)
		{
			Interactable = newValue;
		}

		private void SyncSetOpacity(float oldValue, float newValue)
		{
			Opacity = newValue;
		}

		protected override void Awake()
		{
			canvasGroup = GetComponent<CanvasGroup>();
			canReparent = false;
			base.Awake();
		}

		protected override void Start()
		{
			base.Start();
		}

	}
}