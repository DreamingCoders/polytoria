public class LocalScript : BaseScript
{

}
