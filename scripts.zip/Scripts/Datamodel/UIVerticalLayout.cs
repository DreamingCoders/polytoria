using UnityEngine;
using UnityEngine.UI;

namespace Polytoria.Datamodel
{
	public class UIVerticalLayout : UIHVLayout
	{
		protected override void Awake()
		{
			base.Awake();
			layoutGroup = GetComponent<VerticalLayoutGroup>();
		}

		public override Instance Clone()
		{
			UIVerticalLayout clone = (UIVerticalLayout) New("UIVerticalLayout", Parent);

			try
			{
				clone.Name = Name;
				clone.PositionOffset = PositionOffset;
				clone.PositionRelative = PositionRelative;
				clone.SizeOffset = SizeOffset;
				clone.SizeRelative = SizeRelative;
				clone.Rotation = Rotation;
				clone.PivotPoint = PivotPoint;
				clone.Visible = Visible;
				clone.Spacing = Spacing;
				clone.ChildControlWidth = ChildControlWidth;
				clone.ChildControlHeight = ChildControlHeight;
				clone.ChildScaleWidth = ChildScaleWidth;
				clone.ChildScaleHeight = ChildScaleHeight;
				clone.ChildForceExpandWidth = ChildForceExpandWidth;
				clone.ChildForceExpandHeight = ChildForceExpandHeight;
				clone.PaddingLeft = PaddingLeft;
				clone.PaddingRight = PaddingRight;
				clone.PaddingTop = PaddingTop;
				clone.PaddingBottom = PaddingBottom;
				clone.ChildAlignment = ChildAlignment;
				clone.ReverseAlignment = ReverseAlignment;

				foreach (Instance child in GetChildren())
				{
					Instance childClone = child.Clone();
					childClone.Parent = clone;
				}
			}
			catch (System.Exception e)
			{
				Debug.LogError(e);
			}

			return clone;
		}
	}
}
