using Mirror;
using UnityEngine;

public class ColorValue : ValueBase
{
	[SyncVar] Color val;

	[Archivable, CreatorProperty]
	public Color Value
	{
		get => val;
		set
		{
			val = value;
			InvokeChanged();
		}
	}

	public override Instance Clone()
	{
		ColorValue clone = (ColorValue) New("ColorValue");

		clone.Parent = Parent;
		clone.Name = Name;
		clone.Value = Value;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
