using Mirror;
using UnityEngine;
using UnityEngine.EventSystems;

namespace Polytoria.Datamodel
{
	public class UIField : Instance, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
	{
		public LuaEvent MouseUp = new LuaEvent();
		public LuaEvent MouseDown = new LuaEvent();

		[SyncVar(hook = nameof(SyncSetPositionOffset))] Vector2 positionOffset = Vector2.zero;
		[SyncVar(hook = nameof(SyncSetSizeOffset))] Vector2 sizeOffset = new Vector2(100, 100);
		[SyncVar(hook = nameof(SyncSetPositionRelative))] Vector2 positionRelative = new Vector2(0.5f, 0.5f);
		[SyncVar(hook = nameof(SyncSetSizeRelative))] Vector2 sizeRelative = Vector2.zero;
		[SyncVar(hook = nameof(SyncSetRotation))] float rotation = 0;
		[SyncVar(hook = nameof(SyncSetPivotPoint))] Vector2 pivotPoint = new Vector2(0.5f, 0.5f);
		[SyncVar(hook = nameof(SyncSetVisible))] bool visible = true;

		private RectTransform parentRect;
		private RectTransform recttransform;
		[CreatorProperty, Archivable]
		public Vector2 PositionOffset
		{
			get => positionOffset;
			set => positionOffset = value;
		}
		[CreatorProperty, Archivable]
		public Vector2 PositionRelative
		{
			get => positionRelative;
			set => positionRelative = value;
		}

		[CreatorProperty, Archivable]
		public float Rotation
		{
			get => transform.eulerAngles.z;
			set
			{
				rotation = value;
				transform.eulerAngles = new Vector3(0, 0, rotation);
			}
		}
		[CreatorProperty, Archivable]
		public Vector2 SizeOffset
		{
			get => sizeOffset;
			set => sizeOffset = value;
		}
		[CreatorProperty, Archivable]
		public Vector2 SizeRelative
		{
			get => sizeRelative;
			set => sizeRelative = value;
		}
		[CreatorProperty, Archivable]
		public Vector2 PivotPoint
		{
			get => recttransform?.pivot ?? new Vector2(0.5f, 0.5f);
			set
			{
				recttransform.pivot = pivotPoint = value;
			}
		}

		[CreatorProperty, Archivable]
		public bool Visible
		{
			get => visible;
			set
			{
				visible = value;
				isHidden = !visible;
				if (visible)
				{
					OnShow();
				}
				else
				{
					OnHide();
				}
			}
		}

		void SyncSetPositionOffset(Vector2 oldValue, Vector2 newValue)
		{
			PositionOffset = newValue;
		}
		void SyncSetSizeOffset(Vector2 oldValue, Vector2 newValue)
		{
			SizeOffset = newValue;
		}
		void SyncSetPositionRelative(Vector2 oldValue, Vector2 newValue)
		{
			PositionRelative = newValue;
		}
		void SyncSetSizeRelative(Vector2 oldValue, Vector2 newValue)
		{
			SizeRelative = newValue;
		}
		void SyncSetRotation(float oldValue, float newValue)
		{
			Rotation = newValue;
		}
		void SyncSetPivotPoint(Vector2 oldValue, Vector2 newValue)
		{
			PivotPoint = newValue;
		}
		void SyncSetVisible(bool oldValue, bool newValue)
		{
			Visible = newValue;
		}

		protected override void Awake()
		{
			base.Awake();
			recttransform = GetComponent<RectTransform>();
			this._ParentChanged += () =>
			{
				parentRect = transform.parent.GetComponent<RectTransform>();
			};
		}

		protected override void Start()
		{
			base.Start();
		}

		void Update()
		{
			if (parentRect != null)
			{
				if (!(Parent is UIHVLayout))
				{
					recttransform.anchoredPosition = positionRelative * ((RectTransform) transform.parent).rect.size + positionOffset;
				}
				recttransform.sizeDelta = sizeRelative * ((RectTransform) transform.parent).rect.size + sizeOffset;

			}
		}

		protected override void OnHide()
		{
			base.OnHide();
		}

		protected override void OnShow()
		{
			base.OnShow();
		}

		public override Instance Clone()
		{
			UIField clone = (UIField) New("UIField", Parent);
			try
			{
				clone.Name = Name;
				clone.PositionOffset = PositionOffset;
				clone.PositionRelative = PositionRelative;
				clone.SizeOffset = SizeOffset;
				clone.SizeRelative = SizeRelative;
				clone.Rotation = Rotation;
				clone.PivotPoint = PivotPoint;
				clone.Visible = Visible;

				foreach (Instance child in GetChildren())
				{
					Instance childClone = child.Clone();
					childClone.Parent = clone;
				}
			}
			catch (System.Exception e)
			{
				Debug.LogError(e);
			}
			return clone;
		}

		public void OnPointerEnter(PointerEventData eventData)
		{
			MouseEnter.Invoke();
		}

		public void OnPointerExit(PointerEventData eventData)
		{
			MouseExit.Invoke();
		}

		public void OnPointerUp(PointerEventData eventData)
		{
			MouseUp.Invoke();
		}

		public void OnPointerDown(PointerEventData eventData)
		{
			MouseDown.Invoke();
		}

	}
}