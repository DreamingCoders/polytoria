using Mirror;
using UnityEngine;

public class RemoteEvent : Instance
{
	/* Support for object[] later bc this Fucking Stinks */
	public LuaEvent Invoked = new LuaEvent();

	public override Instance Clone()
	{
		RemoteEvent clone = (RemoteEvent) New("RemoteEvent");

		clone.Parent = Parent;
		clone.Name = Name;

		foreach (Instance instance in GetChildren())
		{
			Instance clonedChild = instance.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}

	public void Invoke(string val)
	{
		CmdInvokeString(val);
	}

	public void Invoke(bool val)
	{
		CmdInvokeBool(val);
	}

	public void Invoke(float val)
	{
		CmdInvokeFloat(val);
	}

	public void Invoke(int val)
	{
		CmdInvokeInt(val);
	}

	public void Invoke(Vector3 val)
	{
		CmdInvokeVec3(val);
	}

	public void Invoke(Color val)
	{
		CmdInvokeColor(val);
	}

	public void Invoke(Instance val)
	{
		CmdInvokeInstance(val);
	}

	[Command(requiresAuthority = false)]
	void CmdInvokeString(string val, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		Invoked?.Invoke(player, val);
	}

	[Command(requiresAuthority = false)]
	void CmdInvokeBool(bool val, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		Invoked?.Invoke(player, val);
	}

	[Command(requiresAuthority = false)]
	void CmdInvokeFloat(float val, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		Invoked?.Invoke(player, val);
	}

	[Command(requiresAuthority = false)]
	void CmdInvokeInt(int val, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		Invoked?.Invoke(player, val);
	}

	[Command(requiresAuthority = false)]
	void CmdInvokeVec3(Vector3 val, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		Invoked?.Invoke(player, val);
	}

	[Command(requiresAuthority = false)]
	void CmdInvokeColor(Color val, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		Invoked?.Invoke(player, val);
	}

	[Command(requiresAuthority = false)]
	void CmdInvokeInstance(Instance val, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		Invoked?.Invoke(player, val);
	}
}
