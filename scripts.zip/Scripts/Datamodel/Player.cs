using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Mirror;
using MoonSharp.Interpreter;
using SimpleJSON;
using TMPro;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.EventSystems;
using UnityEngine.Networking;
using UnityEngine.UI;

[RequireComponent(typeof(ParentConstraint))]
public class Player : Instance
{
	public static bool kicked = false;
	static readonly int maxRequestsPerMin = 60;
	static readonly int hatCheckCacheLength = 300;
	private readonly System.Array keyCodes = System.Enum.GetValues(typeof(KeyCode));

	ParentConstraint parentConstraint;

	float maxHealth = 100f;
	float health;
	[SyncVar] float walkSpeed = 16f;
	[SyncVar] float sprintSpeed = 25f;
	[SerializeField] bool isSprinting = false;
	[SerializeField] bool sprintExhausted = false;
	[SerializeField][SyncVar] bool staminaEnabled = true;
	[SerializeField][SyncVar] float stamina = 0f;
	[SerializeField][SyncVar] float maxStamina = 3f;
	[SerializeField][SyncVar] float staminaRegen = 1.2f;
	[SerializeField] float jumpPower = 36f;
	[SyncVar] float respawnTime = 5f;
	[SyncVar] int userID;
	[SyncVar] bool loaded = false;
	[SyncVar] bool isCreator = false;
	[SyncVar] bool isAdmin = false;
	[SyncVar] Color chatColor = Color.white;
	[SyncVar] string avatarHash;
	[SyncVar] bool canMove = true;
	[SyncVar] public string LeaderboardBadgeId;

	[SerializeField] float turnSmoothing = 10f;
	[SerializeField] LayerMask ignoreLayer;

	[SerializeField] Animator anim;
	[SerializeField] Rigidbody rb;
	[SerializeField] List<MeshRenderer> disableOnFP;
	[SerializeField] List<Rigidbody> deathBodyParts;
	[SerializeField] Transform toolAttachPoint;
	[SerializeField] Transform camAttachment;

	Collider col;
	PhysicMaterial airMaterial, groundMaterial;
	Dictionary<Rigidbody, Vector3> defaultBodyPartPos = new Dictionary<Rigidbody, Vector3>();
	Transform headObj, leftArmObj, rightArmObj, torsoObj, leftLegObj, rightLegObj, tshirtObj;
	NetworkAnimator netAnim;

	public float maxStepHeight = 1.2f;
	public float stepSearchOvershoot = 0.01f;

	private List<ContactPoint> allCPs = new List<ContactPoint>();
	private Vector3 lastVelocity;
	private float afkTimer;
	private float maxAfkTime = 60 * 15f;

	bool isDead = false;
	float jumpCooldown = 0f;
	float currentSpeed;

	Transform rightArmPivot;
	TMP_Text nametag;

	[MoonSharpHidden]
	public bool IsLocalPlayer
	{
		get => isLocalPlayer || LaunchController.isSolo;
	}

	[SyncVar] Seat sittingIn;

	[MoonSharpHidden] public bool IsLoaded => loaded;

	[CreatorProperty]
	public float RespawnTime
	{
		get => respawnTime;
		set
		{
			respawnTime = value;
			if (isServer)
			{
				RpcSetRespawnTime(value);
			}
		}
	}
	public Vector3 Velocity
	{
		get => rb.velocity;
		set
		{
			Debug.Log("Setting velocity to " + value);
			rb.velocity = rb.velocity = value;
		}

	}

	[CreatorProperty]
	public float MaxHealth
	{
		get => maxHealth;
		set
		{
			maxHealth = value;

			if (isServer)
			{
				RpcSetMaxHealth(value);
			}
		}
	}

	[CreatorProperty]
	public float Health
	{
		get => health;
		set
		{
			health = value;

			if (isServer)
			{
				RpcSetHealth(value);
			}
			else
			{
				if (isLocalPlayer)
					CmdSetHealth(value);
			}
		}
	}

	[CreatorProperty]
	public float WalkSpeed
	{
		get => walkSpeed;
		set
		{
			value = Mathf.Clamp(value, 0.01f, 1000f);
			if (currentSpeed == walkSpeed)
				currentSpeed = value;
			walkSpeed = value;

			if (isServer)
			{
				RpcSetWalkSpeed(value);
			}
		}
	}

	[CreatorProperty]
	public float SprintSpeed
	{
		get => sprintSpeed;
		set
		{
			sprintSpeed = value;
			if (isServer)
			{
				RpcSetSprintSpeed(sprintSpeed);
			}
		}
	}
	[CreatorProperty]
	public bool StaminaEnabled
	{
		get => staminaEnabled;
		set
		{
			staminaEnabled = value;
			if (isServer)
			{
				RpcSetStaminaEnabled(staminaEnabled);
			}
		}
	}
	[CreatorProperty]
	public float Stamina
	{
		get => stamina;
		set
		{
			stamina = value;
			if (isServer)
			{
				RpcSetStamina(stamina);
			}
		}
	}
	[CreatorProperty]
	public float MaxStamina
	{
		get => maxStamina;
		set
		{
			maxStamina = value;
			if (isServer)
			{
				RpcSetMaxStamina(maxStamina);
			}
		}
	}
	[CreatorProperty]
	public float StaminaRegen
	{
		get => staminaRegen;
		set
		{
			staminaRegen = value;
			if (isServer)
			{
				RpcSetStaminaRegen(staminaRegen);
			}
		}
	}

	[CreatorProperty]
	public float JumpPower
	{
		get => jumpPower;
		set
		{
			jumpPower = value;
			if (isServer)
			{
				RpcSetJumpPower(value);
			}
		}
	}

	[CreatorProperty]
	public Vector3 Position
	{
		get => transform.position;
		set
		{
			if (SittingIn != null) Unsit(false);
			transform.position = value;
			if (isServer) SetTransformAttrTargetRpc("Position", value);
		}
	}

	[CreatorProperty]
	public Vector3 Rotation
	{
		get => transform.eulerAngles;
		set
		{
			transform.eulerAngles = value;
			if (isServer) SetTransformAttrTargetRpc("Rotation", value);
		}
	}

	public Color ChatColor
	{
		get => chatColor;
		set
		{
			chatColor = value;
			if (isServer)
				RpcSetChatColor(value);
		}
	}
	public bool CanMove
	{
		get => canMove;
		set
		{
			canMove = value;
			if (isServer)
				RpcSetCanMove(value);
		}
	}

	public bool IsInputFocused
	{
		get
		{
			return
			UIController.singleton.ChatBar.isFocused ||
			ScreenshotController.instance.Focused ||
			(EventSystem.current?.currentSelectedGameObject?.GetComponent<Polytoria.Datamodel.UITextInput>() != null);
		}
	}

	public string AvatarHash => avatarHash;

	public Seat SittingIn => sittingIn;
	public Vector3 Forward => transform.forward;
	public Vector3 Right => transform.right;
	public bool IsAdmin => isAdmin;
	public bool IsCreator => isCreator;

	[CreatorProperty]
	public int UserID
	{
		get => userID;
		private set => userID = value;
	}

	public LuaEvent Chatted = new LuaEvent();
	public LuaEvent Died = new LuaEvent();
	public LuaEvent Respawned = new LuaEvent();


	Dictionary<int, bool> assetOwnCache = new Dictionary<int, bool>();
	Dictionary<int, int> assetCacheCheckTimes = new Dictionary<int, int>();

	static Dictionary<int, int> assetCheckCounts = new Dictionary<int, int>();

	float defaultFov, sprintFov;
	Camera cam;

	[MoonSharpHidden] public Transform ToolAttachmentPoint => toolAttachPoint;

	protected override void Start()
	{
		base.Start();

		rb = GetComponent<Rigidbody>();
		col = GetComponent<Collider>();
		anim = GetComponent<Animator>();
		netAnim = GetComponent<NetworkAnimator>();
		parentConstraint = GetComponent<ParentConstraint>();

		parentConstraint.enabled = false;

		headObj = transform.Find("Head");
		torsoObj = transform.Find("Torso");
		leftArmObj = transform.Find("Left Arm Pivot").Find("Left Arm");
		rightArmObj = transform.Find("Right Arm Pivot").Find("Right Arm");
		leftLegObj = transform.Find("Left Leg Pivot").Find("Left Leg");
		rightLegObj = transform.Find("Right Leg Pivot").Find("Right Leg");

		rightArmPivot = transform.Find("Right Arm Pivot");

		tshirtObj = transform.Find("Torso").Find("T-Shirt");
		nametag = transform.Find("Nametag").GetComponent<TMP_Text>();

		if (isClient)
			AppearanceController.Instance.AddPlayerToQueue(this);


		rb.isKinematic = true;

		Health = MaxHealth;
		Stamina = MaxStamina;

		if (!IsLocalPlayer)
		{
			return;
		}

		cam = CameraController.instance.GetComponent<Camera>();

		airMaterial = Resources.Load<PhysicMaterial>("Materials/Physics/PlayerAerial");
		groundMaterial = Resources.Load<PhysicMaterial>("Materials/Physics/PlayerGrounded");

		foreach (Rigidbody p in deathBodyParts)
		{
			defaultBodyPartPos.Add(p, p.transform.localPosition);
			MeshCollider c = p.gameObject.AddComponent<MeshCollider>();
			c.convex = true;
			c.enabled = false;
			c.material = groundMaterial;
		}

		SetChildLayers(transform, LayerMask.NameToLayer("LocalPlayer"));
		CameraController.instance.SetTarget(transform.Find("CameraAttachment"));
		CameraController.instance.disableOnFirstPerson.AddRange(disableOnFP);
		currentSpeed = walkSpeed;
		defaultFov = Camera.main.fieldOfView;
		sprintFov = defaultFov + 10f;

		UIController.singleton.Resetted += () => { Health = 0f; };

		UIController.singleton.ChatBar.onSubmit.AddListener(delegate
		{
			if (!UICommandList.IsActive || UICommandList.ActiveCommand == null || UICommandList.ActiveCommandFilled || UIController.singleton.ChatBar.text.Contains(" "))
			{
				EventSystem.current.SetSelectedGameObject(null);
				SendChat();
			}

		});

		StartCoroutine(PostPlayerLoad());

		if (!isServer)
		{
			if (Game.singleton.isGameLoaded)
			{
				rb.isKinematic = false;
				LoadScreenController.singleton.GameLoaded();
			}
			else
			{
				Game.GameLoadedLocally += () => { rb.isKinematic = false; LoadScreenController.singleton.GameLoaded(); };
			}
		}
		else
		{
			rb.isKinematic = false;
		}
	}

	[MoonSharpHidden]
	public void PlayAnim(string _anim)
	{
		string n = null;

		switch (_anim)
		{
			case "slash":
				n = "toolSlash";
				break;
			case "drink":
				n = "drink";
				break;
			case "eat":
				n = "eat";
				break;
		}

		if (n != null)
			anim.Play(n);
	}

	[TargetRpc, MoonSharpHidden]
	public void PlayAnimTargetRpc(string _anim)
	{
		PlayAnim(_anim);
	}

	void SetChildLayers(Transform root, LayerMask layer)
	{
		root.gameObject.layer = layer;
		foreach (Transform child in root)
		{
			SetChildLayers(child, layer);
		}
	}

	IEnumerator PostPlayerLoad()
	{
		while (Game.singleton.FindChildOfType<Players>() == null)
		{
			yield return new WaitForEndOfFrame();
		}

		Game.singleton.FindChildOfType<Players>().SetLocalPlayer(this);

		while (Game.singleton.FindChildOfType<Players>().GetPlayers().Length == 0)
		{
			yield return new WaitForEndOfFrame();
		}

		foreach (Player player in FindObjectsOfType<Player>())
		{
			if (player.Name != Name)
				UIController.singleton.AddLeaderboardUser(player);
		}

		while (Game.singleton.FindChildOfType<ScriptService>() == null)
		{
			yield return new WaitForEndOfFrame();
		}

		Game.singleton.FindChildOfType<ScriptService>().RunLocalScripts();
		UIController.singleton.SetUserCard(UserID, Name);

		if (!LaunchController.isSolo)
		{
			Discord.Activity ac = DiscordController.Instance.Activity;
			ac.Details = "Playing as " + Name;
			ac.Party.Size = new Discord.PartySize { CurrentSize = Game.singleton.FindChildOfType<Players>().GetChildrenOfType<Player>().Length, MaxSize = PTNetworkManager.singleton.maxConnections };
			DiscordController.Instance.UpdateActivity(ac);

			StartCoroutine(DiscordLoop());
		}

		PlayerDefaults pd = Game.singleton.FindChildOfType<PlayerDefaults>();

		if (pd != null)
		{
			pd.LoadDefaults(this);
		}

		if (isServer)
		{
			Respawned?.Invoke();
		}
		else
		{
			NotifyJoin();
		}
	}

	IEnumerator DiscordLoop()
	{
		while (true)
		{
			Discord.Activity ac = DiscordController.Instance.Activity;
			ac.Party.Size = new Discord.PartySize { CurrentSize = Game.singleton.FindChildOfType<Players>().GetChildrenOfType<Player>().Length, MaxSize = PTNetworkManager.singleton.maxConnections };
			DiscordController.Instance.UpdateActivity(ac);
			yield return new WaitForSeconds(30f);
		}
	}

	[Command]
	void NotifyJoin()
	{
		Respawned?.Invoke();
	}

	public void OwnsItem(int assetId, DynValue callOnComplete)
	{
		if (assetOwnCache.ContainsKey(assetId))
		{
			if (assetCacheCheckTimes.ContainsKey(assetId))
			{
				assetCacheCheckTimes.TryGetValue(assetId, out int time);

				if (time + hatCheckCacheLength < System.DateTime.Now.Second)
				{
					assetOwnCache.TryGetValue(assetId, out bool ownsItem);
					((ScriptService) Game.singleton.FindChildByClass("ScriptService")).CallFunc(callOnComplete, true, ownsItem);
				}
				else
				{
					StartCoroutine(CheckOwnsItemFromAPI(assetId, callOnComplete));
				}
			}
			else
			{
				StartCoroutine(CheckOwnsItemFromAPI(assetId, callOnComplete));
			}
		}
		else
		{
			StartCoroutine(CheckOwnsItemFromAPI(assetId, callOnComplete));
		}
	}

	private bool climbing = false;

	void OnCollisionStay(Collision col)
	{
		allCPs.AddRange(col.contacts);

		if (col.gameObject.GetComponent<Instance>() is Climbable)
		{
			climbing = true;
		}
		else
		{
			climbing = false;
		}
	}
	protected override void OnCollisionExit(Collision col)
	{
		if (col.gameObject.GetComponent<Instance>() is Climbable)
		{
			climbing = false;
		}

		if (!IsLocalPlayer) return;
		GameObject other = col.gameObject;
		Instance i = other.GetComponent<Instance>();
		if (i != null)
		{
			TouchEnded?.Invoke(i);

			if (!isServer)
			{
				CmdTouchEnded(i.gameObject);
			}
		}
	}

	bool FindGround(out ContactPoint groundCP, List<ContactPoint> allCPs)
	{
		groundCP = default;
		bool found = false;
		foreach (ContactPoint cp in allCPs)
		{
			if (cp.normal.y > 0.0001f && (found == false || cp.normal.y > groundCP.normal.y))
			{
				groundCP = cp;
				found = true;
			}
		}

		return found;
	}

	bool FindStep(out Vector3 stepUpOffset, List<ContactPoint> allCPs, ContactPoint groundCP, Vector3 currVelocity)
	{
		stepUpOffset = default;

		Vector2 velocityXZ = new Vector2(currVelocity.x, currVelocity.z);
		if (velocityXZ.sqrMagnitude < 0.0001f)
			return false;

		foreach (ContactPoint cp in allCPs)
		{
			bool test = ResolveStepUp(out stepUpOffset, cp, groundCP);
			if (test)
				return test;
		}
		return false;
	}

	bool ResolveStepUp(out Vector3 stepUpOffset, ContactPoint stepTestCP, ContactPoint groundCP)
	{
		stepUpOffset = default;
		Collider stepCol = stepTestCP.otherCollider;

		if (Mathf.Abs(stepTestCP.normal.y) >= 0.01f)
		{
			return false;
		}

		if (!(stepTestCP.point.y - groundCP.point.y < maxStepHeight))
		{
			return false;
		}

		float stepHeight = groundCP.point.y + maxStepHeight + 0.0001f;
		Vector3 stepTestInvDir = new Vector3(-stepTestCP.normal.x, 0, -stepTestCP.normal.z).normalized;
		Vector3 origin = new Vector3(stepTestCP.point.x, stepHeight, stepTestCP.point.z) + (stepTestInvDir * stepSearchOvershoot);
		Vector3 direction = Vector3.down;
		if (!(stepCol.Raycast(new Ray(origin, direction), out RaycastHit hitInfo, maxStepHeight)))
		{
			return false;
		}

		Vector3 stepUpPoint = new Vector3(stepTestCP.point.x, hitInfo.point.y + 0.0001f, stepTestCP.point.z) + (stepTestInvDir * stepSearchOvershoot);
		Vector3 stepUpPointOffset = stepUpPoint - new Vector3(stepTestCP.point.x, groundCP.point.y, stepTestCP.point.z);

		stepUpOffset = stepUpPointOffset;
		return true;
	}

	[MoonSharpHidden]
	public void SetLoaded(string authToken)
	{
		if (!isServer) return;
		loaded = true;
		StartCoroutine(LoadMetadata(authToken));
	}

	IEnumerator LoadMetadata(string authToken)
	{
		if (!isServer) yield break;
		if (LaunchController.isSolo || LaunchController.isLocal) yield break;

		WWWForm form = new WWWForm();
		form.AddField("token", authToken);

		using (UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/game/server/player", form))
		{
			uwr.SetRequestHeader("Authorization", LaunchController.serverToken);
			yield return uwr.SendWebRequest();

			if (uwr.result == UnityWebRequest.Result.Success)
			{
				JSONNode data = JSON.Parse(uwr.downloadHandler.text);

				isCreator = data["isCreator"];
				isAdmin = data["isAdmin"];
				avatarHash = data["avatar"];
				LeaderboardBadgeId = data["badge"];
				ColorUtility.TryParseHtmlString(data["chatColor"], out chatColor);
			}
		}
	}

	IEnumerator CheckOwnsItemFromAPI(int assetId, DynValue callOnComplete)
	{
		ScriptService ss = (ScriptService) Game.singleton.FindChildByClass("ScriptService");
		int minute = (int) System.DateTimeOffset.Now.ToUnixTimeSeconds() / 60;
		if (assetCheckCounts.ContainsKey(minute))
		{
			if (assetCheckCounts[minute] >= maxRequestsPerMin)
			{
				ss.CallFunc(callOnComplete, false, false);
				yield break;
			}
			assetCheckCounts[minute]++;
		}
		else
		{
			assetCheckCounts.Add(minute, 1);
		}
		using UnityWebRequest uwr = UnityWebRequest.Get($"https://api.polytoria.com/v1/asset/owner?userID={UserID}&assetID={assetId}");
		yield return uwr.SendWebRequest();

		if (uwr.result == UnityWebRequest.Result.Success)
		{
			var json = JSON.Parse(uwr.downloadHandler.text);
			bool owns = json["Success"];

			if (assetOwnCache.ContainsKey(assetId))
			{
				assetOwnCache[assetId] = owns;
			}
			else
			{
				assetOwnCache.Add(assetId, owns);
			}

			if (assetCacheCheckTimes.ContainsKey(assetId))
			{
				assetCacheCheckTimes[assetId] = (int) System.DateTimeOffset.Now.ToUnixTimeSeconds();
			}
			else
			{
				assetCacheCheckTimes.Add(assetId, (int) System.DateTimeOffset.Now.ToUnixTimeSeconds());
			}

			ss.CallFunc(callOnComplete, false, owns);
		}
		else
		{
			ss.CallFunc(callOnComplete, true, false);
		}
	}


	private bool isEmote = false;
	void SendChat()
	{
		ChatWindow.instance.SetInactive();
		EventSystem.current.SetSelectedGameObject(null);
		string message = UIController.singleton.ChatBar.text;

		message = message.Trim();
		if (message == "/dance")
		{
			isEmote = true;
			anim.Play("dance-0");
			return;
		}
		if (message == "/wave")
		{
			isEmote = true;
			anim.Play("wave");
			return;
		}
		if (message == "/helicopter")
		{
			isEmote = true;
			anim.Play("dance-1");
			return;
		}
		if (message == "/scream")
		{
			anim.Play("scream", 2);
			StartCoroutine(StopScream());
			return;
		}
		if (message == "/tpose")
		{
			isEmote = true;
			anim.Play("tpose");
			return;
		}
		if (message == "/sit")
		{
			isEmote = true;
			anim.Play("sit");
			return;
		}
		if (message == "/point")
		{
			isEmote = true;
			anim.Play("point");
			return;
		}
		if (message.Length > 0)
		{
			ChatService.instance.SendChat(message);
			UIController.singleton.ChatBar.text = "";
		}
	}

	IEnumerator StopScream()
	{
		yield return new WaitForSeconds(5f);
		anim.CrossFade("empty", 0.2f, 2);
	}

	private void Update()
	{
		if (isServer)
		{
			if (transform.parent == null)
			{
				Players players = (Players) Game.singleton.FindChildByClass("Players");

				if (players != null)
				{
					players.AddPlayer(this);
				}
			}
			//Continue update logic if acting as a local client
			if (!LaunchController.isSolo)
				return;
		}

		if (!IsLocalPlayer)
		{
			nametag.text = Name;
			nametag.transform.rotation = Quaternion.LookRotation(nametag.transform.position - Camera.main.transform.position);
			return;
		}

		if (!LaunchController.isSolo && !isServer)
		{
			if (afkTimer > maxAfkTime)
			{
				this.Kick("You have been kicked from the server for being inactive for too long.");
				return;
			}

			afkTimer += Time.deltaTime;

			if (Input.anyKey)
			{
				afkTimer = 0;
			}
		}

		string chatText = UIController.singleton.ChatBar.text;
		if (ChatWindow.instance.state != ChatWindowState.Inactive && UICommandList.IsActive && !UICommandList.ActiveCommandFilled && UICommandList.ActiveCommand != null && (!chatText.Contains(" ") && ((Input.GetKeyDown(KeyCode.Tab) || Input.GetKeyDown(KeyCode.Return)))))
		{
			UIController.singleton.ChatBar.text = "/" + UICommandList.ActiveCommand.CommandName;
			UICommandList.ActiveCommandFilled = true;
			EventSystem.current.SetSelectedGameObject(UIController.singleton.ChatBar.gameObject);
			UIController.singleton.ChatBar.Select();
			UIController.singleton.ChatBar.ActivateInputField();
			UIController.singleton.ChatBar.caretPosition = UIController.singleton.ChatBar.text.Length;
		}
		if (Input.GetKeyDown(KeyCode.Slash) && ChatWindow.instance.stateChangeCooldown > ChatWindow.instance.StateChangeRateLimit)
		{
			ChatWindow.instance.stateChangeCooldown = 0;
			UIController.singleton.ChatBar.Select();
			UIController.singleton.ChatBar.ActivateInputField();
			ChatWindow.instance.state = ChatWindowState.Focused;
		}

		if (Input.GetKeyDown(KeyCode.Backspace) && (EventSystem.current.currentSelectedGameObject == null || EventSystem.current.currentSelectedGameObject.GetComponent<InputField>() == null || EventSystem.current.currentSelectedGameObject.GetComponent<TMP_InputField>() == null))
		{
			DropTools();
		}

		if (IsAdmin || IsCreator || LaunchController.isSolo || LaunchController.isLocal)
		{
			if (EventSystem.current.currentSelectedGameObject == null && Input.GetKey(KeyCode.LeftShift) && Input.GetKeyDown(KeyCode.C))
			{
				CameraController.instance.Mode = CameraController.instance.Mode == CameraMode.Free ? CameraMode.FollowPlayer : CameraMode.Free;
			}
		}

		if (Position.y <= -100f)
		{
			Health = 0f;
		}

		if (Health <= 0f && !isDead)
		{
			Die();
		}

		jumpCooldown -= Time.deltaTime;

		bool grounded = IsGrounded() || climbing;
		anim.SetBool("grounded", Mathf.Abs(rb.velocity.y) < 20f && grounded);

		bool hasTool = FindChildOfType<Tool>() != null;
		anim.SetBool("holding", hasTool);

		if (!ChatWindow.instance.Focused && Input.GetButton("Jump") && jumpCooldown <= 0f)
		{
			if (grounded && canMove && !isDead && !IsInputFocused && CameraController.instance.Mode != CameraMode.Free)
			{
				col.material = airMaterial;
				rb.velocity = new Vector3(rb.velocity.x, 0f, rb.velocity.z);
				rb.AddForce(Vector3.up * jumpPower, ForceMode.Impulse);
				if (climbing)
				{
					rb.AddForce(transform.forward * -6, ForceMode.Impulse);
					climbing = false;
				}
				jumpCooldown = 0.1f;
				CmdJumpSound();
				DoJumpSound();
			}
			else if (sittingIn != null)
			{
				Unsit();
			}
		}

		isSprinting = !sprintExhausted && (stamina > 0) && !isDead && !IsInputFocused && (Input.GetKey(KeyCode.LeftShift) || Input.GetButton("Sprint")) && (Input.GetAxisRaw("Vertical") != 0f || Input.GetAxisRaw("Horizontal") != 0f) && CameraController.instance.Mode != CameraMode.Free;
		if (stamina <= 0)
		{
			sprintExhausted = true;
		}

		if (isSprinting && staminaEnabled)
		{
			stamina = Mathf.Clamp(stamina - Time.deltaTime, 0, maxStamina);
			if (stamina <= 0)
			{
				stamina = 0;
			}
		}
		else
		{
			if (stamina < maxStamina)
			{
				stamina = Mathf.Clamp(stamina + Time.deltaTime * ((sprintExhausted) ? 0.8f : staminaRegen), 0, maxStamina);
			}
			else
				sprintExhausted = false;
		}

		anim.SetBool("running", isSprinting);

		if (isSprinting)
		{
			if (currentSpeed != sprintSpeed)
			{
				UpdateFov(true);
				currentSpeed = sprintSpeed;
			}
		}
		else
		{
			if (currentSpeed != walkSpeed)
			{
				currentSpeed = walkSpeed;
				UpdateFov(false);
			}
		}

		if (CameraController.instance.Mode != CameraMode.Free)
		{
			foreach (KeyCode keyCode in keyCodes)
			{
				if (Input.GetKeyDown(keyCode))
				{
					InputService.KeyDown?.Invoke(keyCode.ToString());
				}
				else if (Input.GetKeyUp(keyCode))
				{
					InputService.KeyUp?.Invoke(keyCode.ToString());
				}
			}
		}
		UIController.singleton.HealthbarHeartText.text = Mathf.Floor(Mathf.Max(Health, 0)).ToString();
		UIController.singleton.SetHealthFilled(Health / MaxHealth);
		UIController.singleton.SetStaminaFilled(Stamina / MaxStamina, sprintExhausted);

		if (Input.GetMouseButtonDown(0))
		{
			Tool t = FindChildOfType<Tool>();
			if (t) t.Activate();
		}
	}

	void Die()
	{
		isDead = true;
		if (sittingIn != null)
			Unsit();

		StartCoroutine(DoDie());
		CmdDied();
	}

	[Command]
	void CmdDied()
	{
		Backpack bp = FindChildOfType<Backpack>();

		foreach (Tool t in GetChildrenOfType<Tool>())
		{
			if (bp)
				t.Parent = bp;
		}

		DoDropTools();

		if (bp)
		{
			foreach (Tool tool in bp.GetChildrenOfType<Tool>())
			{
				if (tool.Droppable)
					tool.Destroy();
			}
		}

		Died?.Invoke();

		RpcSetAnimatorActive(false);
	}

	void DropTools()
	{
		Tool t = FindChildOfType<Tool>();
		if (t)
		{
			Physics.IgnoreCollision(t.GetComponent<Collider>(), col, false);
		}
		CmdDropTools();
	}

	[Command]
	void CmdDropTools()
	{
		DoDropTools();
	}

	void DoDropTools()
	{
		Tool t = FindChildOfType<Tool>();
		if (t && t.Droppable)
		{
			t.Parent = Game.singleton.FindChildOfType<Environment>();
			Physics.IgnoreCollision(t.GetComponent<Collider>(), col, false);
		}
	}

	[Command, MoonSharpHidden]
	public void EquipTool(Tool tool)
	{
		Tool currentlyHolding = FindChildOfType<Tool>();
		if (currentlyHolding != null)
		{
			currentlyHolding.Parent = FindChildOfType<Backpack>();
			if (tool == currentlyHolding)
			{
				return;
			}
		}

		if (tool.Parent == FindChildOfType<Backpack>())
		{
			tool.Parent = this;
		}
	}

	[ClientRpc]
	void RpcSetAnimatorActive(bool active)
	{
		if (anim != null && netAnim != null)
		{
			anim.enabled = active;
			netAnim.enabled = active;
		}
	}

	[TargetRpc, MoonSharpHidden]
	public void SetTransformAttrTargetRpc(string attr, Vector3 value)
	{
		switch (attr)
		{
			case "Position":
				transform.position = value;
				break;
			case "Rotation":
				transform.eulerAngles = value;
				break;
		}
	}

	IEnumerator DoDie()
	{

		if (CameraController.instance.Distance == 0)
			CameraController.instance.Distance = 15f;

		camAttachment.localPosition = Vector3.zero;
		camAttachment.SetParent(headObj, false);


		CameraController.instance.MinDistance = 5f;
		anim.enabled = false;
		foreach (Rigidbody bp in deathBodyParts)
		{
			bp.isKinematic = false;
			bp.velocity = rb.velocity;
			bp.GetComponent<Collider>().enabled = true;
		}

		yield return new WaitForSeconds(respawnTime);
		Respawn();
	}

	[MoonSharpHidden]
	public void SetUserID(int userID)
	{
		if (!isServer) return;
		UserID = userID;
	}

	bool IsGrounded()
	{
		BoxCollider boxCol = (BoxCollider) col;
		List<Collider> cols = Physics.OverlapBox((boxCol.bounds.center) - (Vector3.up * 0.1f), new Vector3((boxCol.size.x - 0.01f) / 2, (boxCol.size.y / 2), (boxCol.size.z - 0.01f) / 2), rb.rotation, ~ignoreLayer).ToList();
		Debug.DrawRay(boxCol.bounds.center - (Vector3.up * boxCol.size.y / 2), -transform.up * .75f, Color.white);
		return cols.Where(i => !i.isTrigger).Count() > 0 && ((Mathf.Abs(rb.velocity.y) < 0.1f) || Physics.Raycast(boxCol.bounds.center - (Vector3.up * boxCol.size.y / 2), Vector3.down, .75f, ~ignoreLayer));
	}

	protected override void OnCollisionEnter(Collision collision)
	{
		if (!IsLocalPlayer) return;
		GameObject other = collision.gameObject;
		Instance i = other.GetComponent<Instance>();
		if (i != null)
		{
			Touched?.Invoke(i);

			if (!isServer)
			{
				CmdTouched(i.gameObject);
			}
		}
	}

	protected override void OnTriggerEnter(Collider collider)
	{
		if (!IsLocalPlayer) return;
		GameObject other = collider.gameObject;
		Instance i = other.GetComponent<Instance>();
		if (i != null)
		{
			Touched?.Invoke(i);
			if (!isServer)
			{
				CmdTouched(i.gameObject);
			}
		}
	}

	protected override void OnTriggerExit(Collider collider)
	{
		if (!IsLocalPlayer) return;
		GameObject other = collider.gameObject;
		Instance i = other.GetComponent<Instance>();
		if (i != null)
		{
			TouchEnded?.Invoke(i);
			if (!isServer)
			{
				CmdTouchEnded(i.gameObject);
			}
		}
	}

	[Command]
	void CmdTouched(GameObject other)
	{
		if (other == null) return;
		Instance i = other.GetComponent<Instance>();
		if (i)
		{
			Touched?.Invoke(i);
			i.Touched?.Invoke(this);
		}
	}

	[Command]
	void CmdTouchEnded(GameObject other)
	{
		if (other == null) return;
		Instance i = other.GetComponent<Instance>();
		if (i)
		{
			TouchEnded?.Invoke(i);
			i.TouchEnded?.Invoke(this);
		}
	}

	private void FixedUpdate()
	{
		if (!IsLocalPlayer) return;

		float hor = Input.GetAxisRaw("Horizontal");
		float ver = Input.GetAxisRaw("Vertical");

		if (UICommandList.IsActive || CameraController.instance.Mode == CameraMode.Free)
		{
			hor = ver = 0f;
		}

		if (IsGrounded())
		{
			if (jumpCooldown <= 0f)
				col.material = groundMaterial;

			rb.angularVelocity = Vector3.zero;
		}
		else
		{
			if (isDead)
				col.material = groundMaterial;
			else
				col.material = airMaterial;
		}

		if (canMove)
		{
			Move(hor, ver);
		}

		bool grounded = FindGround(out ContactPoint groundCP, allCPs);

		Vector3 stepUpOffset = Vector3.zero;
		bool stepUp = false;

		if (grounded)
		{
			try
			{
				stepUp = FindStep(out stepUpOffset, allCPs, groundCP, rb.velocity);
			}
			catch (Exception) { }
		}

		if (stepUp)
		{
			rb.position += stepUpOffset;
			rb.velocity = lastVelocity;
		}

		allCPs.Clear();
		lastVelocity = rb.velocity;

		// if (rb.velocity.magnitude >= 0.05f && isEmote) - Old

		if (rb.velocity.magnitude >= 0.05f && PressingMovementKeys() && isEmote)
		{
			isEmote = false;
			anim.CrossFade("idle", 0.2f);
		}
	}

	bool PressingMovementKeys()
	{
		if (Input.GetAxisRaw("Vertical") > 0 || Input.GetAxisRaw("Horizontal") > 0 || Input.GetAxisRaw("Vertical") < 0 || Input.GetAxisRaw("Horizontal") < 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	void UpdateFov(bool sprinting)
	{
		if (sprintSpeed == walkSpeed) return;

		if (sprinting)
		{
			LeanTween.value(defaultFov, sprintFov, 0.5f).setEase(LeanTweenType.easeOutExpo).setOnUpdate((fov) => Camera.main.fieldOfView = fov);
		}

		else
		{
			LeanTween.value(sprintFov, defaultFov, 0.5f).setEase(LeanTweenType.easeOutExpo).setOnUpdate((fov) => Camera.main.fieldOfView = fov);
		}
	}

	void Move(float hor, float ver)
	{
		if (isDead)
		{
			anim.SetBool("walking", false);
			return;
		}

		if (climbing)
		{
			hor = 0;
		}

		if (IsInputFocused || currentSpeed == 0f) hor = ver = 0f;


		Vector3 dir = Camera.main.transform.TransformDirection(new Vector3(hor, 0f, climbing ? Mathf.Abs(ver) : ver));
		dir.y = 0f;
		dir = dir.normalized * currentSpeed;

		anim.SetBool("walking", hor != 0f || ver != 0f);
		if (hor != 0f || ver != 0f || !IsGrounded())
			rb.velocity = new Vector3(dir.x, rb.velocity.y, dir.z);

		anim.SetBool("climbing", climbing);
		rb.useGravity = !climbing;
		if (climbing)
		{
			rb.velocity = new Vector3(rb.velocity.x, ver * 10, rb.velocity.z);
			anim.speed = Mathf.Abs(ver);
			return;
		}
		else
		{
			anim.speed = 1;
		}
		if (hor != 0f || ver != 0f || (CameraController.instance.IsFirstPerson || CameraController.instance.CtrlLocked))
		{
			Quaternion targetRotation;

			if (CameraController.instance.CtrlLocked || CameraController.instance.IsFirstPerson)
			{
				targetRotation = Quaternion.LookRotation(CameraController.instance.transform.forward, Vector3.up);
			}
			else
			{
				targetRotation = Quaternion.LookRotation(dir, Vector3.up);
			}

			Quaternion newRotation = Quaternion.Lerp(rb.rotation, Quaternion.Euler(new Vector3(0f, targetRotation.eulerAngles.y, 0f)), turnSmoothing * Time.deltaTime);
			rb.MoveRotation(newRotation);
		}
	}

	[Command]
	void CmdJumpSound()
	{
		RpcJumpSound();
	}

	[ClientRpc]
	void RpcJumpSound()
	{
		if (isLocalPlayer) return;
		DoJumpSound();
	}

	void DoJumpSound()
	{
		AudioSource audio = GetComponent<AudioSource>();
		audio.Stop();
		audio.time = 0f;
		audio.Play();
	}

	public void Kick(string reason = "You have been kicked from the server.")
	{
		if (isServer)
		{
			SendDisconnectMessageTargetRpc(reason);
			StartCoroutine(DelayedDisconnect());
		}
		else
		{
			kicked = true;
			UIController.singleton.ShowDisconnectMessage(reason);
			connectionToServer.Disconnect();
		}
	}

	IEnumerator DelayedDisconnect()
	{
		if (!isServer) yield break;
		yield return new WaitForEndOfFrame();
		connectionToClient.Disconnect();
	}

	[TargetRpc]
	void SendDisconnectMessageTargetRpc(string message)
	{
		kicked = true;
		UIController.singleton.ShowDisconnectMessage(message);
	}
	public void Sit(Seat seat)
	{
		if (SittingIn != null) return;
		if (seat.Occupant != null) return;

		while (parentConstraint.enabled && parentConstraint.sourceCount > 0)
			parentConstraint.RemoveSource(0);

		SetSittingIn(seat);

		CanMove = false;

		transform.position = seat.transform.position + (Vector3.up * (col.bounds.size.y / 2));

		rb.isKinematic = true;
		rb.constraints = RigidbodyConstraints.None;

		transform.rotation = seat.transform.rotation;

		anim.Play("sit");

		parentConstraint.AddSource(new ConstraintSource
		{
			sourceTransform = seat.transform.Find("SeatTransform"),
			weight = 1
		});

		parentConstraint.enabled = true;

		parentConstraint.translationOffsets = new Vector3[] { Vector3.up * 1.5f };

	}

	void UnsitTargetRpc(bool addForce)
	{
		Unsit(addForce);
	}

	public void Unsit(bool addForce = true)
	{
		if (isServer && !IsLocalPlayer)
		{
			UnsitTargetRpc(addForce);
			return;
		}

		if (SittingIn == null || !parentConstraint.enabled) return;

		SetSittingIn(null);

		rb.isKinematic = false;

		transform.eulerAngles = new Vector3(0f, transform.eulerAngles.y, 0f);
		rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;

		CanMove = true;

		anim.CrossFade("idle", 0.2f);

		while (parentConstraint.enabled && parentConstraint.sourceCount > 0)
			parentConstraint.RemoveSource(0);

		parentConstraint.enabled = false;
		rb.velocity = new Vector3(rb.velocity.x, 0f, rb.velocity.z);
		if (addForce)
			rb.AddForce(Vector3.up * JumpPower, ForceMode.Impulse);
		jumpCooldown = 0.1f;
	}

	[Command, MoonSharpHidden]
	public void CmdSetSittingIn(Seat seat)
	{
		SetSittingIn(seat);
	}

	void SetSittingIn(Seat seat)
	{
		if (isServer)
		{
			sittingIn?.SetOccupant(null);
			sittingIn = seat;

			if (seat != null)
				seat.SetOccupant(this);
		}
		else
		{
			CmdSetSittingIn(seat);
		}
	}

	[Command]
	void CmdNotifyRespawn()
	{
		RpcSetAnimatorActive(true);

		PlayerDefaults pd = Game.singleton.FindChildOfType<PlayerDefaults>();
		if (pd != null)
		{
			Backpack bp = pd.GetComponent<Backpack>();
			if (bp != null)
			{
				foreach (Tool tool in bp.GetChildrenOfType<Tool>())
				{
					Tool clone = (Tool) tool.Clone();
					clone.Parent = FindChildOfType<Backpack>();
				}
			}
		}

		Respawned?.Invoke();
	}

	public void Respawn()
	{
		isDead = false;
		if (!isServer)
		{
			CmdNotifyRespawn();
		}
		else
		{
			RpcSetAnimatorActive(true);
			Respawned?.Invoke();
		}
		try
		{
			transform.Find("Head/CameraAttachment").localPosition = new Vector3(0, 1.7f, 0);
			transform.Find("Head/CameraAttachment").SetParent(transform, false);
		}
		catch { }
		Health = MaxHealth;
		Stamina = MaxStamina;
		CameraController.instance.MinDistance = 0;

		Transform sp = SpawnpointController.GetSpawnPosition();
		if (sp == null)
		{
			Position = SpawnpointController.GetDefaultSpawnPosition();
			Rotation = Quaternion.identity.eulerAngles;
		}
		else
		{
			Position = sp.position + Vector3.up * 5f;
			Rotation = new Vector3(0f, sp.eulerAngles.y, 0f);
		}
		if (defaultBodyPartPos.Count != 0)
		{
			foreach (Rigidbody bp in deathBodyParts)
			{
				bp.GetComponent<Collider>().enabled = false;
				bp.isKinematic = true;
				bp.transform.localPosition = defaultBodyPartPos[bp];
				bp.transform.localRotation = Quaternion.identity;
			}

			anim.enabled = true;
		}

		rb.velocity = Vector3.zero;
		rb.angularVelocity = Vector3.zero;
	}

	[TargetRpc, MoonSharpHidden]
	public void TargetSetPosition(Vector3 pos)
	{
		transform.position = pos;
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();

		if (isServer)
			((Players) Game.singleton.FindChildByClass("Players"))?.NotifyPlayerDestroyed(this);
	}

	[ClientRpc]
	void RpcSetRespawnTime(float time)
	{
		if (isServer) return;
		RespawnTime = time;
	}

	[ClientRpc]
	void RpcSetMaxHealth(float maxHealth)
	{
		if (isServer) return;
		MaxHealth = maxHealth;
	}

	[ClientRpc]
	void RpcSetHealth(float health)
	{
		if (isServer) return;
		Health = health;
	}

	[Command]
	void CmdSetHealth(float health)
	{
		this.health = health;
	}

	[ClientRpc]
	void RpcSetWalkSpeed(float walkSpeed)
	{
		if (isServer) return;
		WalkSpeed = walkSpeed;
	}

	[ClientRpc]
	void RpcSetSprintSpeed(float sprintSpeed)
	{
		if (isServer) return;
		SprintSpeed = sprintSpeed;
	}
	[ClientRpc]
	void RpcSetMaxStamina(float val)
	{
		if (isServer) return;
		MaxStamina = val;
	}
	[ClientRpc]
	void RpcSetStamina(float val)
	{
		if (isServer) return;
		Stamina = val;
	}
	[ClientRpc]
	void RpcSetStaminaRegen(float val)
	{
		if (isServer) return;
		StaminaRegen = val;
	}
	[ClientRpc]
	void RpcSetStaminaEnabled(bool val)
	{
		if (isServer) return;
		StaminaEnabled = val;
	}

	[ClientRpc]
	void RpcSetJumpPower(float jumpPower)
	{
		if (isServer) return;
		JumpPower = jumpPower;
	}

	[ClientRpc]
	void RpcSetChatColor(Color col)
	{
		if (isServer) return;
		ChatColor = col;
	}

	void RpcSetCanMove(bool canMove)
	{
		if (isServer) return;
		CanMove = canMove;
	}
}

public class PlayerChatEvent
{
	public Player Player { get; private set; }
	public string Message { get; private set; }
	public bool Canceled { get; set; }

	public PlayerChatEvent(Player player, string message)
	{
		Player = player;
		Message = message;
	}
}
