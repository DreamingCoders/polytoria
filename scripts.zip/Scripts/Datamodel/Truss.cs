using UnityEngine;

public class Truss : Climbable
{
	protected override void Awake()
	{
		base.Awake();
		shape = PartShape.Truss;
	}

	public override Instance Clone()
	{
		Part clone = (Part) New("Truss", Parent);
		try
		{
			clone.Parent = Parent;
			clone.Name = Name;

			clone.Position = Position;
			clone.Rotation = Rotation;
			clone.Size = Size;

			clone.CanCollide = CanCollide;
			clone.Anchored = Anchored;
			clone.Color = Color;
			clone.Shape = Shape;
			clone.HideStuds = HideStuds;
			clone.Material = Material;

			foreach (Instance child in GetChildren())
			{
				Instance clonedChild = child.Clone();
				clonedChild.Parent = clone;
			}
		}
		catch (System.Exception e)
		{
			Debug.LogError(e);
		}


		return clone;
	}

}
