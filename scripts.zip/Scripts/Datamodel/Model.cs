public class Model : DynamicInstance
{
	public override Instance Clone()
	{
		Model clone = (Model) New("Model", Parent);
		clone.Parent = Parent;
		clone.Name = Name;
		clone.Size = Size;
		clone.Position = Position;
		clone.Rotation = Rotation;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		clone.SyncTransformRecursively();

		return clone;
	}

	protected override void OnHide()
	{
		base.OnHide();
	}

	protected override void OnShow()
	{
		base.OnShow();
	}
}
