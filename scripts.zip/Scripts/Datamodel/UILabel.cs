using Mirror;
using TMPro;
using UnityEngine;

namespace Polytoria.Datamodel
{
	[System.Serializable]
	public enum TextJustify { Left, Center, Right, Justify, Flush }
	[System.Serializable]
	public enum TextVerticalAlign { Top, Middle, Bottom }
	[System.Serializable]
	public enum TextFontPreset { SourceSans, PressStart2P, Montserrat, RobotoMono, Rubik, Poppins, Domine, Fredoka, ComicNeue, Orbitron }
	public class UILabel : UIView
	{

		public const float FONT_SCALE = 1.5f;

		private TMP_Text tmp;

		[SyncVar(hook = nameof(SyncSetTextJustify))] TextJustify justify = TextJustify.Center;
		[SyncVar(hook = nameof(SyncSetTextAlign))] TextVerticalAlign verticalAlign = TextVerticalAlign.Middle;
		[SyncVar(hook = nameof(SyncSetFontSize))] float fontSize = 16;
		[SyncVar(hook = nameof(SyncSetMaxFontSize))] float maxFontSize = 16;
		[SyncVar(hook = nameof(SyncSetAutoSize))] bool autoSize = false;
		[SyncVar(hook = nameof(SyncSetText))] string text = "Text";
		[SyncVar(hook = nameof(SyncSetColor))] Color textColor = Color.black;
		[SyncVar(hook = nameof(SyncSetFont))] TextFontPreset font = TextFontPreset.Montserrat;
		private void SyncSetText(string oldtext, string newtext)
		{
			Text = text;
		}
		private void SyncSetTextJustify(TextJustify oldValue, TextJustify newValue)
		{
			JustifyText = newValue;
		}
		private void SyncSetTextAlign(TextVerticalAlign oldValue, TextVerticalAlign newValue)
		{
			VerticalAlign = newValue;
		}
		private void SyncSetFontSize(float oldValue, float newValue)
		{
			FontSize = newValue;
		}
		private void SyncSetMaxFontSize(float oldValue, float newValue)
		{
			MaxFontSize = newValue;
		}
		private void SyncSetAutoSize(bool oldValue, bool newValue)
		{
			AutoSize = newValue;
		}
		private void SyncSetColor(Color oldValue, Color newValue)
		{
			TextColor = newValue;
		}
		private void SyncSetFont(TextFontPreset oldValue, TextFontPreset newValue)
		{
			Font = newValue;
		}

		[CreatorProperty, Archivable]
		public string Text
		{
			get => text;
			set => tmp.text = text = value;
		}
		[CreatorProperty, Archivable]
		public Color TextColor
		{
			get => textColor;
			set => tmp.color = textColor = value;
		}
		[CreatorProperty, Archivable]
		public TextJustify JustifyText
		{
			get => justify;
			set
			{
				justify = value;
				tmp.alignment = (justify == TextJustify.Left) ? TextAlignmentOptions.Left :
								(justify == TextJustify.Center) ? TextAlignmentOptions.Center :
								(justify == TextJustify.Right) ? TextAlignmentOptions.Right :
								(justify == TextJustify.Justify) ? TextAlignmentOptions.Justified :
								(justify == TextJustify.Flush) ? TextAlignmentOptions.Flush :
								TextAlignmentOptions.Left;
			}
		}
		[CreatorProperty, Archivable]
		public TextVerticalAlign VerticalAlign
		{
			get => verticalAlign;
			set
			{
				verticalAlign = value;
				tmp.verticalAlignment = (verticalAlign == TextVerticalAlign.Top) ? VerticalAlignmentOptions.Top :
								(verticalAlign == TextVerticalAlign.Middle) ? VerticalAlignmentOptions.Middle :
								(verticalAlign == TextVerticalAlign.Bottom) ? VerticalAlignmentOptions.Bottom :
								VerticalAlignmentOptions.Top;
			}
		}
		[CreatorProperty, Archivable]
		public float FontSize
		{
			get => fontSize;
			set
			{
				fontSize = value;
				if (maxFontSize < fontSize)
				{
					maxFontSize = fontSize;
				}
				tmp.fontSize = fontSize * FONT_SCALE;
			}
		}
		[CreatorProperty, Archivable]
		public float MaxFontSize
		{
			get => maxFontSize;
			set
			{
				maxFontSize = Mathf.Max(value, fontSize);
				tmp.fontSizeMax = maxFontSize * FONT_SCALE;
				tmp.fontSizeMin = fontSize * FONT_SCALE;
			}
		}
		[CreatorProperty, Archivable]
		public bool AutoSize
		{
			get => autoSize;
			set
			{
				autoSize = value;
				tmp.enableAutoSizing = autoSize;
			}
		}
		[CreatorProperty, Archivable]
		public TextFontPreset Font
		{
			get => font;
			set
			{
				font = value;
				switch (font)
				{
					case TextFontPreset.SourceSans:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/SourceSansPro-Regular SDF");
						break;
					case TextFontPreset.PressStart2P:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/PressStart2P-Regular SDF");
						break;
					case TextFontPreset.Montserrat:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/Montserrat Regular");
						break;
					case TextFontPreset.RobotoMono:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/RobotoMono-VariableFont_wght SDF");
						break;
					case TextFontPreset.Rubik:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/Rubik-VariableFont_wght SDF");
						break;
					case TextFontPreset.Poppins:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/Poppins-Regular SDF");
						break;
					case TextFontPreset.Domine:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/Domine-VariableFont_wght SDF");
						break;
					case TextFontPreset.Fredoka:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/Fredoka-VariableFont_wdth,wght SDF");
						break;
					case TextFontPreset.ComicNeue:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/ComicNeue-Regular SDF");
						break;
					case TextFontPreset.Orbitron:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/Orbitron-VariableFont_wght SDF");
						break;
					default:
						tmp.font = Resources.Load<TMP_FontAsset>("Fonts/SourceSansPro-Regular SDF");
						break;
				}
			}
		}


		protected override void Awake()
		{
			base.Awake();
			tmp = transform.Find("Text").GetComponent<TMP_Text>();
		}

		protected override void Start()
		{
			base.Start();

			Text = text;
			TextColor = textColor;
			JustifyText = justify;
			VerticalAlign = verticalAlign;
			FontSize = fontSize;
			MaxFontSize = maxFontSize;
			AutoSize = autoSize;
			Font = font;

		}

		protected override void OnHide()
		{
			base.OnHide();
			tmp.enabled = false;
		}

		protected override void OnShow()
		{
			base.OnShow();
			tmp.enabled = true;
		}

		public override Instance Clone()
		{
			UILabel clone = (UILabel) New("UILabel", Parent);
			try
			{
				clone.Name = Name;
				clone.PositionOffset = PositionOffset;
				clone.PositionRelative = PositionRelative;
				clone.SizeOffset = SizeOffset;
				clone.SizeRelative = SizeRelative;
				clone.Rotation = Rotation;
				clone.PivotPoint = PivotPoint;
				clone.Visible = Visible;
				clone.Text = Text;
				clone.Font = Font;
				clone.FontSize = FontSize;
				clone.Color = Color;
				clone.BorderWidth = BorderWidth;
				clone.BorderColor = BorderColor;
				clone.CornerRadius = CornerRadius;
				clone.AutoSize = AutoSize;
				clone.JustifyText = JustifyText;
				clone.VerticalAlign = VerticalAlign;
				clone.MaxFontSize = MaxFontSize;
				clone.TextColor = TextColor;

				foreach (Instance child in GetChildren())
				{
					Instance childClone = child.Clone();
					childClone.Parent = clone;
				}
			}
			catch (System.Exception e)
			{
				Debug.LogError(e);
			}

			return clone;
		}

	}
}