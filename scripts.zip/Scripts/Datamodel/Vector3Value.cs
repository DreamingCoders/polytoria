using Mirror;
using UnityEngine;

public class Vector3Value : ValueBase
{
	[SyncVar] Vector3 val;

	[Archivable, CreatorProperty]
	public Vector3 Value
	{
		get => val;
		set
		{
			val = value;
			InvokeChanged();
		}
	}

	public override Instance Clone()
	{
		Vector3Value clone = (Vector3Value) New("Vector3Value");

		clone.Parent = Parent;
		clone.Name = Name;
		clone.Value = Value;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
