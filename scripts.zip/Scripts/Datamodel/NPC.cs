using System.Collections.Generic;
using System.Linq;
using Mirror;
using UnityEngine;

public class NPC : DynamicInstance
{
	[SerializeField] LayerMask ignoreLayer;

	[SerializeField] GameObject head;
	[SerializeField] GameObject torso;
	[SerializeField] GameObject leftArm;
	[SerializeField] GameObject rightArm;
	[SerializeField] GameObject leftLeg;
	[SerializeField] GameObject rightLeg;

	[SerializeField] List<Rigidbody> deathBodyParts;

	[SyncVar] float maxHealth = 100f;
	[SyncVar] float health;
	[SyncVar] float walkSpeed = 16f;
	[SyncVar] float jumpPower = 25f;

	[SyncVar] Color headColor;
	[SyncVar] Color leftArmColor;
	[SyncVar] Color rightArmColor;
	[SyncVar] Color torsoColor;
	[SyncVar] Color leftLegColor;
	[SyncVar] Color rightLegColor;

	[SyncVar] int shirtID = 0;
	[SyncVar] int pantsID = 0;
	[SyncVar] int faceID = 0;

	[SyncVar] bool anchored = false;
	[SyncVar] bool grounded = false;

	Rigidbody rb;
	Collider col;
	Animator anim;
	NetworkAnimator netAnim;

	public float maxStepHeight = 1.2f;
	public float stepSearchOvershoot = 0.01f;

	PhysicMaterial airMaterial, groundMaterial;
	float jumpCooldown;

	private List<ContactPoint> allCPs = new List<ContactPoint>();
	private Vector3 lastVelocity;

	Dictionary<Rigidbody, Vector3> defaultBodyPartPos = new Dictionary<Rigidbody, Vector3>();

	public Instance MoveTarget
	{
		get; set;
	}

	[CreatorProperty, Archivable]
	public Color HeadColor
	{
		get => head.GetComponent<Renderer>().materials[0].color;
		set
		{
			headColor = value;
			head.GetComponent<Renderer>().materials[0].color = value;

			if (isServer)
				RpcSetColor(BodyPart.Head, value);
		}
	}

	[CreatorProperty, Archivable]
	public Color TorsoColor
	{
		get => torso.GetComponent<Renderer>().materials[0].color;
		set
		{
			torsoColor = value;
			torso.GetComponent<Renderer>().materials[0].color = value;

			if (isServer)
				RpcSetColor(BodyPart.Torso, value);
		}
	}

	[CreatorProperty, Archivable]
	public Color LeftArmColor
	{
		get => leftArm.GetComponent<Renderer>().materials[0].color;
		set
		{
			leftArmColor = value;
			leftArm.GetComponent<Renderer>().materials[0].color = value;

			if (isServer)
				RpcSetColor(BodyPart.LeftArm, value);
		}
	}

	[CreatorProperty, Archivable]
	public Color RightArmColor
	{
		get => rightArm.GetComponent<Renderer>().materials[0].color;
		set
		{
			rightArmColor = value;
			rightArm.GetComponent<Renderer>().materials[0].color = value;

			if (isServer)
				RpcSetColor(BodyPart.RightArm, value);
		}
	}

	[CreatorProperty, Archivable]
	public Color LeftLegColor
	{
		get => leftLeg.GetComponent<Renderer>().materials[0].color;
		set
		{
			leftLegColor = value;
			leftLeg.GetComponent<Renderer>().materials[0].color = value;

			if (isServer)
				RpcSetColor(BodyPart.LeftLeg, value);
		}
	}

	[CreatorProperty, Archivable]
	public Color RightLegColor
	{
		get => rightLeg.GetComponent<Renderer>().materials[0].color;
		set
		{
			rightLegColor = value;
			rightLeg.GetComponent<Renderer>().materials[0].color = value;

			if (isServer)
				RpcSetColor(BodyPart.RightLeg, value);
		}
	}

	[CreatorProperty, Archivable]
	public bool Anchored
	{
		get => anchored;
		set
		{
			anchored = value;
			if (!CreatorController.IsCreator)
				GetComponent<Rigidbody>().isKinematic = anchored;

			if (isServer)
			{
				RpcSetAnchored(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public float Health
	{
		get => health;
		set
		{
			health = value;
		}
	}

	[CreatorProperty, Archivable]
	public float MaxHealth
	{
		get => maxHealth;
		set
		{
			maxHealth = value;
		}
	}


	[CreatorProperty, Archivable]
	public float WalkSpeed
	{
		get => walkSpeed;
		set
		{
			walkSpeed = Mathf.Clamp(value, 0.01f, 1000f);
			if (isServer)
			{
				RpcSetWalkSpeed(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public int ShirtID
	{
		get => shirtID;
		set
		{
			shirtID = value;

			if (value == 0)
			{
				Texture2D t = Resources.Load<Texture2D>("Textures/alpha");
				leftArm.GetComponent<Renderer>().materials[1].mainTexture = t;
				rightArm.GetComponent<Renderer>().materials[1].mainTexture = t;
				torso.GetComponent<Renderer>().materials[1].mainTexture = t;
			}
			else
			{
				ImageCacheController.Instance.GetImage(new ImageCacheKey { id = value.ToString(), type = ImageType.Asset }, (key, entry) =>
				{
					if (key.id != value.ToString()) return;

					leftArm.GetComponent<Renderer>().materials[1].mainTexture = entry.texture;
					rightArm.GetComponent<Renderer>().materials[1].mainTexture = entry.texture;
					torso.GetComponent<Renderer>().materials[1].mainTexture = entry.texture;
				});
			}
		}
	}

	[CreatorProperty, Archivable]
	public int PantsID
	{
		get => pantsID;
		set
		{
			pantsID = value;

			if (value == 0)
			{
				Texture2D t = Resources.Load<Texture2D>("Textures/alpha");
				leftLeg.GetComponent<Renderer>().materials[1].mainTexture = t;
				rightLeg.GetComponent<Renderer>().materials[1].mainTexture = t;
			}
			else
			{
				ImageCacheController.Instance.GetImage(new ImageCacheKey { id = value.ToString(), type = ImageType.Asset }, (key, entry) =>
				{
					if (key.id != value.ToString()) return;

					leftLeg.GetComponent<Renderer>().materials[1].mainTexture = entry.texture;
					rightLeg.GetComponent<Renderer>().materials[1].mainTexture = entry.texture;
				});
			}
		}
	}

	[CreatorProperty, Archivable]
	public int FaceID
	{
		get => faceID;
		set
		{
			faceID = value;

			if (value == 0)
			{
				head.GetComponent<Renderer>().materials[1].mainTexture = Resources.Load<Texture2D>("Textures/DefaultFace");
			}
			else
			{
				ImageCacheController.Instance.GetImage(new ImageCacheKey { id = value.ToString(), type = ImageType.Asset }, (key, entry) =>
				{
					if (key.id != value.ToString()) return;

					head.GetComponent<Renderer>().materials[1].mainTexture = entry.texture;
					head.GetComponent<Renderer>().materials[1].mainTexture.wrapMode = TextureWrapMode.Clamp;
				});
			}

		}
	}

	[ClientRpc]
	void RpcSetWalkSpeed(float walkSpeed)
	{
		if (isServer) return;
		WalkSpeed = walkSpeed;
	}

	public bool Grounded => grounded;
	public LuaEvent Died = new LuaEvent();

	bool isDead = false;

	protected override void Start()
	{
		base.Start();
		rb = GetComponent<Rigidbody>();
		col = GetComponent<Collider>();
		anim = GetComponent<Animator>();
		netAnim = GetComponent<NetworkAnimator>();

		airMaterial = Resources.Load<PhysicMaterial>("Materials/Physics/PlayerAerial");
		groundMaterial = Resources.Load<PhysicMaterial>("Materials/Physics/PlayerGrounded");
		Health = MaxHealth;
		foreach (Rigidbody p in deathBodyParts)
		{
			defaultBodyPartPos.Add(p, p.transform.localPosition);
			MeshCollider c = p.gameObject.AddComponent<MeshCollider>();
			c.convex = true;
			c.enabled = false;
			c.material = groundMaterial;
		}

		if (CreatorController.IsCreator)
		{
			anim.enabled = false;
			rb.isKinematic = true;
		}

		if (!isServer)
		{
			HeadColor = headColor;
			TorsoColor = torsoColor;
			LeftArmColor = leftArmColor;
			RightArmColor = rightArmColor;
			LeftLegColor = leftLegColor;
			RightLegColor = rightLegColor;
			Anchored = anchored;
			Health = health;
			ShirtID = shirtID;
			PantsID = pantsID;
			FaceID = faceID;
		}
	}

	protected override void Update()
	{
		base.Update();
		if (isServer)
		{
			grounded = IsGrounded();
			anim.SetBool("grounded", grounded);

			jumpCooldown -= Time.deltaTime;

			if (Health <= 0f && !isDead)
			{
				Die();
			}
		}
	}

	void Die()
	{
		if (CreatorController.IsCreator) return;
		isDead = true;
		anim.enabled = false;
		RpcSetAnimatorActive(false);
		rb.isKinematic = true;
		col.enabled = false;
		foreach (Rigidbody bp in deathBodyParts)
		{
			bp.isKinematic = false;
			bp.velocity = rb.velocity;
			bp.GetComponent<Collider>().enabled = true;
		}

		Died?.Invoke();
	}

	[ClientRpc]
	void RpcSetAnimatorActive(bool active)
	{
		anim.enabled = enabled;
		netAnim.enabled = active;
	}

	public void Respawn()
	{
		if (!isServer) return;
		isDead = false;
		Health = MaxHealth;

		if (defaultBodyPartPos.Count != 0)
		{
			foreach (Rigidbody bp in deathBodyParts)
			{
				bp.GetComponent<Collider>().enabled = false;
				bp.isKinematic = true;
				bp.velocity = Vector3.zero;
				bp.angularVelocity = Vector3.zero;
				bp.transform.localPosition = defaultBodyPartPos[bp];
				bp.transform.localRotation = Quaternion.identity;
			}

		}

		anim.enabled = true;
		RpcSetAnimatorActive(true);

		rb.isKinematic = false;
		col.enabled = true;
		rb.velocity = Vector3.zero;
		rb.angularVelocity = Vector3.zero;
	}

	private void FixedUpdate()
	{
		if (isServer)
		{
			if (MoveTarget != null)
			{
				Vector3 p = MoveTarget.transform.position;
				Vector3 dir = (p - transform.position).normalized;
				MoveDirection(dir);
			}

			bool grounded = FindGround(out ContactPoint groundCP, allCPs);

			Vector3 stepUpOffset = default;
			bool stepUp = false;
			if (grounded)
				stepUp = FindStep(out stepUpOffset, allCPs, groundCP, rb.velocity);

			if (stepUp)
			{
				rb.position += stepUpOffset;
				rb.velocity = lastVelocity;
			}

			allCPs.Clear();
			lastVelocity = rb.velocity;
		}
	}

	void MoveDirection(Vector3 dir)
	{
		dir = dir.normalized * walkSpeed;
		anim.SetBool("walking", dir != Vector3.zero);
		rb.velocity = new Vector3(dir.x, rb.velocity.y, dir.z);

		Quaternion targetRotation;

		if (dir != Vector3.zero)
		{
			targetRotation = Quaternion.LookRotation(dir, Vector3.up);
		}
		else
		{
			targetRotation = transform.rotation;
		}

		Quaternion newRotation = Quaternion.Lerp(rb.rotation, Quaternion.Euler(new Vector3(0f, targetRotation.eulerAngles.y, 0f)), Time.deltaTime * 15f);
		rb.MoveRotation(newRotation);
	}

	void OnCollisionStay(Collision col)
	{
		allCPs.AddRange(col.contacts);
	}

	bool FindGround(out ContactPoint groundCP, List<ContactPoint> allCPs)
	{
		groundCP = default;
		bool found = false;
		foreach (ContactPoint cp in allCPs)
		{
			if (cp.normal.y > 0.0001f && (found == false || cp.normal.y > groundCP.normal.y))
			{
				groundCP = cp;
				found = true;
			}
		}

		return found;
	}

	bool FindStep(out Vector3 stepUpOffset, List<ContactPoint> allCPs, ContactPoint groundCP, Vector3 currVelocity)
	{
		stepUpOffset = default;

		Vector2 velocityXZ = new Vector2(currVelocity.x, currVelocity.z);
		if (velocityXZ.sqrMagnitude < 0.0001f)
			return false;

		foreach (ContactPoint cp in allCPs)
		{
			bool test = ResolveStepUp(out stepUpOffset, cp, groundCP);
			if (test)
				return test;
		}
		return false;
	}

	bool ResolveStepUp(out Vector3 stepUpOffset, ContactPoint stepTestCP, ContactPoint groundCP)
	{
		stepUpOffset = default;
		Collider stepCol = stepTestCP.otherCollider;

		if (Mathf.Abs(stepTestCP.normal.y) >= 0.01f)
		{
			return false;
		}

		if (!(stepTestCP.point.y - groundCP.point.y < maxStepHeight))
		{
			return false;
		}

		float stepHeight = groundCP.point.y + maxStepHeight + 0.0001f;
		Vector3 stepTestInvDir = new Vector3(-stepTestCP.normal.x, 0, -stepTestCP.normal.z).normalized;
		Vector3 origin = new Vector3(stepTestCP.point.x, stepHeight, stepTestCP.point.z) + (stepTestInvDir * stepSearchOvershoot);
		Vector3 direction = Vector3.down;
		if (!(stepCol.Raycast(new Ray(origin, direction), out RaycastHit hitInfo, maxStepHeight)))
		{
			return false;
		}

		Vector3 stepUpPoint = new Vector3(stepTestCP.point.x, hitInfo.point.y + 0.0001f, stepTestCP.point.z) + (stepTestInvDir * stepSearchOvershoot);
		Vector3 stepUpPointOffset = stepUpPoint - new Vector3(stepTestCP.point.x, groundCP.point.y, stepTestCP.point.z);

		stepUpOffset = stepUpPointOffset;
		return true;
	}

	bool IsGrounded()
	{
		if (Anchored) return true;

		BoxCollider boxCol = (BoxCollider) col;
		List<Collider> cols = Physics.OverlapBox((boxCol.bounds.center) - (Vector3.up * 0.1f), new Vector3((boxCol.size.x - 0.01f) / 2, (boxCol.size.y / 2), (boxCol.size.z - 0.01f) / 2), rb.rotation, ~ignoreLayer).ToList();
		Debug.DrawRay(boxCol.bounds.center - (Vector3.up * boxCol.size.y / 2), -transform.up * .75f, Color.white);
		return cols.Where(i => !i.isTrigger).Count() > 0 && ((Mathf.Abs(rb.velocity.y) < 0.1f) || Physics.Raycast(boxCol.bounds.center - (Vector3.up * boxCol.size.y / 2), Vector3.down, .75f, ~ignoreLayer));
	}

	public void Jump()
	{
		if (grounded && Health > 0f && jumpCooldown <= 0f)
		{
			col.material = airMaterial;
			rb.velocity = new Vector3(rb.velocity.x, 0f, rb.velocity.z);
			rb.AddForce(Vector3.up * jumpPower, ForceMode.Impulse);
			jumpCooldown = 0.1f;
			RpcJumpSound();
		}
	}

	[ClientRpc]
	void RpcJumpSound()
	{
		AudioSource audio = GetComponent<AudioSource>();
		audio.Stop();
		audio.time = 0f;
		audio.Play();
	}

	public override Instance Clone()
	{
		NPC clone = (NPC) New("NPC", Parent);

		clone.Parent = Parent;
		clone.Name = Name;

		clone.Position = Position;
		clone.Rotation = Rotation;
		clone.Size = Size;

		clone.HeadColor = HeadColor;
		clone.TorsoColor = TorsoColor;
		clone.LeftArmColor = LeftArmColor;
		clone.RightArmColor = RightArmColor;
		clone.LeftLegColor = LeftLegColor;
		clone.RightLegColor = RightLegColor;

		clone.Health = Health;
		clone.MaxHealth = MaxHealth;

		clone.Anchored = Anchored;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}

	[ClientRpc]
	void RpcSetAnchored(bool a)
	{
		if (isServer) return;
		Anchored = a;
	}

	[ClientRpc]
	void RpcSetColor(BodyPart bodyPart, Color color)
	{
		if (isServer)
			return;

		switch (bodyPart)
		{
			case BodyPart.Head:
				HeadColor = color;
				break;
			case BodyPart.Torso:
				TorsoColor = color;
				break;
			case BodyPart.LeftArm:
				LeftArmColor = color;
				break;
			case BodyPart.RightArm:
				RightArmColor = color;
				break;
			case BodyPart.LeftLeg:
				LeftLegColor = color;
				break;
			case BodyPart.RightLeg:
				RightLegColor = color;
				break;
		}
	}

	protected override void OnHide()
	{
		base.OnHide();
		foreach (MeshRenderer mr in GetComponentsInChildren<MeshRenderer>())
		{
			mr.enabled = false;
		}
		try
		{
			GetComponent<BoxCollider>().enabled = false;
		}
		catch { }
		try
		{
			GetComponent<MeshCollider>().enabled = false;
		}
		catch { }
		try
		{
			GetComponent<SphereCollider>().enabled = false;
		}
		catch { }
		try
		{
			GetComponent<Rigidbody>().isKinematic = true;
		}
		catch { }
	}
	protected override void OnShow()
	{
		base.OnShow();

		foreach (MeshRenderer mr in GetComponentsInChildren<MeshRenderer>())
		{
			mr.enabled = true;
		}

		try
		{
			GetComponent<BoxCollider>().enabled = true;
		}
		catch { }
		try
		{
			GetComponent<MeshCollider>().enabled = true;
		}
		catch { }
		try
		{
			GetComponent<SphereCollider>().enabled = true;
		}
		catch { }
		//trigger colliders
		Anchored = Anchored;
	}

	enum BodyPart
	{
		Head,
		Torso,
		LeftArm,
		RightArm,
		LeftLeg,
		RightLeg
	}
}
