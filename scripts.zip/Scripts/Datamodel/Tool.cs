using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;
using UnityEngine.Animations;

[RequireComponent(typeof(ParentConstraint))]
public class Tool : DynamicInstance
{
	Renderer _renderer;
	BoxCollider col;
	Rigidbody rb;

	ParentConstraint parentConstraint;

	public LuaEvent Activated = new LuaEvent();

	float pickupCooldown = 0f;
	[SyncVar] bool droppable = true;

	[CreatorProperty, Archivable]
	public bool Droppable
	{
		get => droppable;
		set
		{
			droppable = value;
		}
	}


	protected override bool DoTransformSync => !(Parent is Player);

	protected override void Awake()
	{
		base.Awake();
		rb = GetComponent<Rigidbody>();
		col = GetComponent<BoxCollider>();
		_renderer = GetComponent<Renderer>();
		parentConstraint = GetComponent<ParentConstraint>();

		if (!CreatorController.IsCreator)
		{
			_Touched += OnTouched;
			_ParentChanged += OnParentChange;
		}
	}

	protected override void Start()
	{
		base.Start();

		if (CreatorController.IsCreator)
		{
			rb.isKinematic = true;
		}

		_DescendantAdded += OnDescendantAdded;

		foreach (Instance i in GetChildren())
		{
			OnDescendantAdded(i);
		}
	}

	public void Play(string anim)
	{
		if (Parent is Player plr)
		{
			if (!isServer)
			{
				plr.PlayAnim(anim);
			}
			else
			{
				plr.PlayAnimTargetRpc(anim);
			}
		}
	}

	private void OnParentChange()
	{
		if (isServer)
		{
			RpcLinkTool(Parent);
			DoLinkTool(Parent);
			FixChildTransforms(this);
		}
	}

	void FixChildTransforms(DynamicInstance i)
	{
		RpcUpdateChildTransform(i, i.transform.localPosition, i.transform.localRotation, i.transform.localScale);

		foreach (DynamicInstance d in i.GetChildrenOfType<DynamicInstance>())
		{
			FixChildTransforms(d);
		}
	}

	[ClientRpc]
	void RpcUpdateChildTransform(DynamicInstance i, Vector3 pos, Quaternion rot, Vector3 size)
	{
		i.transform.localPosition = pos;
		i.transform.localRotation = rot;
		i.transform.localScale = size;
	}

	protected override void Update()
	{
		base.Update();

		pickupCooldown -= Time.deltaTime;
	}

	private void OnTouched(Instance obj)
	{
		if (isServer)
		{
			if (obj is Player plr)
			{
				CollectTool(plr);
			}
		}
	}

	void CollectTool(Player player)
	{
		if (!isServer) return;
		if (Parent is Player || Parent is Backpack) return;
		if (pickupCooldown > 0f) return;
		if (player.Health <= 0f) return;

		if (player.FindChildOfType<Tool>() == null)
		{
			Parent = player;
		}
		else
		{
			Parent = player.FindChildOfType<Backpack>();
		}

		pickupCooldown = 1f;
	}

	[ClientRpc]
	void RpcLinkTool(Instance par)
	{
		DoLinkTool(par);
	}

	void DoLinkTool(Instance par)
	{
		if (this != null && par != null)
		{
			if (par is Player plr)
			{
				rb.isKinematic = true;
				transform.position = plr.ToolAttachmentPoint.position;
				transform.rotation = plr.ToolAttachmentPoint.rotation;

				if (LaunchController.isSolo || !isServer)
				{
					if (Game.singleton?.FindChildOfType<Players>()?.LocalPlayer == plr)
					{
						Physics.IgnoreCollision(col, plr.GetComponent<Collider>(), true);
					}
				}
				parentConstraint.AddSource(new ConstraintSource { sourceTransform = plr.ToolAttachmentPoint, weight = 1 });
			}
			else
			{
				if (LaunchController.isSolo || !isServer)
				{
					Players players = Game.singleton.FindChildOfType<Players>();
					if (players != null && players.LocalPlayer != null)
					{
						Collider plrc = players.LocalPlayer.GetComponent<Collider>();
						if (plrc != null)
							Physics.IgnoreCollision(col, plrc, false);

					}
				}

				if (parentConstraint.sourceCount > 0)
				{
					parentConstraint.RemoveSource(0);
				}
			}
		}

		HotbarController.singleton.ToolLinked(this, par);
	}

	private void OnDescendantAdded(Instance obj)
	{
		if (isServer)
		{
			if (obj is Part part)
			{
				part.Anchored = true;
				part.CanCollide = false;
			}

			foreach (Part child in obj.GetChildrenOfType<Part>())
			{
				OnDescendantAdded(child);
			}
		}

		RecalculateBounds();
	}

	void RecalculateBounds()
	{
		Bounds b = _renderer.bounds;
		Renderer[] children = GetComponentsInChildren<Renderer>();

		foreach (Renderer r in children)
		{
			if (r != _renderer)
			{
				b.Encapsulate(r.bounds);
			}
		}

		Vector3 colSize = b.size;
		colSize.x = Mathf.Max(0.05f, colSize.x);
		colSize.y = Mathf.Max(0.05f, colSize.y);
		colSize.z = Mathf.Max(0.05f, colSize.z);

		col.size = colSize;
		col.center = b.center - transform.position;
	}

	[MoonSharpHidden]
	public void Activate()
	{
		if (isServer)
			DoActivate();
		else
			CmdActivate();
	}

	[Command(requiresAuthority = false)]
	void CmdActivate()
	{
		DoActivate();
	}

	void DoActivate()
	{
		if (!isServer) return;
		Activated?.Invoke();
		RpcActivate();
	}

	[ClientRpc]
	void RpcActivate()
	{
		if (isServer) return;
		Activated?.Invoke();
	}

	public override Instance Clone()
	{
		Tool clone = (Tool) New("Tool", Parent);

		clone.Parent = Parent;
		clone.Position = Position;
		clone.Rotation = Rotation;
		clone.Size = Size;
		clone.Name = Name;
		clone.Droppable = Droppable;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		clone.SyncTransformRecursively();

		return clone;
	}
	protected override void OnHide()
	{
		base.OnHide();
		GetComponent<Collider>().enabled = false;
		GetComponent<Rigidbody>().isKinematic = true;
	}

	protected override void OnShow()
	{
		base.OnShow();
		GetComponent<Collider>().enabled = true;
		if (!CreatorController.IsCreator)
			GetComponent<Rigidbody>().isKinematic = false;
	}
}
