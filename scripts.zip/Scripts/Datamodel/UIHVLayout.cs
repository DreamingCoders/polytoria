using Mirror;
using UnityEngine;
using UnityEngine.UI;

namespace Polytoria.Datamodel
{
	public class UIHVLayout : UIField
	{
		protected HorizontalOrVerticalLayoutGroup layoutGroup;

		[SyncVar(hook = nameof(SyncSpacing))] protected float spacing = 0;
		[SyncVar(hook = nameof(SyncChildControlWidth))] protected bool childControlWidth = false;
		[SyncVar(hook = nameof(SyncChildControlHeight))] protected bool childControlHeight = false;
		[SyncVar(hook = nameof(SyncChildScaleWidth))] protected bool childScaleWidth = false;
		[SyncVar(hook = nameof(SyncChildScaleHeight))] protected bool childScaleHeight = false;
		[SyncVar(hook = nameof(SyncChildForceExpandWidth))] protected bool childForceExpandWidth = true;
		[SyncVar(hook = nameof(SyncChildForceExpandHeight))] protected bool childForceExpandHeight = true;
		[SyncVar(hook = nameof(SyncPaddingLeft))] protected int paddingLeft = 0;
		[SyncVar(hook = nameof(SyncPaddingRight))] protected int paddingRight = 0;
		[SyncVar(hook = nameof(SyncPaddingTop))] protected int paddingTop = 0;
		[SyncVar(hook = nameof(SyncPaddingBottom))] protected int paddingBottom = 0;
		[SyncVar(hook = nameof(SyncChildAlignment))] protected TextAnchor childAlignment = TextAnchor.UpperLeft;
		[SyncVar(hook = nameof(SyncReverseAlignment))] protected bool reverseAlignment = false;

		[CreatorProperty, Archivable]
		public float Spacing
		{
			get => spacing;
			set
			{
				spacing = value;
				layoutGroup.spacing = value;
			}
		}

		[CreatorProperty, Archivable]
		public bool ChildControlWidth
		{
			get => childControlWidth;
			set
			{
				childControlWidth = value;
				layoutGroup.childControlWidth = value;
			}
		}

		[CreatorProperty, Archivable]
		public bool ChildControlHeight
		{
			get => childControlHeight;
			set
			{
				childControlHeight = value;
				layoutGroup.childControlHeight = value;
			}
		}

		[CreatorProperty, Archivable]
		public bool ChildScaleWidth
		{
			get => childScaleWidth;
			set
			{
				childScaleWidth = value;
				layoutGroup.childScaleWidth = value;
			}
		}

		[CreatorProperty, Archivable]
		public bool ChildScaleHeight
		{
			get => childScaleHeight;
			set
			{
				childScaleHeight = value;
				layoutGroup.childScaleHeight = value;
			}
		}

		[CreatorProperty, Archivable]
		public bool ChildForceExpandWidth
		{
			get => childForceExpandWidth;
			set
			{
				childForceExpandWidth = value;
				layoutGroup.childForceExpandWidth = value;
			}
		}

		[CreatorProperty, Archivable]
		public bool ChildForceExpandHeight
		{
			get => childForceExpandHeight;
			set
			{
				childForceExpandHeight = value;
				layoutGroup.childForceExpandHeight = value;
			}
		}

		[CreatorProperty, Archivable]
		public int PaddingLeft
		{
			get => paddingLeft;
			set
			{
				paddingLeft = value;
				layoutGroup.padding.left = value;
			}
		}

		[CreatorProperty, Archivable]
		public int PaddingRight
		{
			get => paddingRight;
			set
			{
				paddingRight = value;
				layoutGroup.padding.right = value;
			}
		}

		[CreatorProperty, Archivable]
		public int PaddingTop
		{
			get => paddingTop;
			set
			{
				paddingTop = value;
				layoutGroup.padding.top = value;
			}
		}

		[CreatorProperty, Archivable]
		public int PaddingBottom
		{
			get => paddingBottom;
			set
			{
				paddingBottom = value;
				layoutGroup.padding.bottom = value;
			}
		}

		[CreatorProperty, Archivable]
		public TextAnchor ChildAlignment
		{
			get => childAlignment;
			set
			{
				childAlignment = value;
				layoutGroup.childAlignment = value;
			}
		}

		[CreatorProperty, Archivable]
		public bool ReverseAlignment
		{
			get => reverseAlignment;
			set
			{
				reverseAlignment = value;
				layoutGroup.reverseArrangement = value;
			}
		}

		void SyncSpacing(float oldValue, float newValue)
		{
			Spacing = newValue;
		}

		void SyncChildControlWidth(bool oldValue, bool newValue)
		{
			ChildControlWidth = newValue;
		}

		void SyncChildControlHeight(bool oldValue, bool newValue)
		{
			ChildControlHeight = newValue;
		}

		void SyncChildScaleWidth(bool oldValue, bool newValue)
		{
			ChildScaleWidth = newValue;
		}

		void SyncChildScaleHeight(bool oldValue, bool newValue)
		{
			ChildScaleHeight = newValue;
		}

		void SyncChildForceExpandWidth(bool oldValue, bool newValue)
		{
			ChildForceExpandWidth = newValue;
		}

		void SyncChildForceExpandHeight(bool oldValue, bool newValue)
		{
			ChildForceExpandHeight = newValue;
		}

		void SyncPaddingLeft(int oldValue, int newValue)
		{
			PaddingLeft = newValue;
		}

		void SyncPaddingRight(int oldValue, int newValue)
		{
			PaddingRight = newValue;
		}

		void SyncPaddingTop(int oldValue, int newValue)
		{
			PaddingTop = newValue;
		}

		void SyncPaddingBottom(int oldValue, int newValue)
		{
			PaddingBottom = newValue;
		}

		void SyncChildAlignment(TextAnchor oldValue, TextAnchor newValue)
		{
			ChildAlignment = newValue;
		}

		void SyncReverseAlignment(bool oldValue, bool newValue)
		{
			ReverseAlignment = newValue;
		}

		protected override void Start()
		{
			base.Start();

			// _DescendantAdded += (i) => {
			//	 LayoutRebuilder.ForceRebuildLayoutImmediate(layoutGroup.transform as RectTransform);
			//	 layoutGroup.transform.hasChanged = true;
			// };
		}

		private void LateUpdate()
		{
			LayoutRebuilder.ForceRebuildLayoutImmediate(layoutGroup.transform as RectTransform); // bruh

			// if (layoutGroup.transform.hasChanged) {
			//	 layoutGroup.transform.hasChanged = false;
			// }
		}
	}
}