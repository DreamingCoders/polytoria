using Mirror;

public class InstanceValue : ValueBase
{
	[SyncVar] Instance val;

	[Archivable, CreatorProperty]
	public Instance Value
	{
		get => val;
		set
		{
			val = value;
			InvokeChanged();
		}
	}

	public override Instance Clone()
	{
		InstanceValue clone = (InstanceValue) New("InstanceValue");

		clone.Parent = Parent;
		clone.Name = Name;
		clone.Value = Value;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
