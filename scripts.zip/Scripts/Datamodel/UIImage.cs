using Mirror;
using UnityEngine;
using UnityEngine.UI;

namespace Polytoria.Datamodel
{
	public class UIImage : UIField
	{
		private Image image;

		[SyncVar(hook = nameof(SyncSetColor))] Color color = Color.white;
		[SyncVar(hook = nameof(SetImage))] private string imageID = "0";
		[SyncVar(hook = nameof(SetImageType))] private ImageType imageType;

		bool loading = false;
		Texture2D texture;
		private ImageCacheKey lastCacheKey;

		[CreatorProperty, Archivable]
		public Color Color
		{
			get => color;
			set
			{
				color = image.color = value;
			}
		}

		public bool Loading => loading;

		[CreatorProperty, Archivable]
		public string ImageID
		{
			get => imageID;
			set
			{
				imageID = value;
				GetImage();
			}
		}

		[CreatorProperty, Archivable]
		public ImageType ImageType
		{
			get => imageType;
			set
			{
				imageType = value;
				GetImage();
			}
		}

		void SyncSetColor(Color oldValue, Color newValue)
		{
			if (isServer) return;
			Color = newValue;
		}

		void SetImage(string oldValue, string newValue)
		{
			if (isServer) return;
			ImageID = newValue;
		}

		void SetImageType(ImageType oldValue, ImageType newValue)
		{
			if (isServer) return;
			ImageType = newValue;
		}

		protected override void Awake()
		{
			base.Awake();
			image = transform.Find("Image").GetComponent<Image>();
		}

		protected override void Start()
		{
			base.Start();
		}

		void LoadFallback()
		{
			image.sprite = Resources.Load<Sprite>("Textures/white");
		}

		void GetImage()
		{
			loading = true;

			if (ImageID == "0" || ImageID == "")
			{
				LoadFallback();
				loading = false;
				return;
			}

			lastCacheKey = new ImageCacheKey { id = ImageID, type = ImageType };
			ImageCacheController.Instance.GetImage(lastCacheKey, (key, entry) =>
			{
				if (key.Equals(lastCacheKey))
				{
					image.sprite = Sprite.Create(entry.texture, new Rect(0, 0, entry.texture.width, entry.texture.height), Vector2.one / 2);
					loading = false;
				}
			});
		}

		protected override void OnHide()
		{
			base.OnHide();
			image.enabled = false;
		}

		protected override void OnShow()
		{
			base.OnShow();
			image.enabled = true;
		}

		public override Instance Clone()
		{
			UIImage clone = (UIImage) New("UIImage", Parent);
			try
			{
				clone.Name = Name;
				clone.PositionOffset = PositionOffset;
				clone.PositionRelative = PositionRelative;
				clone.SizeOffset = SizeOffset;
				clone.SizeRelative = SizeRelative;
				clone.Rotation = Rotation;
				clone.PivotPoint = PivotPoint;
				clone.Visible = Visible;
				clone.Color = Color;
				clone.ImageID = ImageID;
				clone.ImageType = ImageType;

				foreach (Instance child in GetChildren())
				{
					Instance childClone = child.Clone();
					childClone.Parent = clone;
				}
			}
			catch (System.Exception e)
			{
				Debug.LogError(e);
			}

			return clone;
		}
	}
}