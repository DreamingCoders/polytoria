using Mirror;

public class Climbable : Part
{
	[SyncVar] private float climbSpeed = 1f;
	[CreatorProperty, Archivable]
	public float ClimbSpeed
	{
		get => climbSpeed;
		set => climbSpeed = value;
	}

	protected override void Start()
	{
		base.Start();
	}
}
