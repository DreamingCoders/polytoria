using Mirror;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Text3D : DynamicInstance
{
	protected override void OnHide()
	{
		base.OnHide();
		GetComponent<TMP_Text>().enabled = false;
	}
	protected override void OnShow()
	{
		base.OnShow();
		GetComponent<TMP_Text>().enabled = true;
	}
	TMP_Text tmp;
	[SyncVar] protected string text = "";
	[SyncVar] protected Color color = Color.white;
	[SyncVar] protected float fontSize = 36;
	[SyncVar] protected bool faceCamera = false;
	[SyncVar] protected HorizontalAlignmentOptions horizontalAlignment = HorizontalAlignmentOptions.Center;
	[SyncVar] protected VerticalAlignmentOptions verticalAlignment = VerticalAlignmentOptions.Middle;

	[SyncVar] Vector3 rotationCache;
	[SyncVar] Vector3 positionCache;

	[SerializeField] ContentSizeFitter csf;

	[CreatorProperty, Archivable]
	public string Text
	{
		get { return tmp.text; }
		set
		{
			text = value;
			tmp.text = text;

			if (isServer)
			{
				RpcSetText(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public Color Color
	{
		get { return tmp.color; }
		set
		{
			color = value;
			tmp.color = value;

			if (isServer)
			{
				RpcSetColor(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public float FontSize
	{
		get { return tmp.fontSize; }
		set
		{
			fontSize = value;
			tmp.fontSize = value;

			if (isServer)
			{
				RpcSetFontSize(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public bool FaceCamera
	{
		get => faceCamera;
		set
		{
			if (isServer)
			{
				if (value)
				{
					positionCache = Position;
					rotationCache = Rotation;
				}
				else
				{
					Position = positionCache;
					Rotation = rotationCache;
				}
			}

			faceCamera = value;
		}
	}

	[CreatorProperty, Archivable]
	public HorizontalAlignmentOptions HorizontalAlignment
	{
		get => horizontalAlignment;
		set
		{
			horizontalAlignment = value;
			tmp.horizontalAlignment = value;

			Vector3 pivot = ((RectTransform) transform).pivot;

			switch (value)
			{
				case HorizontalAlignmentOptions.Left:
					pivot.x = 0;
					break;
				case HorizontalAlignmentOptions.Center:
					pivot.x = 0.5f;
					break;
				case HorizontalAlignmentOptions.Right:
					pivot.x = 1f;
					break;
				default:
					pivot.x = 0.5f;
					break;
			}

			((RectTransform) transform).pivot = pivot;

			if (isServer)
				RpcSetHorizontalAlignment(value);
		}
	}

	[CreatorProperty, Archivable]
	public VerticalAlignmentOptions VerticalAlignment
	{
		get => verticalAlignment;
		set
		{
			verticalAlignment = value;
			tmp.verticalAlignment = value;

			Vector3 pivot = ((RectTransform) transform).pivot;

			switch (value)
			{
				case VerticalAlignmentOptions.Top:
					pivot.y = 0f;
					break;
				case VerticalAlignmentOptions.Middle:
					pivot.y = 0.5f;
					break;
				case VerticalAlignmentOptions.Bottom:
					pivot.y = 1f;
					break;
				default:
					pivot.y = 0.5f;
					break;
			}

			((RectTransform) transform).pivot = pivot;

			if (isServer)
				RpcSetVerticalAlignment(value);
		}
	}

	protected override void Awake()
	{
		tmp = GetComponent<TMP_Text>();
		base.Awake();
	}

	protected override void Start()
	{
		base.Start();

		if (!isServer)
		{
			Text = text;
			Color = color;
			FontSize = fontSize;
			FaceCamera = faceCamera;
			HorizontalAlignment = horizontalAlignment;
			VerticalAlignment = verticalAlignment;
		}
		else
		{
			color = tmp.color;
			text = tmp.text;
			horizontalAlignment = tmp.horizontalAlignment;
			verticalAlignment = tmp.verticalAlignment;
		}

		GetComponent<Collider>().enabled = CreatorController.IsCreator;
	}

	protected override void Update()
	{
		base.Update();
		if (isServer && !CreatorController.IsCreator && !LaunchController.isSolo) return;
		if (faceCamera)
		{
			transform.rotation = Quaternion.LookRotation(transform.position - Camera.main.transform.position);
		}
	}
	// <summary>
	// Clones da fuckin shit crap
	// </summary>
	public override Instance Clone()
	{
		Text3D clone = (Text3D) New("Text3D", Parent);
		clone.Parent = Parent;
		clone.Name = Name;

		clone.Text = Text;
		clone.Color = Color;

		clone.FontSize = FontSize;
		clone.HorizontalAlignment = HorizontalAlignment;
		clone.VerticalAlignment = VerticalAlignment;
		clone.FaceCamera = FaceCamera;

		clone.Position = Position;
		clone.Rotation = Rotation;
		clone.Size = Size;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}

	[ClientRpc]
	void RpcSetText(string t)
	{
		if (isServer) return;
		Text = t;
	}

	[ClientRpc]
	void RpcSetColor(Color color)
	{
		if (isServer) return;
		Color = color;
	}

	[ClientRpc]
	void RpcSetFontSize(float fs)
	{
		if (isServer) return;
		FontSize = fs;
	}

	[ClientRpc]
	void RpcSetHorizontalAlignment(HorizontalAlignmentOptions al)
	{
		if (isServer) return;
		HorizontalAlignment = al;
	}

	[ClientRpc]
	void RpcSetVerticalAlignment(VerticalAlignmentOptions al)
	{
		if (isServer) return;
		VerticalAlignment = al;
	}
}
