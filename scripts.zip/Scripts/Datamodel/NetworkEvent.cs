using System.Collections.Generic;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;

public class NetworkEvent : Instance
{
	public LuaEvent InvokedServer = new LuaEvent();
	public LuaEvent InvokedClient = new LuaEvent();

	public void InvokeServer(NetMessage msg)
	{
		InvokeCmd(msg);
	}

	public void InvokeClient(NetMessage msg, Player player)
	{
		if (!isServer)
			return;

		InvokeTargetRpc(player.connectionToClient, msg);
	}

	public void InvokeClients(NetMessage msg)
	{
		if (!isServer)
			return;


		InvokeClientRpc(msg);
	}

	[Command(requiresAuthority = false)]
	void InvokeCmd(NetMessage msg, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		InvokedServer?.Invoke(player, msg);
	}

	[TargetRpc]
	void InvokeTargetRpc(NetworkConnection target, NetMessage msg)
	{
		InvokedClient?.Invoke(null, msg);
	}

	[ClientRpc]
	void InvokeClientRpc(NetMessage msg)
	{
		InvokedClient?.Invoke(null, msg);
	}

	public override Instance Clone()
	{
		NetworkEvent clone = (NetworkEvent) New("NetworkEvent", Parent);

		clone.Name = Name;
		clone.Parent = Parent;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}

public class NetMessage
{
	[MoonSharpHidden] public readonly Dictionary<string, string> strings;
	[MoonSharpHidden] public readonly Dictionary<string, int> ints;
	[MoonSharpHidden] public readonly Dictionary<string, float> numbers;
	[MoonSharpHidden] public readonly Dictionary<string, bool> bools;
	[MoonSharpHidden] public readonly Dictionary<string, Vector2> vec2s;
	[MoonSharpHidden] public readonly Dictionary<string, Vector3> vec3s;
	[MoonSharpHidden] public readonly Dictionary<string, Color> colors;
	[MoonSharpHidden] public readonly Dictionary<string, Instance> instances;

	public NetMessage()
	{
		strings = new Dictionary<string, string>();
		ints = new Dictionary<string, int>();
		numbers = new Dictionary<string, float>();
		bools = new Dictionary<string, bool>();
		vec2s = new Dictionary<string, Vector2>();
		vec3s = new Dictionary<string, Vector3>();
		colors = new Dictionary<string, Color>();
		instances = new Dictionary<string, Instance>();
	}

	public void AddString(string key, string value)
	{
		strings.Add(key, value);
	}

	public void AddInt(string key, int value)
	{
		ints.Add(key, value);
	}

	public void AddBool(string key, bool value)
	{
		bools.Add(key, value);
	}

	public void AddNumber(string key, float value)
	{
		numbers.Add(key, value);
	}

	public void AddVector2(string key, Vector2 value)
	{
		vec2s.Add(key, value);
	}

	public void AddVector3(string key, Vector3 value)
	{
		vec3s.Add(key, value);
	}

	public void AddColor(string key, Color value)
	{
		colors.Add(key, value);
	}

	public void AddInstance(string key, Instance value)
	{
		instances.Add(key, value);
	}

	public string GetString(string key) => strings[key];
	public int GetInt(string key) => ints[key];
	public float GetNumber(string key) => numbers[key];
	public bool GetBool(string key) => bools[key];
	public Vector2 GetVector2(string key) => vec2s[key];
	public Vector3 GetVector3(string key) => vec3s[key];
	public Color GetColor(string key) => colors[key];
	public Instance GetInstance(string key) => instances[key];

	public static NetMessage New()
	{
		return new NetMessage();
	}

	public NetMessage(Dictionary<string, string> strings, Dictionary<string, int> ints, Dictionary<string, float> numbers, Dictionary<string, bool> bools, Dictionary<string, Vector2> vec2s, Dictionary<string, Vector3> vec3s, Dictionary<string, Color> colors, Dictionary<string, Instance> instances)
	{
		this.strings = strings;
		this.ints = ints;
		this.numbers = numbers;
		this.bools = bools;
		this.vec2s = vec2s;
		this.vec3s = vec3s;
		this.colors = colors;
		this.instances = instances;
	}
}

public static class NetMessageReadWriteFunctions
{
	static void WriteDictionary<T>(this NetworkWriter writer, Dictionary<string, T> dict)
	{
		writer.WriteInt(dict.Count);
		foreach (var kvp in dict)
		{
			writer.WriteString(kvp.Key);
			writer.Write<T>(kvp.Value);
		}
	}

	public static Dictionary<string, T> ReadDictionary<T>(NetworkReader reader)
	{
		var dict = new Dictionary<string, T>();
		int count = reader.ReadInt();
		for (int i = 0; i < count; i++)
		{
			string key = reader.ReadString();
			T value = reader.Read<T>();
			dict.Add(key, value);
		}
		return dict;
	}

	public static void WriteNetMessage(this NetworkWriter writer, NetMessage value)
	{
		writer.WriteDictionary(value.strings);
		writer.WriteDictionary(value.ints);
		writer.WriteDictionary(value.numbers);
		writer.WriteDictionary(value.bools);
		writer.WriteDictionary(value.vec2s);
		writer.WriteDictionary(value.vec3s);
		writer.WriteDictionary(value.colors);
		writer.WriteDictionary(value.instances);
	}

	public static NetMessage ReadNetMessage(this NetworkReader reader)
	{
		Dictionary<string, string> strings = ReadDictionary<string>(reader);
		Dictionary<string, int> ints = ReadDictionary<int>(reader);
		Dictionary<string, float> numbers = ReadDictionary<float>(reader);
		Dictionary<string, bool> bools = ReadDictionary<bool>(reader);
		Dictionary<string, Vector2> vec2s = ReadDictionary<Vector2>(reader);
		Dictionary<string, Vector3> vec3s = ReadDictionary<Vector3>(reader);
		Dictionary<string, Color> colors = ReadDictionary<Color>(reader);
		Dictionary<string, Instance> instances = ReadDictionary<Instance>(reader);

		return new NetMessage(strings, ints, numbers, bools, vec2s, vec3s, colors, instances);
	}
}
