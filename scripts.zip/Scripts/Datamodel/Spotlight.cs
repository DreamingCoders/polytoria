using Mirror;
using UnityEngine;

public class Spotlight : DynamicInstance
{
	static float intensityMultiplier = 0.5f;
	static float rangeMultiplier = 0.333f;
	protected override void OnHide()
	{
		base.OnHide();
		GetComponent<Light>().enabled = false;
	}
	protected override void OnShow()
	{
		base.OnShow();
		GetComponent<Light>().enabled = true;

	}

	[SyncVar] private float range;
	[SyncVar] private float brightness;
	[SyncVar] private Color color;
	[SyncVar] private float angle;
	[SyncVar] private bool shadows;

	[CreatorProperty, Archivable]
	public float Range
	{
		get { return GetComponent<Light>().range / rangeMultiplier; }
		set
		{
			value = Mathf.Clamp(value, 0f, 500f);
			range = value;
			GetComponent<Light>().range = value * rangeMultiplier;

			if (isServer)
			{
				RpcSetRange(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public float Angle
	{
		get { return GetComponent<Light>().spotAngle; }
		set
		{
			value = Mathf.Clamp(value, 1f, 179f);
			angle = value;
			GetComponent<Light>().spotAngle = value;

			if (isServer)
			{
				RpcSetAngle(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public float Brightness
	{
		get { return GetComponent<Light>().intensity / intensityMultiplier; }
		set
		{
			value = Mathf.Clamp(value, 0f, 10000f);
			brightness = value;
			GetComponent<Light>().intensity = value * intensityMultiplier;

			if (isServer)
			{
				RpcSetBrightness(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public Color Color
	{
		get => GetComponent<Light>().color;
		set
		{
			color = value;
			GetComponent<Light>().color = value;

			if (isServer)
			{
				RpcSetColor(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public bool Shadows
	{
		get => GetComponent<Light>().shadows != LightShadows.None;
		set
		{
			shadows = value;
			GetComponent<Light>().shadows = shadows ? LightShadows.Soft : LightShadows.None;

			if (isServer)
			{
				RpcSetShadowsEnabled(value);
			}
		}
	}

	protected override void Start()
	{
		base.Start();

		if (!isServer)
		{
			Color = color;
			Brightness = brightness;
			Range = range;
			Angle = angle;
			Shadows = shadows;
		}

		GetComponent<Collider>().enabled = CreatorController.IsCreator;
	}

	public override Instance Clone()
	{
		Spotlight clone = (Spotlight) New("Spotlight", Parent);
		clone.Parent = Parent;
		clone.Name = Name;

		clone.Position = Position;
		clone.Rotation = Rotation;
		clone.Size = Size;

		clone.Brightness = Brightness;
		clone.Range = Range;
		clone.Color = Color;
		clone.Angle = Angle;
		clone.Shadows = Shadows;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}

	[ClientRpc]
	void RpcSetRange(float range)
	{
		if (isServer) return;
		Range = range;
	}

	[ClientRpc]
	void RpcSetAngle(float angle)
	{
		if (isServer) return;
		Angle = angle;
	}

	[ClientRpc]
	void RpcSetBrightness(float brightness)
	{
		if (isServer) return;
		Brightness = brightness;
	}

	[ClientRpc]
	void RpcSetColor(Color color)
	{
		if (isServer) return;
		Color = color;
	}

	[ClientRpc]
	void RpcSetShadowsEnabled(bool enabled)
	{
		if (isServer) return;
		Shadows = enabled;
	}
}
