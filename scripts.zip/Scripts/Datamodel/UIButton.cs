using System;
using UnityEngine;
using UnityEngine.UI;

namespace Polytoria.Datamodel
{
	public class UIButton : UILabel
	{
		Button button;
		protected override void Awake()
		{
			base.Awake();
			button = GetComponent<Button>();
		}

		protected override void Start()
		{
			base.Start();
			button.onClick.AddListener(() =>
			{
				Clicked.Invoke();
			});
		}

		public override Instance Clone()
		{
			UIButton clone = (UIButton) New("UIButton", Parent);
			try
			{
				clone.Name = Name;
				clone.PositionOffset = PositionOffset;
				clone.PositionRelative = PositionRelative;
				clone.SizeOffset = SizeOffset;
				clone.SizeRelative = SizeRelative;
				clone.Rotation = Rotation;
				clone.PivotPoint = PivotPoint;
				clone.Visible = Visible;
				clone.Text = Text;
				clone.Font = Font;
				clone.FontSize = FontSize;
				clone.Color = Color;
				clone.BorderWidth = BorderWidth;
				clone.BorderColor = BorderColor;
				clone.CornerRadius = CornerRadius;
				clone.AutoSize = AutoSize;
				clone.JustifyText = JustifyText;
				clone.VerticalAlign = VerticalAlign;
				clone.MaxFontSize = MaxFontSize;
				clone.TextColor = TextColor;

				foreach (Instance child in GetChildren())
				{
					Instance childClone = child.Clone();
					childClone.Parent = clone;
				}
			}
			catch (Exception e)
			{
				Debug.LogError(e);
			}

			return clone;
		}
	}
}