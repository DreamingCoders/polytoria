using Mirror;
using UnityEngine;
using UnityEngine.UI;

namespace Polytoria.Datamodel
{
	public class UIView : UIField
	{
		private Image border;
		private RectTransform borderRect;
		private Image fill;

		/*[CreatorProperty, Archivable]
		public Color Color {
			get => img.color;
			set => img.color = value;
		}*/
		[SyncVar(hook = nameof(SyncSetColor))] Color color = Color.white;
		[SyncVar(hook = nameof(SyncSetBorderWidth))] float borderWidth = 2;
		[SyncVar(hook = nameof(SyncSetBorderColor))] Color borderColor = Color.black;
		[SyncVar(hook = nameof(SyncSetCornerRadius))] float cornerRadius = 0;

		[CreatorProperty, Archivable]
		public Color BorderColor
		{
			get => borderColor;
			set
			{
				borderColor = value;
				border.color = value;
			}
		}
		[CreatorProperty, Archivable]
		public Color Color
		{
			get => color;
			set
			{
				color = value;
				fill.color = value;
			}
		}
		[CreatorProperty, Archivable]
		public float BorderWidth
		{
			get => borderWidth;
			set
			{
				borderWidth = Mathf.Clamp(value, 0, 100000);
				UpdateBorder();
			}
		}

		[CreatorProperty, Archivable]
		public float CornerRadius
		{
			get => cornerRadius;
			set
			{
				float width = SizeOffset.x;
				float height = SizeOffset.y;
				cornerRadius = Mathf.Clamp(value, 0, (width > height ? width : height) / 3);
				UpdateBorder();
			}
		}
		void UpdateBorder()
		{
			borderRect.sizeDelta = new Vector2(borderWidth * 2, borderWidth * 2);
			border.pixelsPerUnitMultiplier = cornerRadius < 1 ? int.MaxValue : 1000 / ((10 * (cornerRadius + borderWidth)) + 1);
			fill.pixelsPerUnitMultiplier = cornerRadius < 1 ? int.MaxValue : 1000 / ((10 * cornerRadius) + 10);
		}
		void SyncSetBorderWidth(float oldValue, float newValue)
		{
			BorderWidth = newValue;
		}
		void SyncSetBorderColor(Color oldValue, Color newValue)
		{
			border.color = borderColor = newValue;
		}
		void SyncSetCornerRadius(float oldValue, float newValue)
		{
			CornerRadius = newValue;
		}
		void SyncSetColor(Color oldValue, Color newValue)
		{
			Color = newValue;
		}

		//1000/((10*0)+10) max widthorheight / 3
		//r*9/10

		protected override void Awake()
		{
			base.Awake();
			borderRect = transform.Find("Border").GetComponent<RectTransform>();
			border = borderRect.GetComponent<Image>();
			fill = transform.Find("Fill").GetComponent<Image>();
		}

		protected override void Start()
		{
			base.Start();

			Color = color;
			BorderColor = borderColor;
			BorderWidth = borderWidth;
			CornerRadius = cornerRadius;
		}

		protected override void OnHide()
		{
			base.OnHide();
			border.gameObject.SetActive(false);
			fill.gameObject.SetActive(false);
		}

		protected override void OnShow()
		{
			base.OnShow();
			border.gameObject.SetActive(true);
			fill.gameObject.SetActive(true);
		}

		public override Instance Clone()
		{
			UIView clone = (UIView) New("UIView", Parent);
			try
			{
				clone.Name = Name;
				clone.PositionOffset = PositionOffset;
				clone.PositionRelative = PositionRelative;
				clone.SizeOffset = SizeOffset;
				clone.SizeRelative = SizeRelative;
				clone.Rotation = Rotation;
				clone.PivotPoint = PivotPoint;
				clone.Visible = Visible;
				clone.Color = Color;
				clone.BorderWidth = BorderWidth;
				clone.BorderColor = BorderColor;
				clone.CornerRadius = CornerRadius;

				foreach (Instance child in GetChildren())
				{
					Instance childClone = child.Clone();
					childClone.Parent = clone;
				}
			}
			catch (System.Exception e)
			{
				Debug.LogError(e);
			}

			return clone;
		}
	}
}