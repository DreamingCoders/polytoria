using Mirror;

public class IntValue : ValueBase
{
	[SyncVar] int val;

	[Archivable, CreatorProperty]
	public int Value
	{
		get => val;
		set
		{
			val = value;
			InvokeChanged();
		}
	}

	public override Instance Clone()
	{
		IntValue clone = (IntValue) New("IntValue");

		clone.Parent = Parent;
		clone.Name = Name;
		clone.Value = Value;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
