using MoonSharp.Interpreter;
using Polytoria.Datamodel;

public class PlayerGUIProxy : InstanceProxy
{
	PlayerGUI playerGUI;

	[MoonSharpHidden]
	public PlayerGUIProxy(PlayerGUI target) : base(target)
	{
		playerGUI = target;
	}
	public float Opacity
	{
		get => playerGUI.Opacity;
		set => playerGUI.Opacity = value;
	}

	public bool Interactable
	{
		get => playerGUI.Interactable;
		set => playerGUI.Interactable = value;
	}
}