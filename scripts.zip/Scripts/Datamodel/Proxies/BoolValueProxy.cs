using MoonSharp.Interpreter;

public class BoolValueProxy : ValueBaseProxy
{
	BoolValue boolValue;

	[MoonSharpHidden]
	public BoolValueProxy(BoolValue target) : base(target)
	{
		boolValue = target;
	}

	public bool Value
	{
		get => boolValue.Value;
		set => boolValue.Value = value;
	}
}