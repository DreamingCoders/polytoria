using MoonSharp.Interpreter;

public class ClimbableProxy : PartProxy
{
	Climbable climbable;

	[MoonSharpHidden]
	public ClimbableProxy(Climbable target) : base(target)
	{
		climbable = target;
	}

	public float ClimbSpeed
	{
		get => climbable.ClimbSpeed;
		set => climbable.ClimbSpeed = value;
	}
}