using MoonSharp.Interpreter;

public class InstanceValueProxy : InstanceProxy
{
	InstanceValue instanceValue;

	[MoonSharpHidden]
	public InstanceValueProxy(InstanceValue target) : base(target)
	{
		instanceValue = target;
	}

	public Instance Value
	{
		get => instanceValue.Value;
		set => instanceValue.Value = value;
	}
}