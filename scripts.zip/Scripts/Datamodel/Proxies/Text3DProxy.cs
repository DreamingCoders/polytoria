using MoonSharp.Interpreter;
using TMPro;
using UnityEngine;
public class Text3DProxy : DynamicInstanceProxy
{
	Text3D text3D;

	[MoonSharpHidden]
	public Text3DProxy(Text3D target) : base(target)
	{
		text3D = target;
	}

	public string Text
	{
		get => text3D.Text;
		set => text3D.Text = value;
	}

	public Color Color
	{
		get => text3D.Color;
		set => text3D.Color = value;
	}

	public float FontSize
	{
		get => text3D.FontSize;
		set => text3D.FontSize = value;
	}

	public bool FaceCamera
	{
		get => text3D.FaceCamera;
		set => text3D.FaceCamera = value;
	}

	public HorizontalAlignmentOptions HorizontalAlignment
	{
		get => text3D.HorizontalAlignment;
		set => text3D.HorizontalAlignment = value;
	}

	public VerticalAlignmentOptions VerticalAlignment
	{
		get => text3D.VerticalAlignment;
		set => text3D.VerticalAlignment = value;
	}
}