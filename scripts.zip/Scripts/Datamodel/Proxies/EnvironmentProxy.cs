using System.Collections.Generic;
using MoonSharp.Interpreter;
using UnityEngine;

public class EnvironmentProxy : InstanceProxy
{
	Environment environment;
	[MoonSharpHidden]
	public EnvironmentProxy(Environment target) : base(target)
	{
		environment = target;
	}

	public SkyboxPreset Skybox
	{
		get => environment.Skybox;
		set => environment.Skybox = value;
	}

	public Vector3 Gravity
	{
		get => environment.Gravity;
		set => environment.Gravity = value;
	}

	public bool FogEnabled
	{
		get => environment.FogEnabled;
		set => environment.FogEnabled = value;
	}

	public float FogStartDistance
	{
		get => environment.FogStartDistance;
		set => environment.FogStartDistance = value;
	}

	public float FogEndDistance
	{
		get => environment.FogEndDistance;
		set => environment.FogEndDistance = value;
	}

	public Color FogColor
	{
		get => environment.FogColor;
		set => environment.FogColor = value;
	}

	public void CreateExplosion(Vector3 position, float radius = 10f, float force = 5000f, bool affectKinematic = true, DynValue func = null) => environment.CreateExplosion(position, radius, force, affectKinematic, func);
	public RayResult? Raycast(Vector3 origin, Vector3 direction, float maxDistance = Mathf.Infinity, List<Instance> ignoreList = null) => environment.Raycast(origin, direction, maxDistance, ignoreList);
	public RayResult[] RaycastAll(Vector3 origin, Vector3 direction, float maxDistance = Mathf.Infinity, List<Instance> ignoreList = null) => environment.RaycastAll(origin, direction, maxDistance, ignoreList);

}
