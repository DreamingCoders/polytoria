using MoonSharp.Interpreter;
using UnityEngine;

public class SoundProxy : DynamicInstanceProxy
{
	Sound sound;

	[MoonSharpHidden]
	public SoundProxy(Sound target) : base(target)
	{
		sound = target;
	}
	public bool Playing => sound.Playing;
	public int SoundID
	{
		get => sound.SoundID;
		set => sound.SoundID = value;
	}
	public float Pitch
	{
		get => sound.Pitch;
		set => sound.Pitch = value;
	}
	public float Length => sound.Length;
	public new Vector3 Size
	{
		get => sound.Size;
		set => sound.Size = value;
	}
	public new Vector3 Rotation
	{
		get => sound.Rotation;
		set => sound.Rotation = value;
	}
	public float Time
	{
		get => sound.Time;
		set => sound.Time = value;
	}
	public bool Autoplay
	{
		get => sound.Autoplay;
		set => sound.Autoplay = value;
	}
	public bool Loop
	{
		get => sound.Loop;
		set => sound.Loop = value;
	}
	public bool PlayInWorld
	{
		get => sound.PlayInWorld;
		set => sound.PlayInWorld = value;
	}
	public float Volume
	{
		get => sound.Volume;
		set => sound.Volume = value;
	}
	public void Play() => sound.Play();
	public void Stop() => sound.Stop();
}