using MoonSharp.Interpreter;
using Polytoria.Datamodel;
using UnityEngine;

public class UILabelProxy : UIViewProxy
{
	Polytoria.Datamodel.UILabel uiLabel;

	[MoonSharpHidden]
	public UILabelProxy(Polytoria.Datamodel.UILabel target) : base(target)
	{
		uiLabel = target;
	}

	public string Text
	{
		get => uiLabel.Text;
		set => uiLabel.Text = value;
	}

	public Color TextColor
	{
		get => uiLabel.TextColor;
		set => uiLabel.TextColor = value;
	}

	public TextJustify JustifyText
	{
		get => uiLabel.JustifyText;
		set => uiLabel.JustifyText = value;
	}

	public TextVerticalAlign VerticalAlign
	{
		get => uiLabel.VerticalAlign;
		set => uiLabel.VerticalAlign = value;
	}

	public float FontSize
	{
		get => uiLabel.FontSize;
		set => uiLabel.FontSize = value;
	}

	public float MaxFontSize
	{
		get => uiLabel.MaxFontSize;
		set => uiLabel.MaxFontSize = value;
	}

	public bool AutoSize
	{
		get => uiLabel.AutoSize;
		set => uiLabel.AutoSize = value;
	}

	public TextFontPreset Font
	{
		get => uiLabel.Font;
		set => uiLabel.Font = value;
	}
}