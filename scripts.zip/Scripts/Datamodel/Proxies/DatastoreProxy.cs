using MoonSharp.Interpreter;

public class DatastoreProxy
{
	Datastore datastore;

	[MoonSharpHidden]
	public DatastoreProxy(Datastore target)
	{
		datastore = target;
	}

	public string Key => datastore.Key;
	public bool Loading => datastore.Loading;
	public LuaEvent Loaded => datastore.Loaded;

	public void Get(string key, DynValue callback) => datastore.Get(key, callback);
	public void Set(string key, DynValue value, DynValue callback = null) => datastore.Set(key, value, callback);
	public void Remove(string key, DynValue callback = null) => datastore.Remove(key, callback);
}