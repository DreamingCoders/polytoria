using MoonSharp.Interpreter;

public class SeatProxy : PartProxy
{
	Seat seat;

	[MoonSharpHidden]
	public SeatProxy(Seat target) : base(target)
	{
		seat = target;
	}

	public Player Occupant => seat.Occupant;

	public LuaEvent Sat => seat.Sat;
	public LuaEvent Vacated => seat.Vacated;
}
