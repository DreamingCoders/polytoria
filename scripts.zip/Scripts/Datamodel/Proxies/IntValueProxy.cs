using MoonSharp.Interpreter;

public class IntValueProxy : ValueBaseProxy
{
	IntValue intValue;

	[MoonSharpHidden]
	public IntValueProxy(IntValue target) : base(target)
	{
		intValue = target;
	}

	public int Value
	{
		get => intValue.Value;
		set => intValue.Value = value;
	}
}