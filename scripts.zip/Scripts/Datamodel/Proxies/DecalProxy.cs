using MoonSharp.Interpreter;
using UnityEngine;

public class DecalProxy : DynamicInstanceProxy
{
	Decal decal;

	[MoonSharpHidden]
	public DecalProxy(Decal target) : base(target)
	{
		decal = target;
	}

	public string ImageID
	{
		get => decal.ImageID;
		set => decal.ImageID = value;
	}

	public ImageType ImageType
	{
		get => decal.ImageType;
		set => decal.ImageType = value;
	}

	public Vector2 TextureScale
	{
		get => decal.TextureScale;
		set => decal.TextureScale = value;
	}
}