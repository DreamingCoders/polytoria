using MoonSharp.Interpreter;

public class BaseScriptProxy : InstanceProxy
{
	BaseScript baseScript;
	[MoonSharpHidden]
	public BaseScriptProxy(BaseScript target) : base(target)
	{
		baseScript = target;
	}

	public new object this[string name]
	{
		get => baseScript[name];
		set => baseScript[name] = value;
	}

	public void Call(string function, params object[] args)
	{
		baseScript.Call(function, args);
	}
}
