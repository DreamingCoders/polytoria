using MoonSharp.Interpreter;

public class InstanceProxy
{
	protected Instance target;

	[MoonSharpHidden]
	public InstanceProxy(Instance target)
	{
		this.target = target;
	}

	public Instance this[string name]
	{
		get
		{
			return target[name];
		}
	}

	public Instance this[int index]
	{
		get
		{
			return target[index];
		}
	}

	public string Name
	{
		get => target.Name;
		set => target.Name = value;
	}

	public string ClassName => target.ClassName;
	public DynValue Shared => target.Shared;

	public Instance Parent
	{
		get => target.Parent;
		set => target.Parent = value;
	}

	public LuaEvent ChildRemoved => target.ChildRemoved;
	public LuaEvent ChildAdded => target.ChildAdded;
	public LuaEvent Touched => target.Touched;
	public LuaEvent TouchEnded => target.TouchEnded;
	public LuaEvent Clicked => target.Clicked;
	public LuaEvent MouseEnter => target.MouseEnter;
	public LuaEvent MouseExit => target.MouseExit;

	public Instance GetParent() => target.GetParent();
	public void SetParent(Instance parent) => target.SetParent(parent);
	public Instance FindChild(string name) => target.FindChild(name);
	public Instance[] GetChildren() => target.GetChildren();
	public Instance[] GetChildrenOfClass(string className) => target.GetChildrenOfClass(className);
	public Instance FindChildByClass(string className) => target.FindChildByClass(className);
	public bool IsA(string className) => target.IsA(className);
	public bool IsDescendantOf(Instance parent) => target.IsDescendantOf(parent);
	public void Destroy(float time = 0f) => target.Destroy(time);
	public void Delete(float time = 0f) => target.Delete(time);
	public static Instance New(string className, Instance parent = null) => Instance.New(className, parent);
	public Instance Clone() => target.Clone();
}
