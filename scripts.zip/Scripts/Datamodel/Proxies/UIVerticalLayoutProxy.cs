using MoonSharp.Interpreter;
using Polytoria.Datamodel;

public class UIVerticalLayoutProxy : UIHVLayoutProxy
{
	UIVerticalLayout uiVerticalLayout;

	[MoonSharpHidden]
	public UIVerticalLayoutProxy(UIVerticalLayout target) : base(target)
	{
		uiVerticalLayout = target;
	}
}