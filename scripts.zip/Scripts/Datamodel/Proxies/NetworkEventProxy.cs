using MoonSharp.Interpreter;

public class NetworkEventProxy : InstanceProxy
{
	NetworkEvent networkEvent;

	[MoonSharpHidden]
	public NetworkEventProxy(NetworkEvent target) : base(target)
	{
		networkEvent = target;
	}

	public LuaEvent InvokedServer => networkEvent.InvokedServer;
	public LuaEvent InvokedClient => networkEvent.InvokedClient;

	public void InvokeServer(NetMessage msg) => networkEvent.InvokeServer(msg);
	public void InvokeClient(NetMessage msg, Player player) => networkEvent.InvokeClient(msg, player);
	public void InvokeClients(NetMessage msg) => networkEvent.InvokeClients(msg);
}