using MoonSharp.Interpreter;

public class StringValueProxy : ValueBaseProxy
{
	StringValue stringValue;

	[MoonSharpHidden]
	public StringValueProxy(StringValue target) : base(target)
	{
		stringValue = target;
	}

	public string Value
	{
		get => stringValue.Value;
		set => stringValue.Value = value;
	}
}