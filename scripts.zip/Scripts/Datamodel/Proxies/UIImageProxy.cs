using MoonSharp.Interpreter;
using UnityEngine;

public class UIImageProxy : UIFieldProxy
{
	Polytoria.Datamodel.UIImage uiImage;

	[MoonSharpHidden]
	public UIImageProxy(Polytoria.Datamodel.UIImage target) : base(target)
	{
		uiImage = target;
	}

	public string ImageID
	{
		get => uiImage.ImageID;
		set => uiImage.ImageID = value;
	}

	public ImageType ImageType
	{
		get => uiImage.ImageType;
		set => uiImage.ImageType = value;
	}

	public Color Color
	{
		get => uiImage.Color;
		set => uiImage.Color = value;
	}
}