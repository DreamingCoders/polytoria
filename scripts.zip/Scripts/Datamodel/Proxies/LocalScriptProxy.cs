using MoonSharp.Interpreter;

public class LocalScriptProxy : BaseScriptProxy
{
	LocalScript localScript;
	[MoonSharpHidden]
	public LocalScriptProxy(LocalScript target) : base(target)
	{
		localScript = target;
	}
}
