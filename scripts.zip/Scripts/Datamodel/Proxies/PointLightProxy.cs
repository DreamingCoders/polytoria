using MoonSharp.Interpreter;
using UnityEngine;

public class PointLightProxy : DynamicInstanceProxy
{
	PointLight pointLight;

	[MoonSharpHidden]
	public PointLightProxy(PointLight target) : base(target)
	{
		pointLight = target;
	}

	public float Range
	{
		get => pointLight.Range;
		set => pointLight.Range = value;
	}

	public float Brightness
	{
		get => pointLight.Brightness;
		set => pointLight.Brightness = value;
	}

	public Color Color
	{
		get => pointLight.Color;
		set => pointLight.Color = value;
	}

	public bool Shadows
	{
		get => pointLight.Shadows;
		set => pointLight.Shadows = value;
	}
}