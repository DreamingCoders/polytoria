using MoonSharp.Interpreter;
using UnityEngine;

public class CameraControllerProxy
{
	CameraController cameraController;

	[MoonSharpHidden]
	public CameraControllerProxy(CameraController target)
	{
		cameraController = target;
	}

	public CameraMode Mode
	{
		get => cameraController.Mode;
		set => cameraController.Mode = value;
	}

	public float FOV
	{
		get => cameraController.FOV;
		set => cameraController.FOV = value;
	}

	public bool Orthographic
	{
		get => cameraController.Orthographic;
		set => cameraController.Orthographic = value;
	}

	public float OrthographicSize
	{
		get => cameraController.OrthographicSize;
		set => cameraController.OrthographicSize = value;
	}

	public float Distance
	{
		get => cameraController.Distance;
		set => cameraController.Distance = value;
	}

	public float MinDistance
	{
		get => cameraController.MinDistance;
		set => cameraController.MinDistance = value;
	}

	public float MaxDistance
	{
		get => cameraController.MaxDistance;
		set => cameraController.MaxDistance = value;
	}

	public float HorizontalSpeed
	{
		get => cameraController.HorizontalSpeed;
		set => cameraController.HorizontalSpeed = value;
	}

	public float VerticalSpeed
	{
		get => cameraController.VerticalSpeed;
		set => cameraController.VerticalSpeed = value;
	}

	public float ScrollSensitivity
	{
		get => cameraController.ScrollSensitivity;
		set => cameraController.ScrollSensitivity = value;
	}

	public bool ClipThroughWalls
	{
		get => cameraController.ClipThroughWalls;
		set => cameraController.ClipThroughWalls = value;
	}

	public float FlySpeed
	{
		get => cameraController.FlySpeed;
		set => cameraController.FlySpeed = value;
	}

	public float FastFlySpeed
	{
		get => cameraController.FastFlySpeed;
		set => cameraController.FastFlySpeed = value;
	}

	public float FreeLookSensitivity
	{
		get => cameraController.FreeLookSensitivity;
		set => cameraController.FreeLookSensitivity = value;
	}

	public float LerpSpeed
	{
		get => cameraController.LerpSpeed;
		set => cameraController.LerpSpeed = value;
	}

	public bool FollowLerp
	{
		get => cameraController.FollowLerp;
		set => cameraController.FollowLerp = value;
	}

	public Vector3 Position
	{
		get => cameraController.Position;
		set => cameraController.Position = value;
	}

	public Vector3 Rotation
	{
		get => cameraController.Rotation;
		set => cameraController.Rotation = value;
	}

	public bool IsFirstPerson => cameraController.IsFirstPerson;

	public void LookAt(Instance target) => cameraController.LookAt(target);
	public void LookAt(Vector3 target) => cameraController.LookAt(target);
}