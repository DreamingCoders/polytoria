using MoonSharp.Interpreter;

public class ValueBaseProxy : InstanceProxy
{
	ValueBase valueBase;

	[MoonSharpHidden]
	public ValueBaseProxy(ValueBase target) : base(target)
	{
		valueBase = target;
	}

	public LuaEvent Changed => valueBase.Changed;
}