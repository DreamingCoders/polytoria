using MoonSharp.Interpreter;
using UnityEngine;

public class SpotlightProxy : DynamicInstanceProxy
{
	Spotlight spotlight;

	[MoonSharpHidden]
	public SpotlightProxy(Spotlight target) : base(target)
	{
		spotlight = target;
	}

	public float Range
	{
		get => spotlight.Range;
		set => spotlight.Range = value;
	}

	public float Angle
	{
		get => spotlight.Angle;
		set => spotlight.Angle = value;
	}

	public float Brightness
	{
		get => spotlight.Brightness;
		set => spotlight.Brightness = value;
	}

	public Color Color
	{
		get => spotlight.Color;
		set => spotlight.Color = value;
	}

	public bool Shadows
	{
		get => spotlight.Shadows;
		set => spotlight.Shadows = value;
	}
}