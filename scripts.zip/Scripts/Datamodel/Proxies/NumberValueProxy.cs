// NumberValueProxy.cs
using MoonSharp.Interpreter;

public class NumberValueProxy : ValueBaseProxy
{
	NumberValue numberValue;

	[MoonSharpHidden]
	public NumberValueProxy(NumberValue target) : base(target)
	{
		numberValue = target;
	}

	public float Value
	{
		get => numberValue.Value;
		set => numberValue.Value = value;
	}
}