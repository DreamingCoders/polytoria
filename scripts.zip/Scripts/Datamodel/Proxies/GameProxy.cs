using MoonSharp.Interpreter;

public class GameProxy : InstanceProxy
{
	Game game;
	[MoonSharpHidden]
	public GameProxy(Game target) : base(target)
	{
		game = target;
	}

	public LuaEvent Rendered => game.Rendered;

	public int GameID => game.GameID;
	public int PlayersConnected => game.PlayersConnected;
	public int InstanceCount => game.InstanceCount;
	public int LocalInstanceCount => game.LocalInstanceCount;
}
