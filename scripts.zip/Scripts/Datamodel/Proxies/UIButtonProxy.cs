using MoonSharp.Interpreter;

public class UIButtonProxy : UILabelProxy
{
	Polytoria.Datamodel.UIButton uiButton;

	[MoonSharpHidden]
	public UIButtonProxy(Polytoria.Datamodel.UIButton target) : base(target)
	{
		uiButton = target;
	}
}