using MoonSharp.Interpreter;
using Polytoria.Datamodel;
using UnityEngine;

public class UIViewProxy : UIFieldProxy
{
	UIView uiView;

	[MoonSharpHidden]
	public UIViewProxy(UIView target) : base(target)
	{
		uiView = target;
	}

	public Color BorderColor
	{
		get => uiView.BorderColor;
		set => uiView.BorderColor = value;
	}

	public float BorderWidth
	{
		get => uiView.BorderWidth;
		set => uiView.BorderWidth = value;
	}

	public Color Color
	{
		get => uiView.Color;
		set => uiView.Color = value;
	}

	public float CornerRadius
	{
		get => uiView.CornerRadius;
		set => uiView.CornerRadius = value;
	}
}