using MoonSharp.Interpreter;
using Polytoria.Datamodel;
using UnityEngine;

public class UIHVLayoutProxy : UIFieldProxy
{
	UIHVLayout uiHVLayout;

	[MoonSharpHidden]
	public UIHVLayoutProxy(UIHVLayout target) : base(target)
	{
		uiHVLayout = target;
	}

	public float Spacing
	{
		get => uiHVLayout.Spacing;
		set => uiHVLayout.Spacing = value;
	}

	public bool ChildControlWidth
	{
		get => uiHVLayout.ChildControlWidth;
		set => uiHVLayout.ChildControlWidth = value;
	}

	public bool ChildControlHeight
	{
		get => uiHVLayout.ChildControlHeight;
		set => uiHVLayout.ChildControlHeight = value;
	}

	public bool ChildScaleWidth
	{
		get => uiHVLayout.ChildScaleWidth;
		set => uiHVLayout.ChildScaleWidth = value;
	}

	public bool ChildScaleHeight
	{
		get => uiHVLayout.ChildScaleHeight;
		set => uiHVLayout.ChildScaleHeight = value;
	}

	public bool ChildForceExpandWidth
	{
		get => uiHVLayout.ChildForceExpandWidth;
		set => uiHVLayout.ChildForceExpandWidth = value;
	}

	public bool ChildForceExpandHeight
	{
		get => uiHVLayout.ChildForceExpandHeight;
		set => uiHVLayout.ChildForceExpandHeight = value;
	}

	public int PaddingLeft
	{
		get => uiHVLayout.PaddingLeft;
		set => uiHVLayout.PaddingLeft = value;
	}

	public int PaddingRight
	{
		get => uiHVLayout.PaddingRight;
		set => uiHVLayout.PaddingRight = value;
	}

	public int PaddingTop
	{
		get => uiHVLayout.PaddingTop;
		set => uiHVLayout.PaddingTop = value;
	}

	public int PaddingBottom
	{
		get => uiHVLayout.PaddingBottom;
		set => uiHVLayout.PaddingBottom = value;
	}

	public TextAnchor ChildAlignment
	{
		get => uiHVLayout.ChildAlignment;
		set => uiHVLayout.ChildAlignment = value;
	}

	public bool ReverseAlignment
	{
		get => uiHVLayout.ReverseAlignment;
		set => uiHVLayout.ReverseAlignment = value;
	}
}
