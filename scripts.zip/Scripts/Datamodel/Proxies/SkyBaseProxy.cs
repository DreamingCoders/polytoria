using MoonSharp.Interpreter;

public class SkyBaseProxy : InstanceProxy
{
	SkyBase skyBase;

	[MoonSharpHidden]
	public SkyBaseProxy(SkyBase target) : base(target)
	{
		skyBase = target;
	}
}