using MoonSharp.Interpreter;
using UnityEngine;

public class PlayerDefaultsProxy : InstanceProxy
{
	PlayerDefaults playerDefaults;

	[MoonSharpHidden]
	public PlayerDefaultsProxy(PlayerDefaults target) : base(target)
	{
		playerDefaults = target;
	}
	public float MaxHealth
	{
		get => playerDefaults.MaxHealth;
		set => playerDefaults.MaxHealth = value;
	}

	public float WalkSpeed
	{
		get => playerDefaults.WalkSpeed;
		set => playerDefaults.WalkSpeed = value;
	}

	public float SprintSpeed
	{
		get => playerDefaults.SprintSpeed;
		set => playerDefaults.SprintSpeed = value;
	}

	public bool StaminaEnabled
	{
		get => playerDefaults.StaminaEnabled;
		set => playerDefaults.StaminaEnabled = value;
	}

	public float Stamina
	{
		get => playerDefaults.Stamina;
		set => playerDefaults.Stamina = value;
	}

	public float MaxStamina
	{
		get => playerDefaults.MaxStamina;
		set => playerDefaults.MaxStamina = value;
	}

	public float StaminaRegen
	{
		get => playerDefaults.StaminaRegen;
		set => playerDefaults.StaminaRegen = value;
	}

	public float JumpPower
	{
		get => playerDefaults.JumpPower;
		set => playerDefaults.JumpPower = value;
	}

	public float RespawnTime
	{
		get => playerDefaults.RespawnTime;
		set => playerDefaults.RespawnTime = value;
	}

	public Color ChatColor
	{
		get => playerDefaults.ChatColor;
		set => playerDefaults.ChatColor = value;
	}
}