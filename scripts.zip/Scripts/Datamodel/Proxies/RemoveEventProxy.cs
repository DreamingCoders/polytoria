using MoonSharp.Interpreter;
using UnityEngine;

public class RemoveEventProxy : InstanceProxy
{
	RemoteEvent remoteEvent;
	[MoonSharpHidden]
	public RemoveEventProxy(RemoteEvent target) : base(target)
	{
		remoteEvent = target;
	}

	public LuaEvent Invoked => remoteEvent.Invoked;

	public void Invoke(string val) => remoteEvent.Invoke(val);
	public void Invoke(bool val) => remoteEvent.Invoke(val);
	public void Invoke(float val) => remoteEvent.Invoke(val);
	public void Invoke(int val) => remoteEvent.Invoke(val);
	public void Invoke(Vector3 val) => remoteEvent.Invoke(val);
	public void Invoke(Color val) => remoteEvent.Invoke(val);
	public void Invoke(Instance val) => remoteEvent.Invoke(val);

}
