using MoonSharp.Interpreter;
using Polytoria.Datamodel;
using UnityEngine;

public class UIFieldProxy : InstanceProxy
{
	UIField uiField;

	[MoonSharpHidden]
	public UIFieldProxy(UIField target) : base(target)
	{
		uiField = target;
	}

	public LuaEvent MouseUp => uiField.MouseUp;
	public LuaEvent MouseDown => uiField.MouseDown;

	public Vector2 PositionOffset
	{
		get => uiField.PositionOffset;
		set => uiField.PositionOffset = value;
	}

	public Vector2 PositionRelative
	{
		get => uiField.PositionRelative;
		set => uiField.PositionRelative = value;
	}

	public float Rotation
	{
		get => uiField.Rotation;
		set => uiField.Rotation = value;
	}

	public Vector2 SizeOffset
	{
		get => uiField.SizeOffset;
		set => uiField.SizeOffset = value;
	}

	public Vector2 SizeRelative
	{
		get => uiField.SizeRelative;
		set => uiField.SizeRelative = value;
	}

	public Vector2 PivotPoint
	{
		get => uiField.PivotPoint;
		set => uiField.PivotPoint = value;
	}

	public bool Visible
	{
		get => uiField.Visible;
		set => uiField.Visible = value;
	}
}