using MoonSharp.Interpreter;

public class ModelProxy : DynamicInstanceProxy
{
	Model model;

	[MoonSharpHidden]
	public ModelProxy(Model target) : base(target)
	{
		model = target;
	}
}