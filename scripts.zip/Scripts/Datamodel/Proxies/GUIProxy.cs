using MoonSharp.Interpreter;

public class GUIProxy : InstanceProxy
{
	Polytoria.Datamodel.GUI gui;

	[MoonSharpHidden]
	public GUIProxy(Polytoria.Datamodel.GUI target) : base(target)
	{
		gui = target;
	}

	public bool Visible
	{
		get => gui.Visible;
		set => gui.Visible = value;
	}
}