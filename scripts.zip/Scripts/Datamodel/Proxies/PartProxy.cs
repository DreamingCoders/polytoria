using MoonSharp.Interpreter;
using UnityEngine;

public class PartProxy : DynamicInstanceProxy
{
	Part part;
	[MoonSharpHidden]
	public PartProxy(Part target) : base(target)
	{
		part = target;
	}

	public Color Color
	{
		get => part.Color;
		set => part.Color = value;
	}

	public bool Anchored
	{
		get => part.Anchored;
		set => part.Anchored = value;
	}

	public bool CanCollide
	{
		get => part.CanCollide;
		set => part.CanCollide = value;
	}

	public bool IsSpawn
	{
		get => part.IsSpawn;
		set => part.IsSpawn = value;
	}

	public bool HideStuds
	{
		get => part.HideStuds;
		set => part.HideStuds = value;
	}

	public PartShape Shape
	{
		get => part.Shape;
		set => part.Shape = value;
	}

	public PartMaterial Material
	{
		get => part.Material;
		set => part.Material = value;
	}

	public Vector3 Velocity
	{
		get => part.Velocity;
		set => part.Velocity = value;
	}

	public float Drag
	{
		get => part.Drag;
		set => part.Drag = value;
	}

	public float AngularDrag
	{
		get => part.AngularDrag;
		set => part.AngularDrag = value;
	}

	public float Mass
	{
		get => part.Mass;
		set => part.Mass = value;
	}

	public Vector3 AngularVelocity
	{
		get => part.AngularVelocity;
		set => part.AngularVelocity = value;
	}

	public bool UseGravity
	{
		get => part.UseGravity;
		set => part.UseGravity = value;
	}

	public void MovePosition(Vector3 pos) => part.MovePosition(pos);
	public void MoveRotation(Vector3 rot) => part.MoveRotation(rot);
}
