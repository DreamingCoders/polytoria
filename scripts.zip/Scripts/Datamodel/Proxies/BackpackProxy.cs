using MoonSharp.Interpreter;

public class BackpackProxy : InstanceProxy
{
	Backpack backpack;

	[MoonSharpHidden]
	public BackpackProxy(Backpack target) : base(target)
	{
		backpack = target;
	}
}