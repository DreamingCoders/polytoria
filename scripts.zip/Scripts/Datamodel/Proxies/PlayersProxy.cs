using MoonSharp.Interpreter;
public class PlayersProxy : InstanceProxy
{
	Players players;

	[MoonSharpHidden]
	public PlayersProxy(Players target) : base(target)
	{
		players = target;
	}

	public LuaEvent PlayerAdded => players.PlayerAdded;
	public LuaEvent PlayerRemoved => players.PlayerRemoved;
	public bool PlayerCollisionEnabled
	{
		get => players.PlayerCollisionEnabled;
		set => players.PlayerCollisionEnabled = value;
	}
	public Player LocalPlayer => players.LocalPlayer;
	public Player[] GetPlayers() => players.GetPlayers();
	public Player GetPlayer(string username) => players.GetPlayer(username);
	public Player GetPlayerByID(int id) => players.GetPlayerByID(id);
}