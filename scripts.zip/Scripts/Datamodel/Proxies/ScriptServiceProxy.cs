using MoonSharp.Interpreter;

public class ScriptServiceProxy : InstanceProxy
{
	ScriptService scriptService;
	[MoonSharpHidden]
	public ScriptServiceProxy(ScriptService target) : base(target)
	{
		scriptService = target;
	}
}
