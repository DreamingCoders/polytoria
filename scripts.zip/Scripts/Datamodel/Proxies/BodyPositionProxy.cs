using MoonSharp.Interpreter;
using UnityEngine;

public class BodyPositionProxy : InstanceProxy
{
	BodyPosition bodyPosition;

	[MoonSharpHidden]
	public BodyPositionProxy(BodyPosition target) : base(target)
	{
		bodyPosition = target;
	}

	public Vector3 TargetPosition
	{
		get => bodyPosition.TargetPosition;
		set => bodyPosition.TargetPosition = value;
	}

	public float Force
	{
		get => bodyPosition.Force;
		set => bodyPosition.Force = value;
	}

	public float AcceptanceDistance
	{
		get => bodyPosition.AcceptanceDistance;
		set => bodyPosition.AcceptanceDistance = value;
	}
}