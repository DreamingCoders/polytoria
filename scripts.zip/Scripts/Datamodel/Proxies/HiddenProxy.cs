using MoonSharp.Interpreter;

public class HiddenProxy : InstanceProxy
{
	Hidden hidden;

	[MoonSharpHidden]
	public HiddenProxy(Hidden target) : base(target)
	{
		hidden = target;
	}
}