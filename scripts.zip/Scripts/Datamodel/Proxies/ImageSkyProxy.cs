using MoonSharp.Interpreter;

public class ImageSkyProxy : SkyBaseProxy
{
	ImageSky imageSky;

	[MoonSharpHidden]
	public ImageSkyProxy(ImageSky target) : base(target)
	{
		imageSky = target;
	}

	public int TopId
	{
		get => imageSky.TopId;
		set => imageSky.TopId = value;
	}

	public int BottomId
	{
		get => imageSky.BottomId;
		set => imageSky.BottomId = value;
	}

	public int LeftId
	{
		get => imageSky.LeftId;
		set => imageSky.LeftId = value;
	}

	public int RightId
	{
		get => imageSky.RightId;
		set => imageSky.RightId = value;
	}

	public int FrontId
	{
		get => imageSky.FrontId;
		set => imageSky.FrontId = value;
	}

	public int BackId
	{
		get => imageSky.BackId;
		set => imageSky.BackId = value;
	}
}