using MoonSharp.Interpreter;
using Polytoria.Datamodel;

public class UIHorizontalLayoutProxy : UIHVLayoutProxy
{
	UIHorizontalLayout uiHorizontalLayout;

	[MoonSharpHidden]
	public UIHorizontalLayoutProxy(UIHorizontalLayout target) : base(target)
	{
		uiHorizontalLayout = target;
	}
}
