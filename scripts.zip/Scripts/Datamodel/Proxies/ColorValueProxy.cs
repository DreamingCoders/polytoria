using MoonSharp.Interpreter;
using UnityEngine;

public class ColorValueProxy : ValueBaseProxy
{
	ColorValue colorValue;

	[MoonSharpHidden]
	public ColorValueProxy(ColorValue target) : base(target)
	{
		colorValue = target;
	}

	public Color Value
	{
		get => colorValue.Value;
		set => colorValue.Value = value;
	}
}