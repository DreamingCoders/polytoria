using MoonSharp.Interpreter;

public class ToolProxy : DynamicInstanceProxy
{
	Tool tool;

	[MoonSharpHidden]
	public ToolProxy(Tool target) : base(target)
	{
		tool = target;
	}

	public LuaEvent Activated => tool.Activated;
	public void Play(string anim) => tool.Play(anim);
}