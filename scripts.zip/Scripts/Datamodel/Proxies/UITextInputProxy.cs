using MoonSharp.Interpreter;
using Polytoria.Datamodel;
using UnityEngine;

public class UITextInputProxy : UIViewProxy
{
	UITextInput uiTextInput;

	[MoonSharpHidden]
	public UITextInputProxy(UITextInput target) : base(target)
	{
		uiTextInput = target;
	}

	public string Text
	{
		get => uiTextInput.Text;
		set => uiTextInput.Text = value;
	}

	public Color TextColor
	{
		get => uiTextInput.TextColor;
		set => uiTextInput.TextColor = value;
	}

	public TextJustify JustifyText
	{
		get => uiTextInput.JustifyText;
		set => uiTextInput.JustifyText = value;
	}

	public TextVerticalAlign VerticalAlign
	{
		get => uiTextInput.VerticalAlign;
		set => uiTextInput.VerticalAlign = value;
	}

	public float FontSize
	{
		get => uiTextInput.FontSize;
		set => uiTextInput.FontSize = value;
	}

	public float MaxFontSize
	{
		get => uiTextInput.MaxFontSize;
		set => uiTextInput.MaxFontSize = value;
	}

	public bool AutoSize
	{
		get => uiTextInput.AutoSize;
		set => uiTextInput.AutoSize = value;
	}

	public TextFontPreset Font
	{
		get => uiTextInput.Font;
		set => uiTextInput.Font = value;
	}

	public string Placeholder
	{
		get => uiTextInput.Placeholder;
		set => uiTextInput.Placeholder = value;
	}

	public Color PlaceholderColor
	{
		get => uiTextInput.PlaceholderColor;
		set => uiTextInput.PlaceholderColor = value;
	}

	public bool IsMultiline
	{
		get => uiTextInput.IsMultiline;
		set => uiTextInput.IsMultiline = value;
	}

	public bool IsReadOnly
	{
		get => uiTextInput.IsReadOnly;
		set => uiTextInput.IsReadOnly = value;
	}

	public LuaEvent Changed => uiTextInput.Changed;
	public LuaEvent Submitted => uiTextInput.Submitted;
}