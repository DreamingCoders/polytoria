using MoonSharp.Interpreter;
using UnityEngine;

public class Vector3ValueProxy : ValueBaseProxy
{
	Vector3Value vector3Value;

	[MoonSharpHidden]
	public Vector3ValueProxy(Vector3Value target) : base(target)
	{
		vector3Value = target;
	}

	public Vector3 Value
	{
		get => vector3Value.Value;
		set => vector3Value.Value = value;
	}
}