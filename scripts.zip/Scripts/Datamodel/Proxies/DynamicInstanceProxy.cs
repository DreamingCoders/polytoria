using MoonSharp.Interpreter;
using UnityEngine;

public class DynamicInstanceProxy : InstanceProxy
{
	DynamicInstance dynamicInstance;
	[MoonSharpHidden]
	public DynamicInstanceProxy(DynamicInstance target) : base(target)
	{
		dynamicInstance = target;
	}

	public Vector3 Position
	{
		get => dynamicInstance.Position;
		set => dynamicInstance.Position = value;
	}

	public Vector3 Rotation
	{
		get => dynamicInstance.Rotation;
		set => dynamicInstance.Rotation = value;
	}

	public Vector3 LocalPosition
	{
		get => dynamicInstance.LocalPosition;
		set => dynamicInstance.LocalPosition = value;
	}

	public Vector3 LocalRotation
	{
		get => dynamicInstance.LocalRotation;
		set => dynamicInstance.LocalRotation = value;
	}

	public Vector3 Size
	{
		get => dynamicInstance.Size;
		set => dynamicInstance.Size = value;
	}

	public Vector3 Forward => dynamicInstance.Forward;
	public Vector3 Up => dynamicInstance.Up;
	public Vector3 Right => dynamicInstance.Right;

	public void LookAt(Vector3 lookTarget, Vector3 worldUp) => dynamicInstance.LookAt(lookTarget, worldUp);
	public void LookAt(Vector3 lookTarget) => dynamicInstance.LookAt(lookTarget);
	public void LookAt(DynamicInstance dynamicInstance) => dynamicInstance.LookAt(dynamicInstance);
	public void Translate(Vector3 translation) => dynamicInstance.Translate(translation);
}
