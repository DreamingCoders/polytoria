using MoonSharp.Interpreter;

public class MeshPartProxy : PartProxy
{
	MeshPart meshPart;

	[MoonSharpHidden]
	public MeshPartProxy(MeshPart target) : base(target)
	{
		meshPart = target;
	}

	public int AssetID
	{
		get => meshPart.AssetID;
		set => meshPart.AssetID = value;
	}
}