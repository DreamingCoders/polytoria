using MoonSharp.Interpreter;
using UnityEngine;

public class NPCProxy : DynamicInstanceProxy
{
	NPC npc;

	[MoonSharpHidden]
	public NPCProxy(NPC target) : base(target)
	{
		npc = target;
	}

	public LuaEvent Died => npc.Died;

	public Instance MoveTarget
	{
		get => npc.MoveTarget;
		set => npc.MoveTarget = value;
	}

	public Color HeadColor
	{
		get => npc.HeadColor;
		set => npc.HeadColor = value;
	}

	public Color TorsoColor
	{
		get => npc.TorsoColor;
		set => npc.TorsoColor = value;
	}

	public Color LeftArmColor
	{
		get => npc.LeftArmColor;
		set => npc.LeftArmColor = value;
	}

	public Color RightArmColor
	{
		get => npc.RightArmColor;
		set => npc.RightArmColor = value;
	}

	public Color LeftLegColor
	{
		get => npc.LeftLegColor;
		set => npc.LeftLegColor = value;
	}

	public Color RightLegColor
	{
		get => npc.RightLegColor;
		set => npc.RightLegColor = value;
	}

	public bool Anchored
	{
		get => npc.Anchored;
		set => npc.Anchored = value;
	}

	public float Health
	{
		get => npc.Health;
		set => npc.Health = value;
	}

	public float MaxHealth
	{
		get => npc.MaxHealth;
		set => npc.MaxHealth = value;
	}

	public int ShirtID
	{
		get => npc.ShirtID;
		set => npc.ShirtID = value;
	}

	public int PantsID
	{
		get => npc.PantsID;
		set => npc.PantsID = value;
	}

	public int FaceID
	{
		get => npc.FaceID;
		set => npc.FaceID = value;
	}

	public bool Grounded => npc.Grounded;
	public void Respawn() => npc.Respawn();
	public void Jump() => npc.Jump();
}