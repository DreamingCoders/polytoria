using MoonSharp.Interpreter;

public class DataStoreServiceProxy
{
	DataStoreService dataStoreService;

	[MoonSharpHidden]
	public DataStoreServiceProxy(DataStoreService target)
	{
		dataStoreService = target;
	}

	public Datastore GetDatastore(string key, DynValue callback) => dataStoreService.GetDatastore(key, callback);
}
