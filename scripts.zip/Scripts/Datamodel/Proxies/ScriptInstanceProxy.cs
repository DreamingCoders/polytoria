using MoonSharp.Interpreter;

public class ScriptInstanceProxy : BaseScriptProxy
{
	ScriptInstance scriptInstance;
	[MoonSharpHidden]
	public ScriptInstanceProxy(ScriptInstance target) : base(target)
	{
		scriptInstance = target;
	}
}
