using MoonSharp.Interpreter;
using UnityEngine;

public class LightingProxy : InstanceProxy
{
	Lighting lighting;

	[MoonSharpHidden]
	public LightingProxy(Lighting target) : base(target)
	{
		lighting = target;
	}

	public float SunBrightness
	{
		get => lighting.SunBrightness;
		set => lighting.SunBrightness = value;
	}

	public Color SunColor
	{
		get => lighting.SunColor;
		set => lighting.SunColor = value;
	}

	public Color AmbientColor
	{
		get => lighting.AmbientColor;
		set => lighting.AmbientColor = value;
	}

	public AmbientSource AmbientSource
	{
		get => lighting.AmbientSource;
		set => lighting.AmbientSource = value;
	}

	public bool Shadows
	{
		get => lighting.Shadows;
		set => lighting.Shadows = value;
	}
}