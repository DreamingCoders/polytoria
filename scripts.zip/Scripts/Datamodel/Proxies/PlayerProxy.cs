using MoonSharp.Interpreter;
using UnityEngine;

public class PlayerProxy : InstanceProxy
{
	Player player;
	[MoonSharpHidden]
	public PlayerProxy(Player target) : base(target)
	{
		player = target;
	}

	public float RespawnTime
	{
		get => player.RespawnTime;
		set => player.RespawnTime = value;
	}

	public Vector3 Velocity
	{
		get => player.Velocity;
		set => player.Velocity = value;
	}

	public float MaxHealth
	{
		get => player.MaxHealth;
		set => player.MaxHealth = value;
	}

	public float Health
	{
		get => player.Health;
		set => player.Health = value;
	}

	public float WalkSpeed
	{
		get => player.WalkSpeed;
		set => player.WalkSpeed = value;
	}

	public float SprintSpeed
	{
		get => player.SprintSpeed;
		set => player.SprintSpeed = value;
	}

	public bool StaminaEnabled
	{
		get => player.StaminaEnabled;
		set => player.StaminaEnabled = value;
	}

	public float Stamina
	{
		get => player.Stamina;
		set => player.Stamina = value;
	}

	public float MaxStamina
	{
		get => player.MaxStamina;
		set => player.MaxStamina = value;
	}

	public float StaminaRegen
	{
		get => player.StaminaRegen;
		set => player.StaminaRegen = value;
	}

	public float JumpPower
	{
		get => player.JumpPower;
		set => player.JumpPower = value;
	}

	public Vector3 Position
	{
		get => player.Position;
		set => player.Position = value;
	}

	public Vector3 Rotation
	{
		get => player.Rotation;
		set => player.Rotation = value;
	}

	public Color ChatColor
	{
		get => player.ChatColor;
		set => player.ChatColor = value;
	}

	public bool CanMove
	{
		get => player.CanMove;
		set => player.CanMove = value;
	}

	public bool IsInputFocused => player.IsInputFocused;
	public Seat SittingIn => player.SittingIn;
	public Vector3 Forward => player.Forward;
	public Vector3 Right => player.Right;
	public bool IsAdmin => player.IsAdmin;
	public bool IsCreator => player.IsCreator;

	public int UserID => player.UserID;
	public LuaEvent Chatted => player.Chatted;
	public LuaEvent Died => player.Died;
	public LuaEvent Respawned => player.Respawned;
	public void OwnsItem(int assetId, DynValue callOnComplete) => player.OwnsItem(assetId, callOnComplete);
	public void Kick(string reason = "You have been kicked from the server.") => player.Kick(reason);
	public void Sit(Seat seat) => player.Sit(seat);
	public void Unsit(bool addForce = true) => player.Unsit(addForce);
	public void Respawn() => player.Respawn();
}
