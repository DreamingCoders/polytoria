using MoonSharp.Interpreter;

public class TrussProxy : ClimbableProxy
{
	Truss truss;

	[MoonSharpHidden]
	public TrussProxy(Truss target) : base(target)
	{
		truss = target;
	}
}