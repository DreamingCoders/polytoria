using Mirror;

public class NumberValue : ValueBase
{
	[SyncVar] float val;

	[Archivable, CreatorProperty]
	public float Value
	{
		get => val;
		set
		{
			val = value;
			InvokeChanged();
		}
	}

	public override Instance Clone()
	{
		NumberValue clone = (NumberValue) New("NumberValue");

		clone.Parent = Parent;
		clone.Name = Name;
		clone.Value = Value;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
