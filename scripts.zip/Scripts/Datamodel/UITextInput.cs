using Mirror;
using TMPro;
using UnityEngine;

namespace Polytoria.Datamodel
{
	public class UITextInput : UIView
	{
		TMP_InputField inputField;
		TMP_Text placeholderText;

		public LuaEvent Changed = new LuaEvent();
		public LuaEvent Submitted = new LuaEvent();

		[SyncVar(hook = nameof(SyncSetTextJustify))] TextJustify justify = TextJustify.Center;
		[SyncVar(hook = nameof(SyncSetTextAlign))] TextVerticalAlign verticalAlign = TextVerticalAlign.Middle;
		[SyncVar(hook = nameof(SyncSetFontSize))] float fontSize = 16;
		[SyncVar(hook = nameof(SyncSetMaxFontSize))] float maxFontSize = 16;
		[SyncVar(hook = nameof(SyncSetAutoSize))] bool autoSize = false;
		[SyncVar(hook = nameof(SyncSetText))] string text = "";
		[SyncVar(hook = nameof(SyncSetColor))] Color textColor = Color.black;
		[SyncVar(hook = nameof(SyncSetFont))] TextFontPreset font = TextFontPreset.Montserrat;
		[SyncVar(hook = nameof(SyncSetPlaceholder))] string placeholder = "<i>Placeholder</i>";
		[SyncVar(hook = nameof(SyncSetPlaceholderColor))] Color placeholderColor = Color.grey;
		[SyncVar(hook = nameof(SyncSetIsReadOnly))] bool isReadOnly = false;
		[SyncVar(hook = nameof(SyncSetIsMultiline))] bool isMultiline = false;

		[CreatorProperty, Archivable]
		public string Text
		{
			get => inputField.text;
			set => inputField.text = text = value;
		}
		[CreatorProperty, Archivable]
		public Color TextColor
		{
			get => textColor;
			set => inputField.textComponent.color = textColor = value;
		}
		[CreatorProperty, Archivable]
		public TextJustify JustifyText
		{
			get => justify;
			set
			{
				justify = value;
				inputField.textComponent.alignment = (justify == TextJustify.Left) ? TextAlignmentOptions.Left :
								(justify == TextJustify.Center) ? TextAlignmentOptions.Center :
								(justify == TextJustify.Right) ? TextAlignmentOptions.Right :
								(justify == TextJustify.Justify) ? TextAlignmentOptions.Justified :
								(justify == TextJustify.Flush) ? TextAlignmentOptions.Flush :
								TextAlignmentOptions.Left;

				placeholderText.alignment = inputField.textComponent.alignment;
			}
		}
		[CreatorProperty, Archivable]
		public TextVerticalAlign VerticalAlign
		{
			get => verticalAlign;
			set
			{
				verticalAlign = value;
				inputField.textComponent.verticalAlignment = (verticalAlign == TextVerticalAlign.Top) ? VerticalAlignmentOptions.Top :
								(verticalAlign == TextVerticalAlign.Middle) ? VerticalAlignmentOptions.Middle :
								(verticalAlign == TextVerticalAlign.Bottom) ? VerticalAlignmentOptions.Bottom :
								VerticalAlignmentOptions.Top;

				placeholderText.verticalAlignment = inputField.textComponent.verticalAlignment;
			}
		}
		[CreatorProperty, Archivable]
		public float FontSize
		{
			get => fontSize;
			set
			{
				fontSize = value;
				if (maxFontSize < fontSize)
				{
					maxFontSize = fontSize;
				}
				inputField.textComponent.fontSize = fontSize * UILabel.FONT_SCALE;
				placeholderText.fontSize = inputField.textComponent.fontSize;
			}
		}
		[CreatorProperty, Archivable]
		public float MaxFontSize
		{
			get => maxFontSize;
			set
			{
				maxFontSize = Mathf.Max(value, fontSize);
				inputField.textComponent.fontSizeMax = maxFontSize * UILabel.FONT_SCALE;
				inputField.textComponent.fontSizeMin = fontSize * UILabel.FONT_SCALE;
				placeholderText.fontSizeMax = inputField.textComponent.fontSizeMax;
				placeholderText.fontSizeMin = inputField.textComponent.fontSizeMin;
			}
		}
		[CreatorProperty, Archivable]
		public bool AutoSize
		{
			get => autoSize;
			set
			{
				autoSize = value;
				inputField.textComponent.enableAutoSizing = autoSize;
				placeholderText.enableAutoSizing = autoSize;
			}
		}
		[CreatorProperty, Archivable]
		public TextFontPreset Font
		{
			get => font;
			set
			{
				font = value;
				switch (font)
				{
					case TextFontPreset.SourceSans:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/SourceSansPro-Regular SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/SourceSansPro-Regular SDF");
						break;
					case TextFontPreset.PressStart2P:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/PressStart2P-Regular SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/PressStart2P-Regular SDF");
						break;
					case TextFontPreset.Montserrat:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/Montserrat Regular");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/Montserrat Regular");
						break;
					case TextFontPreset.RobotoMono:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/RobotoMono-VariableFont_wght SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/RobotoMono-VariableFont_wght SDF");
						break;
					case TextFontPreset.Rubik:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/Rubik-VariableFont_wght SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/Rubik-VariableFont_wght SDF");
						break;
					case TextFontPreset.Poppins:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/Poppins-Regular SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/Poppins-Regular SDF");
						break;
					case TextFontPreset.Domine:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/Domine-VariableFont_wght SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/Domine-VariableFont_wght SDF");
						break;
					case TextFontPreset.Fredoka:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/Fredoka-VariableFont_wdth,wght SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/Fredoka-VariableFont_wdth,wght SDF");
						break;
					case TextFontPreset.ComicNeue:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/ComicNeue-Regular SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/ComicNeue-Regular SDF");
						break;
					case TextFontPreset.Orbitron:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/Orbitron-VariableFont_wght SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/Orbitron-VariableFont_wght SDF");
						break;
					default:
						inputField.textComponent.font = Resources.Load<TMP_FontAsset>("Fonts/SourceSansPro-Regular SDF");
						placeholderText.font = Resources.Load<TMP_FontAsset>("Fonts/SourceSansPro-Regular SDF");
						break;
				}
			}
		}

		[CreatorProperty, Archivable]
		public string Placeholder
		{
			get => placeholder;
			set
			{
				placeholder = value;
				placeholderText.text = placeholder;
			}
		}

		[CreatorProperty, Archivable]
		public Color PlaceholderColor
		{
			get => placeholderColor;
			set
			{
				placeholderColor = value;
				placeholderText.color = placeholderColor;
			}
		}

		[CreatorProperty, Archivable]
		public bool IsMultiline
		{
			get => isMultiline;
			set
			{
				isMultiline = value;
				inputField.lineType = (isMultiline) ? TMP_InputField.LineType.MultiLineNewline : TMP_InputField.LineType.SingleLine;
			}
		}

		[CreatorProperty, Archivable]
		public bool IsReadOnly
		{
			get => isReadOnly;
			set
			{
				isReadOnly = value;
				inputField.readOnly = isReadOnly;
			}
		}

		private void SyncSetText(string oldtext, string newtext)
		{
			Text = text;
		}
		private void SyncSetTextJustify(TextJustify oldValue, TextJustify newValue)
		{
			JustifyText = newValue;
		}
		private void SyncSetTextAlign(TextVerticalAlign oldValue, TextVerticalAlign newValue)
		{
			VerticalAlign = newValue;
		}
		private void SyncSetFontSize(float oldValue, float newValue)
		{
			FontSize = newValue;
		}
		private void SyncSetMaxFontSize(float oldValue, float newValue)
		{
			MaxFontSize = newValue;
		}
		private void SyncSetAutoSize(bool oldValue, bool newValue)
		{
			AutoSize = newValue;
		}
		private void SyncSetColor(Color oldValue, Color newValue)
		{
			TextColor = newValue;
		}
		private void SyncSetFont(TextFontPreset oldValue, TextFontPreset newValue)
		{
			Font = newValue;
		}
		private void SyncSetPlaceholder(string oldValue, string newValue)
		{
			Placeholder = newValue;
		}
		private void SyncSetPlaceholderColor(Color oldValue, Color newValue)
		{
			PlaceholderColor = newValue;
		}
		private void SyncSetIsMultiline(bool oldValue, bool newValue)
		{
			IsMultiline = newValue;
		}
		private void SyncSetIsReadOnly(bool oldValue, bool newValue)
		{
			IsReadOnly = newValue;
		}

		protected override void Awake()
		{
			base.Awake();
			inputField = GetComponent<TMP_InputField>();
			placeholderText = inputField.placeholder as TMP_Text;

			if (CreatorController.IsCreator)
			{
				inputField.interactable = false;
			}

			inputField.onSubmit.AddListener((s) => Submitted.Invoke(s));
			inputField.onValueChanged.AddListener((s) => Changed.Invoke(s));
		}

		protected override void Start()
		{
			base.Start();

			Text = text;
			JustifyText = justify;
			VerticalAlign = verticalAlign;
			FontSize = fontSize;
			MaxFontSize = maxFontSize;
			AutoSize = autoSize;
			TextColor = textColor;
			Font = font;
			Placeholder = placeholder;
			PlaceholderColor = placeholderColor;
		}

		protected override void OnHide()
		{
			base.OnHide();
			inputField.enabled = false;
		}

		protected override void OnShow()
		{
			base.OnShow();
			inputField.enabled = true;
		}

		public override Instance Clone()
		{
			UITextInput clone = (UITextInput) New("UITextInput", Parent);
			try
			{
				clone.Name = Name;
				clone.PositionOffset = PositionOffset;
				clone.PositionRelative = PositionRelative;
				clone.SizeOffset = SizeOffset;
				clone.SizeRelative = SizeRelative;
				clone.Rotation = Rotation;
				clone.PivotPoint = PivotPoint;
				clone.Visible = Visible;
				clone.Text = Text;
				clone.Font = Font;
				clone.FontSize = FontSize;
				clone.Color = Color;
				clone.BorderWidth = BorderWidth;
				clone.BorderColor = BorderColor;
				clone.CornerRadius = CornerRadius;
				clone.AutoSize = AutoSize;
				clone.JustifyText = JustifyText;
				clone.VerticalAlign = VerticalAlign;
				clone.MaxFontSize = MaxFontSize;
				clone.TextColor = TextColor;
				clone.Placeholder = Placeholder;
				clone.PlaceholderColor = PlaceholderColor;
				clone.IsMultiline = IsMultiline;
				clone.IsReadOnly = IsReadOnly;

				foreach (Instance child in GetChildren())
				{
					Instance childClone = child.Clone();
					childClone.Parent = clone;
				}
			}
			catch (System.Exception e)
			{
				Debug.LogError(e);
			}

			return clone;
		}

	}
}