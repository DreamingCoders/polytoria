using Mirror;
using UnityEngine;

public class PlayerDefaults : Instance
{
	[SyncVar] float maxHealth = 100;
	[SyncVar] float walkSpeed = 16f;
	[SyncVar] float sprintSpeed = 25f;
	[SyncVar] bool staminaEnabled = true;
	[SyncVar] float stamina = 0f;
	[SyncVar] float maxStamina = 3f;
	[SyncVar] float staminaRegen = 1.2f;
	[SyncVar] float jumpPower = 36f;
	[SyncVar] float respawnTime = 5f;
	[SyncVar] Color chatColor = Color.white;

	[CreatorProperty, Archivable]
	public float MaxHealth
	{
		get => maxHealth;
		set => maxHealth = value;
	}

	[CreatorProperty, Archivable]
	public float WalkSpeed
	{
		get => walkSpeed;
		set => walkSpeed = value;
	}

	[CreatorProperty, Archivable]
	public float SprintSpeed
	{
		get => sprintSpeed;
		set => sprintSpeed = value;
	}

	[CreatorProperty, Archivable]
	public bool StaminaEnabled
	{
		get => staminaEnabled;
		set => staminaEnabled = value;
	}

	[CreatorProperty, Archivable]
	public float Stamina
	{
		get => stamina;
		set => stamina = value;
	}

	[CreatorProperty, Archivable]
	public float MaxStamina
	{
		get => maxStamina;
		set => maxStamina = value;
	}

	[CreatorProperty, Archivable]
	public float StaminaRegen
	{
		get => staminaRegen;
		set => staminaRegen = value;
	}

	[CreatorProperty, Archivable]
	public float JumpPower
	{
		get => jumpPower;
		set => jumpPower = value;
	}

	[CreatorProperty, Archivable]
	public float RespawnTime
	{
		get => respawnTime;
		set => respawnTime = value;
	}

	[CreatorProperty, Archivable]
	public Color ChatColor
	{
		get => chatColor;
		set => chatColor = value;
	}

	protected override void Awake()
	{
		canReparent = false;
		base.Awake();
	}

	protected override void Start()
	{
		base.Start();
		if (isServer)
		{
			if (FindChildOfType<Backpack>() == null)
			{
				Backpack backpack = Instantiate(Resources.Load<Backpack>("Datamodel/Backpack"), transform);
				backpack.name = "Backpack";
				NetworkServer.Spawn(backpack.gameObject);
			}
		}
	}

	public void LoadDefaults(Player player)
	{
		if (CreatorController.IsCreator) return;

		if (isServer)
		{
			if (player != null)
			{
				player.MaxHealth = maxHealth;
				player.WalkSpeed = walkSpeed;
				player.SprintSpeed = sprintSpeed;
				player.StaminaEnabled = staminaEnabled;
				player.Stamina = stamina;
				player.MaxStamina = maxStamina;
				player.StaminaRegen = staminaRegen;
				player.JumpPower = jumpPower;
				player.RespawnTime = respawnTime;
				player.ChatColor = chatColor;

				if (FindChildOfType<Backpack>() != null)
				{
					foreach (Tool tool in FindChildOfType<Backpack>().GetChildrenOfType<Tool>())
					{
						Tool copy = (Tool) tool.Clone();
						copy.Parent = player.FindChildOfType<Backpack>();
					}
				}

				foreach (Instance i in GetChildren())
				{
					if (i is Backpack) continue;
					Instance copy = i.Clone();
					copy.Parent = player;
				}
			}
		}
		else
		{
			CmdLoadDefaults(player);
		}
	}

	[Command]
	void CmdLoadDefaults(Player player)
	{
		LoadDefaults(player);
	}
}
