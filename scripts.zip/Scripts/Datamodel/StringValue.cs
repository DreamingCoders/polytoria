using Mirror;

public class StringValue : ValueBase
{
	[SyncVar] string val;

	[Archivable, CreatorProperty]
	public string Value
	{
		get => val;
		set
		{
			val = value;
			InvokeChanged();
		}
	}

	public override Instance Clone()
	{
		StringValue clone = (StringValue) New("StringValue");

		clone.Parent = Parent;
		clone.Name = Name;
		clone.Value = Value;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
