using System;
using System.Collections;
using kcp2k;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;

public class Game : Instance
{
	public static Game singleton;
	public event Action Loaded;
	public LuaEvent Rendered = new LuaEvent();

	[SyncVar] int gameID;
	[SyncVar] int playersConnected;
	public static string GameName;

	public int GameID => gameID;

	public int PlayersConnected => playersConnected;

	[SyncVar] public int instanceCount;

	int localInstanceCount;

	public int InstanceCount => instanceCount;
	public int LocalInstanceCount => localInstanceCount;

	public static event Action GameLoadedLocally;

	public bool isGameLoaded;

	protected override void Awake()
	{
		singleton = this;
		canReparent = false;
		GameLoadedLocally += () => { isGameLoaded = true; };
		if (isServer)
			Loaded += () => { GameLoadedLocally?.Invoke(); };
		base.Awake();
	}

	public override void OnStartServer()
	{
		base.OnStartServer();
		if (!CreatorController.IsCreator)
		{
			if (!LaunchController.isSolo)
			{
				if (LaunchController.isLocal && LaunchController.localMapPath != "" && LaunchController.localMapPath != null)
				{
					GetComponent<GameIO>().LoadFromFile(LaunchController.localMapPath);
				}
				else
				{
					GetComponent<GameIO>().Load(NetworkController.singleton.PlaceID);
				}
			}
			else
			{
				GetComponent<GameIO>().LoadFromFile(LaunchController.soloMapPath);
			}
		}
	}

	public void InvokeLoaded()
	{
		Loaded?.Invoke();
	}

	public void SetGameID(int id)
	{
		gameID = id;
	}

	protected override void Start()
	{
		Name = "Game";

		if (!isServer)
		{
			StartCoroutine(WaitForGameLoad());
		}
	}

	[MoonSharpHidden]
	public IEnumerator WaitForGameLoad()
	{
		if (!isServer)
		{
			float startTime = Time.time;

			while (InstanceCount <= 2 || LocalInstanceCount < InstanceCount)
			{
				if (Time.time - startTime >= 15f) break;
				yield return new WaitForEndOfFrame();
			}

			NetworkManager.singleton.GetComponent<KcpTransport>().Timeout = 10000;
		}

		GameLoadedLocally?.Invoke();
	}

	private void Update()
	{
		Rendered?.Invoke(Time.deltaTime);

		if (isServer)
		{
			playersConnected = NetworkServer.connections.Count;
		}
	}

	[MoonSharpHidden]
	public void InstanceAdded()
	{
		if (isServer)
		{
			instanceCount++;
		}
		localInstanceCount++;
	}


	[MoonSharpHidden]
	public void InstanceRemoved()
	{
		if (isServer)
		{
			instanceCount--;
		}
		localInstanceCount--;
	}
}
