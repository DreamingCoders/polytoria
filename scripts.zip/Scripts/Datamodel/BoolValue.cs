using Mirror;

public class BoolValue : ValueBase
{
	[SyncVar] bool val;

	[Archivable, CreatorProperty]
	public bool Value
	{
		get => val;
		set
		{
			InvokeChanged();
			val = value;
		}
	}

	public override Instance Clone()
	{
		BoolValue clone = (BoolValue) New("BoolValue");

		clone.Parent = Parent;
		clone.Name = Name;
		clone.Value = Value;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
