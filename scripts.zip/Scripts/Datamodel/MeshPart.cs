using Mirror;
using UnityEngine;

public class MeshPart : Part
{
	[SyncVar] protected int assetID = 24742;

	[CreatorProperty, Archivable]
	public int AssetID
	{
		get => assetID;
		set
		{
			assetID = value;
			LoadMesh();

			if (isServer)
			{
				RpcSetAssetID(value);
			}
		}
	}

	public new PartShape Shape => PartShape.Brick;
	public new Color Color => Color.white;
	public new PartMaterial Material => PartMaterial.SmoothPlastic;

	[CreatorProperty, Archivable]
	public new bool CanCollide
	{
		get => canCollide;
		set
		{
			canCollide = value;

			GetComponent<Collider>().isTrigger = !value;

			if (isServer)
			{
				RpcSetCanCollide(value);
			}
		}
	}

	protected override void Start()
	{
		base.Start();

		AssetID = assetID;
	}

	void LoadMesh()
	{
		MeshPartLoadController.Instance.LoadMesh(new MeshPartLoadRequest(assetID, this));
	}

	public void Hide() => OnHide();

	protected override void OnHide()
	{
		base.OnHide();

		GetComponent<Collider>().enabled = false;

		foreach (MeshRenderer mr in GetComponentsInChildren<MeshRenderer>())
		{
			mr.enabled = false;
		}

		// foreach (MeshCollider col in GetComponentsInChildren<MeshCollider>())
		// {
		//	 col.enabled = false;
		// }

		GetComponent<Rigidbody>().isKinematic = true;
	}
	protected override void OnShow()
	{
		base.OnShow();

		foreach (MeshRenderer mr in GetComponentsInChildren<MeshRenderer>())
		{
			mr.enabled = true;
		}

		GetComponent<Collider>().enabled = true;

		//trigger colliders
		CanCollide = CanCollide;
		Anchored = Anchored;
	}

	public override Instance Clone()
	{
		MeshPart clone = (MeshPart) New("MeshPart", Parent);
		clone.Name = Name;
		clone.CanCollide = CanCollide;
		clone.Anchored = Anchored;
		clone.Position = Position;
		clone.Rotation = Rotation;
		clone.Size = Size;
		clone.AssetID = AssetID;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}

	#region Property network sync

	[ClientRpc]
	void RpcSetAssetID(int id)
	{
		if (isServer) return;
		AssetID = id;
	}

	#endregion
}
