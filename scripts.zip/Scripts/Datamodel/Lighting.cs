using System.Linq;
using Mirror;
using UnityEngine;

public class Lighting : Instance
{
	Light sun;
	[SyncVar] private float sunBrightness = 1f;
	[SyncVar] private Color sunColor = Color.white;
	[SyncVar] private Color ambientColor;
	[SyncVar] private AmbientSource ambientSource = AmbientSource.Skybox;
	[SyncVar(hook = nameof(OnShadowsChanged))] private bool shadows = true;

	[CreatorProperty, Archivable]
	public float SunBrightness
	{
		get { return sun.intensity; }
		set
		{
			sunBrightness = value;
			CheckForSun();
			sun.intensity = value;
			if (isServer)
			{
				RpcSetSunBrightness(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public Color SunColor
	{
		get { return sun.color; }
		set
		{
			sunColor = value;
			CheckForSun();
			sun.color = value;
			if (isServer)
			{
				RpcSetSunColor(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public Color AmbientColor
	{
		get { return RenderSettings.ambientLight; }
		set
		{
			ambientColor = value;
			RenderSettings.ambientLight = value;
			//DynamicGI.UpdateEnvironment();

			if (isServer)
			{
				RpcSetAmbientColor(value);
			}
		}
	}
	[CreatorProperty, Archivable]
	public AmbientSource AmbientSource
	{
		get { return ambientSource; }
		set
		{
			ambientSource = value;

			switch (value)
			{
				case AmbientSource.Skybox:
					RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Skybox;
					break;
				case AmbientSource.AmbientColor:
					RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
					break;
			}

			DynamicGI.UpdateEnvironment();

			if (isServer)
			{
				RpcSetAmbientSource(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public bool Shadows
	{
		get => shadows;
		set
		{
			shadows = value;
			sun.shadows = value ? LightShadows.Soft : LightShadows.None;
		}
	}


	protected override void Awake()
	{
		canReparent = false;
		base.Awake();
	}

	protected override void Start()
	{
		base.Start();
		CheckForSun();

		if (!isServer)
		{
			SunBrightness = sunBrightness;
			SunColor = sunColor;
			AmbientColor = ambientColor;
			AmbientSource = ambientSource;
			Shadows = shadows;
		}
		else
		{
			sunColor = sun.color;
		}
	}

	void CheckForSun()
	{
		if (sun != null) return;
		sun = GameObject.Find("Directional Light").GetComponent<Light>();

		if (sun == null)
		{
			sun = FindObjectsOfType<Light>().First(i => i.type == LightType.Directional);
		}
	}

	[ClientRpc]
	void RpcSetSunBrightness(float b)
	{
		if (isServer) return;
		SunBrightness = b;
	}

	[ClientRpc]
	void RpcSetSunColor(Color c)
	{
		if (isServer) return;
		SunColor = c;
	}

	[ClientRpc]
	void RpcSetAmbientColor(Color c)
	{
		if (isServer) return;
		AmbientColor = c;
	}

	[ClientRpc]
	void RpcSetAmbientSource(AmbientSource source)
	{
		if (isServer) return;
		AmbientSource = source;
	}

	void OnShadowsChanged(bool oldValue, bool newValue)
	{
		if (isServer) return;
		Shadows = newValue;
	}
}

public enum AmbientSource
{
	Skybox,
	AmbientColor
}
