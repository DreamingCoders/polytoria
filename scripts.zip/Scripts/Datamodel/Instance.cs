using System;
using System.Collections.Generic;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;

public class Instance : NetworkBehaviour
{
	[SyncVar] protected string _name;
	protected string className;
	protected bool canReparent = true;
	protected bool hidesMembers = false;

	public bool CanReparent => canReparent;

	private DynValue shared = DynValue.NewPrimeTable();

	public LuaEvent ChildRemoved = new LuaEvent();
	public LuaEvent ChildAdded = new LuaEvent();
	public LuaEvent Touched = new LuaEvent();
	public LuaEvent TouchEnded = new LuaEvent();
	public LuaEvent MouseHover = new LuaEvent();
	public LuaEvent MouseHoverEnded = new LuaEvent();
	public LuaEvent Clicked = new LuaEvent();
	public LuaEvent MouseEnter = new LuaEvent();
	public LuaEvent MouseExit = new LuaEvent();

	[MoonSharpHidden] public event Action<Instance> _DescendantAdded;
	[MoonSharpHidden] public event Action _ParentChanged;
	[MoonSharpHidden] public event Action<Instance> _Touched;

	[MoonSharpHidden] public int DescendantLevel => GetDescendantLevel();

	public Instance this[string name]
	{
		get
		{
			return FindChild(name);
		}
	}

	public Instance this[int index]
	{
		get
		{
			return GetChildren()[index - 1];
		}
	}

	[CreatorProperty, Archivable]
	public string Name
	{
		get => _name;
		set
		{
			transform.name = _name = value;

			if (isServer)
			{
				RpcSetName(value);
			}
		}
	}

	public string FullName
	{
		get
		{
			Instance cursor = this;
			string result = Name;

			while (cursor.Parent is Instance instance)
			{
				cursor = instance;
				result = instance.Name + "." + result;
			}

			return result;
		}
	}

	[CreatorProperty]
	public string ClassName => className;

	public DynValue Shared
	{
		get
		{
			return shared;
		}
	}

	public Instance Parent
	{
		get => GetParent();
		set => SetParent(value);
	}

	public Instance GetParent()
	{
		Instance p = null;
		if (this.gameObject == null)
		{
			return null;
		}
		Transform par = transform.parent;
		while (par != null)
		{
			p = par.GetComponent<Instance>();
			if (p) return p;

			par = par.parent;
		}
		return p;
	}

	public void SetParent(Instance par)
	{
		Instance previousParent = Parent;

		if (par == null) return;
		if (!canReparent && Parent != null) return;
		if (Parent) Parent.ChildRemoved?.Invoke(this);
		par.ChildAdded?.Invoke(this);
		transform.SetParent(par.transform);//CreatorController.IsCreator);

		Instance p = Parent;

		while (p != null)
		{
			p._DescendantAdded?.Invoke(this);
			p = p.Parent;
		}

		if (par.hidesMembers || par.isHidden)
		{
			OnHide();
		}
		else
		{
			if (isHidden)
			{
				OnShow();
			}
		}

		_ParentChanged?.Invoke();

		if (isServer)
		{
			RpcSetParent(par.transform);
		}
	}

	[MoonSharpHidden]
	public bool isHidden = false;

	protected virtual void OnHide()
	{
		isHidden = true;

		foreach (Instance child in GetChildren())
		{
			child.OnHide();
		}
	}

	protected virtual void OnShow()
	{
		isHidden = false;

		foreach (Instance child in GetChildren())
		{
			child.OnShow();
		}
	}

	[ClientRpc]
	void RpcSetParent(Transform par)
	{
		if (isServer) return;
		if (par == null) return;
		transform.SetParent(par);
		SetParent(par.GetComponent<Instance>());
	}

	public Instance FindChild(string name)
	{

		foreach (Instance instance in GetChildren())
		{
			if (instance.Name == name)
				return instance;
		}

		return null;
	}

	public Instance[] GetChildren()
	{
		List<Instance> instances = new List<Instance>();
		// foreach (Transform t in transform)
		// {
		//     Instance i = t.GetComponent<Instance>();

		//     if (i && t.gameObject.activeInHierarchy)
		//     {
		//         instances.Add(i);
		//     }
		// }

		for (int i = 0; i < transform.childCount; i++)
		{
			Instance ins = transform.GetChild(i).GetComponent<Instance>();

			if (ins && ins.gameObject.activeInHierarchy)
			{
				instances.Add(ins);
			}
		}

		return instances.ToArray();
	}

	[MoonSharpHidden]
	public List<Instance> GetChildrenAsList()
	{
		List<Instance> instances = new List<Instance>();

		for (int i = 0; i < transform.childCount; i++)
		{
			Instance ins = transform.GetChild(i).GetComponent<Instance>();

			if (ins && ins.gameObject.activeInHierarchy)
			{
				instances.Add(ins);
			}
		}

		return instances;
	}

	public Instance[] GetChildrenOfClass(string className)
	{
		List<Instance> instances = new List<Instance>();

		for (int i = 0; i < transform.childCount; i++)
		{
			Instance ins = transform.GetChild(i).GetComponent<Instance>();

			if (ins && ins.gameObject.activeInHierarchy && ins.ClassName == className)
			{
				instances.Add(ins);
			}
		}

		return instances.ToArray();
	}

	public T[] GetChildrenOfType<T>() where T : Instance
	{
		List<T> children = new List<T>();

		foreach (Instance instance in GetChildren())
		{
			if (instance is T c)
			{
				children.Add(c);
			}
		}

		return children.ToArray();
	}

	public T FindChildOfType<T>() where T : Instance
	{
		foreach (Instance instance in GetChildren())
		{
			if (instance is T c)
				return c;
		}

		return null;
	}


	public Instance FindChildByClass(string className)
	{
		foreach (Instance instance in GetChildren())
		{
			if (instance.ClassName == className)
				return instance;
		}
		return null;
	}

	public bool IsA(string className)
	{
		return ClassName == className || (className == "Part" && ClassName == "Truss");
	}

	public bool IsDescendantOf(Instance other)
	{
		return transform.IsChildOf(other.transform);
	}

	public void Destroy(float time = 0f)
	{
		if (!canReparent) return;
		if (Parent != null) Parent.ChildRemoved?.Invoke(this);

		Destroy(gameObject, time);
	}

	public void Delete(float time = 0f)
	{
		Destroy(time);
	}

	[ClientRpc]
	void RpcSetName(string n)
	{
		if (isServer) return;
		Name = n;
	}

	[Command(requiresAuthority = false)]
	void RequestParent(NetworkConnectionToClient sender = null)
	{
		SetParentTargetRpc(sender, transform.parent);
	}

	[TargetRpc]
	void SetParentTargetRpc(NetworkConnection target, Transform par)
	{
		if (par == null) return;
		transform.SetParent(par);
		Instance i = par.GetComponent<Instance>();
		if (i)
			SetParent(i);
	}

	protected virtual void Awake()
	{
		className = GetType().Name;
		_name = className;
	}

	protected virtual void Start()
	{
		if (!isServer && !CreatorController.IsCreator)
		{
			if (Game.singleton.isGameLoaded)
			{
				RequestParent();
			}
			else
			{
				Game.GameLoadedLocally += OnGameLoaded;
			}
			Name = _name;
		}

		if (!netIdentity.serverOnly)
			Game.singleton.InstanceAdded();
	}

	private void OnGameLoaded()
	{
		RequestParent();
		Game.GameLoadedLocally -= OnGameLoaded;
	}

	protected virtual void OnDestroy()
	{
		if (!netIdentity.serverOnly)
			Game.singleton.InstanceRemoved();
	}

	public static Instance New(string className, Instance parent = null)
	{
		if (parent == null)
		{
			parent = Game.singleton.FindChildByClass("Environment");
		}

		Instance instance;

		switch (className)
		{
			case "Part":
				instance = Resources.Load<Part>("Datamodel/Part");
				break;
			case "Model":
				instance = Resources.Load<Model>("Datamodel/Model");
				break;
			case "Text3D":
				instance = Resources.Load<Text3D>("Datamodel/Text3D");
				break;
			case "PointLight":
				instance = Resources.Load<PointLight>("Datamodel/PointLight");
				break;
			case "RemoteEvent":
				instance = Resources.Load<RemoteEvent>("Datamodel/RemoteEvent");
				break;
			case "ScriptInstance":
				instance = Resources.Load<ScriptInstance>("Datamodel/ScriptInstance");
				break;
			case "LocalScript":
				instance = Resources.Load<LocalScript>("Datamodel/LocalScript");
				break;
			case "NPC":
				instance = Resources.Load<NPC>("Datamodel/NPC");
				break;
			case "Sound":
				instance = Resources.Load<Sound>("Datamodel/Sound");
				break;
			case "Truss":
				instance = Resources.Load<Truss>("Datamodel/Truss");
				break;
			case "Decal":
				instance = Resources.Load<Decal>("Datamodel/Decal");
				break;
			case "Tool":
				instance = Resources.Load<Tool>("Datamodel/Tool");
				break;
			case "Spotlight":
				instance = Resources.Load<Spotlight>("Datamodel/Spotlight");
				break;
			case "BoolValue":
				instance = Resources.Load<ValueBase>("Datamodel/BoolValue");
				break;
			case "ColorValue":
				instance = Resources.Load<ValueBase>("Datamodel/ColorValue");
				break;
			case "IntValue":
				instance = Resources.Load<ValueBase>("Datamodel/IntValue");
				break;
			case "InstanceValue":
				instance = Resources.Load<ValueBase>("Datamodel/InstanceValue");
				break;
			case "StringValue":
				instance = Resources.Load<ValueBase>("Datamodel/StringValue");
				break;
			case "NumberValue":
				instance = Resources.Load<ValueBase>("Datamodel/NumberValue");
				break;
			case "Vector3Value":
				instance = Resources.Load<ValueBase>("Datamodel/Vector3Value");
				break;
			case "MeshPart":
				instance = Resources.Load<MeshPart>("Datamodel/MeshPart");
				break;
			case "BodyPosition":
				instance = Resources.Load<BodyPosition>("Datamodel/BodyPosition");
				break;
			case "Seat":
				instance = Resources.Load<Seat>("Datamodel/Seat");
				break;
			case "ImageSky":
				instance = Resources.Load<ImageSky>("Datamodel/ImageSky");
				break;
			case "NetworkEvent":
				instance = Resources.Load<NetworkEvent>("Datamodel/NetworkEvent");
				break;
			case "GUI":
				instance = Resources.Load<Polytoria.Datamodel.GUI>("Datamodel/GUI");
				break;
			case "UILabel":
				instance = Resources.Load<Polytoria.Datamodel.UILabel>("Datamodel/UILabel");
				instance.name = "Label";
				break;
			case "UIView":
				instance = Resources.Load<Polytoria.Datamodel.UIView>("Datamodel/UIView");
				instance.name = "Rectangle";
				break;
			case "UIButton":
				instance = Resources.Load<Polytoria.Datamodel.UIButton>("Datamodel/UIButton");
				instance.name = "Button";
				break;
			case "UIImage":
				instance = Resources.Load<Polytoria.Datamodel.UIImage>("Datamodel/UIImage");
				instance.name = "Image";
				break;
			case "UITextInput":
				instance = Resources.Load<Polytoria.Datamodel.UITextInput>("Datamodel/UITextInput");
				instance.name = "Text Input";
				break;
			case "UIHorizontalLayout":
				instance = Resources.Load<Polytoria.Datamodel.UIHorizontalLayout>("Datamodel/UIHorizontalLayout");
				instance.name = "Horizontal Layout";
				break;
			case "UIVerticalLayout":
				instance = Resources.Load<Polytoria.Datamodel.UIVerticalLayout>("Datamodel/UIVerticalLayout");
				instance.name = "Vertical Layout";
				break;
			default:
				throw new Exception("Class \"" + className + "\" not found.");
		}

		instance = Instantiate(instance);

		if (Game.singleton.GetComponent<NetworkIdentity>().isServer)
		{
			NetworkServer.Spawn(instance.gameObject);
		}

		instance.Name = instance.ClassName;
		instance.Parent = parent;

		return instance;
	}

	protected virtual void OnCollisionEnter(Collision collision)
	{
		GameObject other = collision.gameObject;
		Instance i = other.GetComponent<Instance>();
		if (i != null && !isHidden && !i.isHidden)
		{
			Touched?.Invoke(i);
			_Touched?.Invoke(i);
		}
	}

	protected virtual void OnTriggerEnter(Collider collider)
	{
		GameObject other = collider.gameObject;
		Instance i = other.GetComponent<Instance>();
		if (i != null && !isHidden && !i.isHidden)
		{
			Touched?.Invoke(i);
			_Touched?.Invoke(i);
		}
	}

	protected virtual void OnCollisionExit(Collision collision)
	{
		GameObject other = collision.gameObject;
		Instance i = other.GetComponent<Instance>();
		if (i != null && !isHidden && !i.isHidden)
		{
			TouchEnded?.Invoke(i);
		}
	}

	protected virtual void OnTriggerExit(Collider collider)
	{
		GameObject other = collider.gameObject;
		Instance i = other.GetComponent<Instance>();
		if (i != null && !isHidden && !i.isHidden)
		{
			TouchEnded?.Invoke(i);
		}
	}


	int GetDescendantLevel()
	{
		int i = 1;
		Transform t = transform;

		if (!transform.IsChildOf(Game.singleton.transform))
		{
			return 0;
		}

		while (true)
		{
			if (t.parent == Game.singleton.transform)
			{
				return i;
			}
			else
			{
				i++;
				t = t.parent;
			}
		}
	}

	private void OnMouseDown()
	{
		if (CreatorController.IsCreator) return;

		if (!isServer)
		{
			CmdClicked();
		}

		Clicked?.Invoke(Game.singleton.FindChildOfType<Players>().LocalPlayer);
	}

	bool isMouseOver = false;

	private void OnMouseEnter()
	{
		if (CreatorController.IsCreator) return;
		if (!isMouseOver)
		{
			isMouseOver = true;
			MouseEnter?.Invoke();
		}
	}

	private void OnMouseExit()
	{
		if (CreatorController.IsCreator) return;
		if (isMouseOver)
		{
			isMouseOver = false;
			MouseExit?.Invoke();
		}
	}

	[Command(requiresAuthority = false)]
	void CmdClicked(NetworkConnectionToClient sender = null)
	{
		Clicked?.Invoke(PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId));
	}

	public virtual Instance Clone() { return null; }
}
[AttributeUsage(AttributeTargets.Property)] public class CreatorProperty : PropertyAttribute { }

[AttributeUsage(AttributeTargets.Property)] public class Archivable : PropertyAttribute { }
