public class ScriptInstance : BaseScript
{

}
