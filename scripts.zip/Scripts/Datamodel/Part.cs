using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;

public class Part : DynamicInstance
{
	protected override void OnHide()
	{
		MeshRenderer mr = GetComponent<MeshRenderer>();
		if (mr != null)
			mr.enabled = false;

		Collider c = GetComponent<Collider>();
		if (c != null)
			c.enabled = false;

		Rigidbody rb = GetComponent<Rigidbody>();
		if (rb != null)
			rb.isKinematic = true;

		isSpawnCached = isSpawn;
		isSpawn = false;

		base.OnHide();
	}
	protected override void OnShow()
	{
		MeshRenderer mr = GetComponent<MeshRenderer>();
		if (mr != null)
			mr.enabled = true;

		Collider c = GetComponent<Collider>();
		if (c != null)
			c.enabled = true;

		Rigidbody rb = GetComponent<Rigidbody>();
		if (rb != null)
			rb.isKinematic = anchored;

		isSpawn = isSpawnCached;

		base.OnShow();
	}

	public static float MaterialUVScale = 4f;
	[SyncVar] protected bool hideStuds = false;
	protected bool isSpawnCached = false;
	[SyncVar] protected bool isSpawn = false;
	[SyncVar] protected bool anchored = true;
	[SyncVar] protected bool canCollide = true;
	[SyncVar] protected Color color;
	[SyncVar] protected PartShape shape;
	[SyncVar] protected PartMaterial material = PartMaterial.Plastic;
	[SyncVar(hook = nameof(SetVelocity))] Vector3 velocity;
	[SyncVar] float drag;
	[SyncVar] float angularDrag;
	[SyncVar] bool useGravity = true;
	private MaterialPropertyBlock materialPropertyBlock;
	private Renderer _renderer;

	protected override bool DoTransformSync => base.DoTransformSync || !Anchored;

	[CreatorProperty, Archivable]
	public Color Color
	{
		get => color;
		set
		{
			if (this is MeshPart) return;
			if (color.a < 1f && value.a >= 1f)
			{
				GetComponent<Renderer>().sharedMaterial = MaterialCache.Instance.GetMaterial(material, color.a < 1f);
			}

			color = value;
			UpdateMaterial();
			if (isServer)
			{
				RpcSetColor(color);
			}
		}
	}

	[CreatorProperty, Archivable]
	public bool Anchored
	{
		get => anchored;
		set
		{
			anchored = value;
			if (!CreatorController.IsCreator)
				GetComponent<Rigidbody>().isKinematic = anchored;

			if (isServer)
			{
				RpcSetAnchored(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public bool CanCollide
	{
		get => canCollide;
		set
		{
			canCollide = value;

			Collider c = GetComponent<Collider>();
			if (c != null)
				c.isTrigger = !canCollide;

			if (isServer)
			{
				RpcSetCanCollide(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public bool IsSpawn
	{
		get => isSpawn;
		set
		{
			isSpawn = value;

			if (isSpawn)
			{
				SpawnpointController.AddSpawn(this);
			}
			else
			{
				SpawnpointController.RemoveSpawn(this);
			}

			if (isServer)
			{
				RpcSetSpawn(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public bool HideStuds
	{
		get => hideStuds;
		set
		{
			hideStuds = value;
			if (isServer)
			{
				RpcSetHideStuds(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public PartShape Shape
	{
		get => shape;
		set
		{
			if (this is MeshPart) return;

			shape = value;
			Collider oldC = GetComponent<Collider>();
			bool colActive = oldC.enabled;
			Destroy(oldC);

			MeshFilter meshFilter = GetComponent<MeshFilter>();
			GameObject shapeObj = Instantiate(Resources.Load<GameObject>("PartShapes/" + value.ToString()));
			meshFilter.mesh = shapeObj.GetComponent<MeshFilter>().mesh;
			Destroy(shapeObj);

			Collider c;

			if (shape == PartShape.Ball)
			{
				c = gameObject.AddComponent<SphereCollider>();
			}
			else
			{
				MeshCollider mcol = gameObject.AddComponent<MeshCollider>();
				mcol.sharedMesh = meshFilter.mesh;
				mcol.convex = true;
				c = mcol;
			}

			c.enabled = colActive;
			c.isTrigger = !canCollide;

			if (isServer)
			{
				RpcSetShape(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public PartMaterial Material
	{
		get => material;
		set
		{
			if (this is MeshPart) return;
			material = value;
			GetComponent<Renderer>().sharedMaterial = MaterialCache.Instance.GetMaterial(value, color.a < 1f);
			UpdateMaterial();
			if (isServer)
			{
				RpcSetMaterial(value);
			}
		}
	}
	private void UpdateMaterial()
	{
		if (materialPropertyBlock == null)
		{
			materialPropertyBlock = new MaterialPropertyBlock();
		}
		if (_renderer == null)
		{
			_renderer = GetComponent<Renderer>();
		}

		_renderer.GetPropertyBlock(materialPropertyBlock);
		materialPropertyBlock.SetColor("_Color", color);
		if (material == PartMaterial.Neon)
		{
			materialPropertyBlock.SetColor("_Emission", color);
		}
		else
		{
			materialPropertyBlock.SetColor("_Emission", Color.black);
		}
		_renderer.SetPropertyBlock(materialPropertyBlock);
	}



	[CreatorProperty, Archivable]
	public Vector3 Velocity
	{
		get => Anchored ? velocity : GetComponent<Rigidbody>().velocity;
		set
		{
			velocity = value;

			if (!Anchored)
			{
				GetComponent<Rigidbody>().velocity = value;
			}
		}
	}

	[CreatorProperty, Archivable]
	public float Drag
	{
		get => GetComponent<Rigidbody>().drag;
		set
		{
			drag = value;
			GetComponent<Rigidbody>().drag = value;

			if (isServer)
			{
				RpcSetDrag(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public float AngularDrag
	{
		get => GetComponent<Rigidbody>().angularDrag;
		set
		{
			angularDrag = value;
			GetComponent<Rigidbody>().angularDrag = value;

			if (isServer)
			{
				RpcSetAngularDrag(value);
			}
		}
	}

	[SyncVar(hook = nameof(SetMass))] float mass;

	[CreatorProperty, Archivable]
	public float Mass
	{
		get => GetComponent<Rigidbody>()?.mass ?? 1f;
		set => GetComponent<Rigidbody>().mass = mass = value;
	}

	public Vector3 AngularVelocity
	{
		get => GetComponent<Rigidbody>().angularVelocity;
		set => GetComponent<Rigidbody>().angularVelocity = value;
	}

	[CreatorProperty, Archivable]
	public bool UseGravity
	{
		get => useGravity;
		set
		{
			useGravity = value;
			GetComponent<Rigidbody>().useGravity = value;

			if (isServer)
			{
				RpcSetUseGravity(value);
			}
		}
	}

	Vector3 lastScale;

	[SerializeField] Rigidbody rb;

	protected override void Awake()
	{
		base.Awake();

		if (!(this is MeshPart))
			color = GetComponent<Renderer>().sharedMaterials[0].color;
	}
	protected override void Start()
	{
		base.Start();

		if (rb == null) rb = GetComponent<Rigidbody>();

		lastScale = Vector3.zero;
		if (!isServer)
		{
			// Init stuff from network sync
			Color = color;
			Anchored = anchored;
			CanCollide = canCollide;
			IsSpawn = isSpawn;
			HideStuds = hideStuds;
			Shape = shape;
			Material = material;
			UseGravity = useGravity;
		}

		if (!(this is MeshPart))
		{
			RecalculateUVs();
			TransformChanged += OnTransformChange;
		}

	}

	protected override void Update()
	{
		base.Update();
		// if (isServer)
		// {
		//	 if (!Anchored)
		//	 {
		//		 if (Position.y < -1000f && lifetime > 5f)
		//			 this.Destroy();
		//	 }
		// }

	}

	public override Instance Clone()
	{
		Part clone = (Part) New("Part", Parent);
		clone.Name = Name;
		clone.CanCollide = CanCollide;
		clone.Anchored = Anchored;
		clone.Color = Color;
		clone.Shape = Shape;
		clone.HideStuds = HideStuds;
		clone.Material = Material;
		clone.IsSpawn = IsSpawn;
		clone.Position = Position;
		clone.Rotation = Rotation;
		clone.Size = Size;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}

	void SetMass(float oldMass, float newMass)
	{
		rb.mass = mass = newMass;
	}

	void SetVelocity(Vector3 oldVelocity, Vector3 newVelocity)
	{
		rb.velocity = velocity = newVelocity;
	}

	protected override void OnDestroy()
	{
		base.OnDestroy();

		if (isSpawn)
			SpawnpointController.RemoveSpawn(this);
	}

	public void MovePosition(Vector3 pos)
	{
		rb.MovePosition(pos);
	}

	public void MoveRotation(Vector3 rot)
	{
		rb.MoveRotation(Quaternion.Euler(rot));
	}

	#region UV updating
	private void OnTransformChange()
	{
		RecalculateUVs();
	}

	[MoonSharpHidden]
	public void RecalculateUVs()
	{
		if (this is MeshPart) return;
		if (Size == lastScale) return;
		if (Shape != PartShape.Brick) return;

		lastScale = Size;
		Mesh mesh = GetComponent<MeshFilter>().mesh;
		mesh.uv = SetupUvMap(mesh.uv);

		if (GetComponent<Renderer>().sharedMaterial.mainTexture != null && GetComponent<Renderer>().sharedMaterial.mainTexture.wrapMode != TextureWrapMode.Repeat)
		{
			GetComponent<Renderer>().sharedMaterial.mainTexture.wrapMode = TextureWrapMode.Repeat;
		}
	}



	private Vector2[] SetupUvMap(Vector2[] meshUVs)
	{
		var width = Size.x / MaterialUVScale;
		var depth = Size.z / MaterialUVScale;
		var height = Size.y / MaterialUVScale;

		//Front
		meshUVs[2] = new Vector2(0, height);
		meshUVs[3] = new Vector2(width, height);
		meshUVs[0] = new Vector2(0, 0);
		meshUVs[1] = new Vector2(width, 0);

		//Back
		meshUVs[7] = new Vector2(0, 0);
		meshUVs[6] = new Vector2(width, 0);
		meshUVs[11] = new Vector2(0, height);
		meshUVs[10] = new Vector2(width, height);

		//Left
		meshUVs[19] = new Vector2(depth, 0);
		meshUVs[17] = new Vector2(0, height);
		meshUVs[16] = new Vector2(0, 0);
		meshUVs[18] = new Vector2(depth, height);

		//Right
		meshUVs[23] = new Vector2(depth, 0);
		meshUVs[21] = new Vector2(0, height);
		meshUVs[20] = new Vector2(0, 0);
		meshUVs[22] = new Vector2(depth, height);

		//Top
		meshUVs[4] = new Vector2(width, 0);
		meshUVs[5] = new Vector2(0, 0);
		meshUVs[8] = new Vector2(width, depth);
		meshUVs[9] = new Vector2(0, depth);

		//Bottom
		meshUVs[13] = new Vector2(width, 0);
		meshUVs[14] = new Vector2(0, 0);
		meshUVs[12] = new Vector2(width, depth);
		meshUVs[15] = new Vector2(0, depth);

		return meshUVs;
	}
	#endregion

	#region Property network sync

	[ClientRpc]
	void RpcSetColor(Color color)
	{
		if (isServer) return;
		Color = color;
	}

	[ClientRpc]
	void RpcSetAnchored(bool anchored)
	{
		if (isServer) return;
		Anchored = anchored;
	}

	[ClientRpc]
	protected void RpcSetCanCollide(bool canCollide)
	{
		if (isServer) return;
		CanCollide = canCollide;
	}

	[ClientRpc]
	void RpcSetSpawn(bool spawn)
	{
		if (isServer) return;
		IsSpawn = spawn;
	}

	[ClientRpc]
	void RpcSetHideStuds(bool hideStuds)
	{
		if (isServer) return;
		HideStuds = hideStuds;
	}

	[ClientRpc]
	void RpcSetShape(PartShape shape)
	{
		if (isServer) return;
		Shape = shape;
	}

	[ClientRpc]
	void RpcSetMaterial(PartMaterial material)
	{
		if (isServer) return;
		Material = material;
	}

	[ClientRpc]
	void RpcSetDrag(float d)
	{
		if (isServer) return;
		Drag = d;
	}

	[ClientRpc]
	void RpcSetAngularDrag(float d)
	{
		if (isServer) return;
		AngularDrag = d;
	}

	[ClientRpc]
	void RpcSetUseGravity(bool g)
	{
		if (isServer) return;
		UseGravity = g;
	}
	#endregion
}

public enum PartShape
{
	Brick,
	Ball,
	Cylinder,
	Wedge,
	Truss,
	TrussFrame,
	Bevel,
	QuarterPipe,
}

public enum PartMaterial
{
	SmoothPlastic,
	Wood,
	Concrete,
	Neon,
	Metal,
	Brick,
	Grass,
	Dirt,
	Stone,
	Snow,
	Ice,
	RustyIron,
	Sand,
	Sandstone,
	Plastic,
	Plywood,
	Planks,
	MetalGrid,
	MetalPlate
}
