using Mirror;
using UnityEngine;

public class BodyPosition : Instance
{
	[SyncVar] Vector3 tPos;
	[SyncVar] float force;
	[SyncVar] float accDist;

	[CreatorProperty, Archivable]
	public Vector3 TargetPosition
	{
		get => tPos;
		set => tPos = value;
	}

	[CreatorProperty, Archivable]
	public float Force
	{
		get => force;
		set => force = value;
	}

	[CreatorProperty, Archivable]
	public float AcceptanceDistance
	{
		get => force;
		set => force = value;
	}

	protected override void Start()
	{
		base.Start();

		if (!isServer)
		{
			TargetPosition = tPos;
			Force = force;
			AcceptanceDistance = accDist;
		}
	}

	private void FixedUpdate()
	{
		if (!CreatorController.IsCreator)
		{
			if (Parent != null)
			{
				Rigidbody rb = Parent.GetComponent<Rigidbody>();

				if (rb != null)
				{
					if (Vector3.Distance(Parent.transform.position, transform.position) > accDist)
					{
						Vector3 dir = (TargetPosition - Parent.transform.position);
						rb.AddForce(dir.normalized * Force, ForceMode.Impulse);
					}
				}
			}
		}
	}

	public override Instance Clone()
	{
		BodyPosition clone = (BodyPosition) New("BodyPosition");

		clone.Parent = Parent;
		clone.Name = Name;

		clone.Force = Force;
		clone.TargetPosition = TargetPosition;
		clone.AcceptanceDistance = AcceptanceDistance;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
