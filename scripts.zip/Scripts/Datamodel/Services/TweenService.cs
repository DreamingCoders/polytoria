using System;
using MoonSharp.Interpreter;
using UnityEngine;

public class TweenService
{
	public static int TweenPosition(DynamicInstance target, Vector3 destination, float time, LeanTweenType tweenType = LeanTweenType.linear, DynValue callOnComplete = null)
	{
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();
		LTDescr lt = LeanTween.move(target.gameObject, destination, time).setEase(tweenType);

		DynamicInstance inst = target.GetComponent<DynamicInstance>();

		if (inst != null)
			inst.SyncMode = SyncMode.ForceSync;

		if (callOnComplete != null)
		{
			lt.setOnComplete(() =>
			{
				try
				{
					if (callOnComplete != null)
						ss.CallFunc(callOnComplete);
				}
				catch { }
				if (inst != null)
					inst.SyncMode = SyncMode.ForceSync;
			});
		}

		return lt.id;
	}

	public static int TweenRotation(DynamicInstance target, Vector3 destination, float time, LeanTweenType tweenType = LeanTweenType.linear, DynValue callOnComplete = null)
	{
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();
		LTDescr lt = LeanTween.rotate(target.gameObject, destination, time).setEase(tweenType);

		DynamicInstance inst = target.GetComponent<DynamicInstance>();

		if (inst != null)
			inst.SyncMode = SyncMode.ForceSync;

		if (callOnComplete != null)
		{
			lt.setOnComplete(() =>
			{
				try
				{
					if (callOnComplete != null)
						ss.CallFunc(callOnComplete);
				}
				catch { }
				if (inst != null)
					inst.SyncMode = SyncMode.ForceSync;
			});
		}

		return lt.id;
	}

	public static int TweenSize(DynamicInstance target, Vector3 destination, float time, LeanTweenType tweenType = LeanTweenType.linear, DynValue callOnComplete = null)
	{
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();
		LTDescr lt = LeanTween.scale(target.gameObject, destination, time).setEase(tweenType);

		DynamicInstance inst = target.GetComponent<DynamicInstance>();

		if (inst != null)
			inst.SyncMode = SyncMode.ForceSync;

		if (callOnComplete != null)
		{
			lt.setOnComplete(() =>
			{
				try
				{
					if (callOnComplete != null)
						ss.CallFunc(callOnComplete);
				}
				catch { }
				if (inst != null)
					inst.SyncMode = SyncMode.ForceSync;
			});
		}

		return lt.id;
	}

	public static int TweenNumber(float start, float end, float time, DynValue callback, LeanTweenType tweenType = LeanTweenType.linear, DynValue callOnComplete = null)
	{
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();

		LTDescr lt = LeanTween.value(start, end, time).setEase(tweenType).setOnUpdate(onUpdate);

		void onUpdate(float val)
		{
			ss.CallFunc(callback, val);
		}

		if (callOnComplete != null)
		{
			lt.setOnComplete(() =>
			{
				try
				{
					if (callOnComplete != null)
						ss.CallFunc(callOnComplete);
				}
				catch { }
			});
		}

		return lt.id;
	}

	public static int TweenColor(Color start, Color end, float time, DynValue callback, LeanTweenType tweenType = LeanTweenType.linear, DynValue callOnComplete = null)
	{
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();

		LTDescr lt = LeanTween.value(Game.singleton.gameObject, start, end, time).setEase(tweenType).setOnUpdate(onUpdate);

		void onUpdate(Color val)
		{
			ss.CallFunc(callback, val);
		}

		if (callOnComplete != null)
		{
			lt.setOnComplete(() =>
			{
				try
				{
					if (callOnComplete != null)
						ss.CallFunc(callOnComplete);
				}
				catch { }
			});
		}

		return lt.id;
	}

	public static int TweenVector3(Vector3 start, Vector3 end, float time, DynValue callback, LeanTweenType tweenType = LeanTweenType.linear, DynValue callOnComplete = null)
	{
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();

		Action<Vector3> onUpdate = (val) =>
		{
			ss.CallFunc(callback, val);
		};

		LTDescr lt = LeanTween.value(Game.singleton.gameObject, start, end, time).setEase(tweenType).setOnUpdate(onUpdate);

		if (callOnComplete != null)
		{
			lt.setOnComplete(() =>
			{
				try
				{
					if (callOnComplete != null)
						ss.CallFunc(callOnComplete);
				}
				catch { }
			});
		}

		return lt.id;
	}

	public static int TweenVector2(Vector2 start, Vector2 end, float time, DynValue callback, LeanTweenType tweenType = LeanTweenType.linear, DynValue callOnComplete = null)
	{
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();

		Action<Vector2> onUpdate = (val) =>
		{
			ss.CallFunc(callback, val);
		};

		LTDescr lt = LeanTween.value(Game.singleton.gameObject, start, end, time).setEase(tweenType).setOnUpdate(onUpdate);

		if (callOnComplete != null)
		{
			lt.setOnComplete(() =>
			{
				try
				{
					if (callOnComplete != null)
						ss.CallFunc(callOnComplete);
				}
				catch { }
			});
		}

		return lt.id;
	}

	public static void Cancel(int id, bool callOnComplete = false)
	{
		LeanTween.cancel(id, callOnComplete);
	}

	public static void CancelAll(bool callOnComplete = false)
	{
		LeanTween.cancelAll(callOnComplete);
	}

	public static void Pause(int id)
	{
		LeanTween.pause(id);
	}

	public static void Resume(int id)
	{
		LeanTween.resume(id);
	}

	public static bool IsPaused(int id)
	{
		return LeanTween.isPaused(id);
	}
}
