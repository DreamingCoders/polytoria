using System.Collections.Generic;
using MoonSharp.Interpreter;
using SimpleJSON;
using UnityEngine;

public class Datastore
{
	public static readonly float CACHE_TIME = 5f;
	string key;
	bool loading = false;
	Dictionary<string, DatastoreEntry> data = new Dictionary<string, DatastoreEntry>();
	ScriptService scriptService;

	public bool Loading => loading;
	public string Key => key;
	public LuaEvent Loaded = new LuaEvent();

	public Datastore(string key)
	{
		this.key = key;
		loading = true;
		scriptService = Game.singleton.FindChildOfType<ScriptService>();

		if (DataStoreService.Instance.UseReadRequest())
		{
			DataStoreService.Instance.LoadFromServer(this, (success) =>
			{
				loading = false;
				Loaded.Invoke();
			});
		}
	}

	public void Deserialize(string jsonData)
	{
		JSONNode json = JSON.Parse(jsonData);
		foreach (KeyValuePair<string, JSONNode> entry in json)
		{
			DatastoreEntry dsEntry = new DatastoreEntry() { timestamp = Time.time };
			JSONNode val = entry.Value;

			if (val.IsBoolean)
			{
				dsEntry.value = val.AsBool;
			}
			else if (val.IsString)
			{
				dsEntry.value = val.ToString();
			}
			else if (val.IsNumber)
			{
				dsEntry.value = val.AsDouble;
			}

			data[entry.Key] = dsEntry;
		}
		loading = false;
	}

	public void Get(string key, DynValue callback)
	{
		if (data.ContainsKey(key))
		{
			DatastoreEntry entry = data[key];

			if (Time.time - entry.timestamp > CACHE_TIME)
			{
				if (!DataStoreService.Instance.UseReadRequest())
				{
					scriptService.CallFunc(callback, entry.value, false, "Too many read requests, using cached value");
				}

				DataStoreService.Instance.LoadFromServer(this, (success) =>
				{
					if (success)
						this.Get(key, callback);
					else
						scriptService.CallFunc(callback, entry.value, false, "Failed to load from server, using cached value");
				});
			}
			else
			{
				string msg = null;
				if (LaunchController.isSolo)
				{
					msg = "In solo mode, keeping data until the end of the session.";
				}
				scriptService.CallFunc(callback, entry.value, true, msg);
			}
		}
		else
		{
			scriptService.CallFunc(callback, null, false, "No value for key " + key + " in datastore " + this.key);
		}
	}

	public void Set(string key, DynValue value, DynValue callback = null)
	{
		object val = null;
		if (value.Type == DataType.Boolean)
		{
			val = value.Boolean;
		}
		else if (value.Type == DataType.String)
		{
			val = value.String;
		}
		else if (value.Type == DataType.Number)
		{
			val = value.Number;
		}
		else
		{
			if (callback != null)
			{
				scriptService.CallFunc(callback, false, "Invalid value type");
			}
			return;
		}

		data[key] = new DatastoreEntry() { value = val, timestamp = Time.time };
		if (!DataStoreService.Instance.UseWriteRequest())
		{
			if (callback != null)
				scriptService.CallFunc(callback, false, "Too many write requests");
		}
		else
		{
			DataStoreService.Instance.WriteToServer(this, key, val, (success) =>
			{
				if (callback != null)
				{
					string msg = null;
					if (LaunchController.isSolo)
					{
						msg = "In solo mode, keeping data until the end of the session.";
					}
					scriptService.CallFunc(callback, success, success ? msg : "Failed to write to server");
				}
			});
		}
	}

	public void Remove(string key, DynValue callback = null)
	{
		if (data.ContainsKey(key))
		{
			data.Remove(key);

			if (!DataStoreService.Instance.UseWriteRequest())
			{
				if (callback != null)
					scriptService.CallFunc(callback, false, "Too many write requests");
			}
			else
			{
				DataStoreService.Instance.WriteToServer(this, key, null, (success) =>
				{
					if (callback != null)
						scriptService.CallFunc(callback, success, success ? null : "Failed to write to server");
				});
			}
		}
		else
		{
			if (callback != null)
				scriptService.CallFunc(callback, false, "No value for key " + key + " in datastore " + this.key);
		}
	}

	struct DatastoreEntry
	{
		public object value;
		public float timestamp;
	}
}