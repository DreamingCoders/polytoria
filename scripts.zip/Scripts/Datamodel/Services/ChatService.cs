using System.Collections;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;
using UnityEngine.Networking;

public class ChatService : NetworkBehaviour
{
	public static ChatService instance;

	void Awake()
	{
		instance = this;
	}

	public new void BroadcastMessage(string message)
	{
		if (isServer)
		{
			SendChatClientRpc(message, "", new Color(1f, 0.89f, 0.35f), null);
		}
		else
		{
			UIController.singleton.ReceiveChat("", message, new Color(1f, 0.89f, 0.35f));
		}
	}

	public void UnicastMessage(string message, Player player)
	{
		if (isServer)
		{
			SendChatTargetRpc(player.netIdentity.connectionToClient, message, "", new Color(1f, 0.89f, 0.35f));
		}
	}

	[MoonSharpHidden]
	public void SendChat(string message)
	{
		if (isServer)
		{
			Player player = PTNetworkManager.instance.GetPlayerPrefab(NetworkServer.localConnection.connectionId);
			message = FilterService.Filter(message);
			DoSendChat(message, player.ChatColor, player);
		}
		else
		{
			CmdSendChat(message);
		}
	}

	string filterChatExploits(string message)
	{
		//weird temporary fix for BR and attempting to escape noparse tag but it works
		return "<noparse>" +
		message
		/*Prevent exploit using unicode (TextMeshPro still recognizes rich text using angle bracket unicode u003C and u003E)*/
		.Replace("\\u", "<noparse>\\</noparse>u")
		/*Can we automate this using regular expressions?*/
		.Replace("<br>", "</noparse><<noparse>br>")
		.Replace("</noparse>", "</noparse><<noparse>/noparse>")

		+ "</noparse>";
	}

	void DoSendChat(string message, Color color, Player player)
	{
		if (player.IsAdmin)
		{
			if (message.StartsWith("/kick "))
			{
				string username = message.Replace("/kick ", "").Trim();
				Player pl = (Player) Game.singleton.FindChildOfType<Players>().FindChild(username);

				if (pl)
				{
					pl.Kick();
				}

				return;
			}
		}

		PlayerChatEvent playerChatEvent = new PlayerChatEvent(player, message);

		player.Chatted?.Invoke(message, playerChatEvent);

		if (playerChatEvent.Canceled)
		{
			return;
		}

		if (!LaunchController.isLocal)
			StartCoroutine(LogChatMessage(player.UserID, message));

		message = filterChatExploits(message);
		SendChatClientRpc(message, player.Name, color, player);
	}

	IEnumerator LogChatMessage(int userId, string message)
	{
		if (!isServer) yield break;
		if (LaunchController.isSolo) yield break;
		WWWForm form = new WWWForm();
		form.AddField("userID", userId);
		form.AddField("message", message);

		using (UnityWebRequest uwr = UnityWebRequest.Post("https://api.polytoria.com/v1/game/server/log", form))
		{
			uwr.SetRequestHeader("Authorization", LaunchController.serverToken);
			yield return uwr.SendWebRequest();

			if (uwr.result != UnityWebRequest.Result.Success)
			{
				Debug.LogError(uwr.error);
			}
		}
	}

	[Command(requiresAuthority = false)]
	void CmdSendChat(string message, NetworkConnectionToClient sender = null)
	{
		Player player = PTNetworkManager.instance.GetPlayerPrefab(sender.connectionId);
		message = FilterService.Filter(message);
		DoSendChat(message, player.ChatColor, player);
	}

	[ClientRpc]
	void SendChatClientRpc(string message, string username, Color color, Player player)
	{
		UIController.singleton.ReceiveChat(username, message, color);

		if (player != null)
			player.GetComponentInChildren<UISpeechBubble>().Message = message;
	}

	[TargetRpc]
	void SendChatTargetRpc(NetworkConnection target, string message, string username, Color color)
	{
		UIController.singleton.ReceiveChat(username, message, color);
	}

	[MoonSharpHidden] public new void Invoke(string methodName, float time) { }
	[MoonSharpHidden] public new void InvokeRepeating(string methodName, float time, float repeatRate) { }
}
