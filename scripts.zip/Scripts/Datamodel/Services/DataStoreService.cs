using System.Collections;
using System.Collections.Generic;
using Mirror;
using MoonSharp.Interpreter;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

public class DataStoreService : NetworkBehaviour
{
	public static DataStoreService Instance { get; private set; }
	public int MaxReadRequestsPerMinute = 30;
	public int ReadRequestsPerPlayerModifier = 10;
	public int MaxWriteRequestsPerMinute = 30;
	public int WriteRequestsPerPlayerModifier = 10;

	Queue<GetDataStoreQueueEntry> getDataStoreQueue = new Queue<GetDataStoreQueueEntry>();
	Dictionary<string, Datastore> datastores = new Dictionary<string, Datastore>();
	int readRequestsThisMinute = 0, writeRequestThisMinute = 0, currentMinute = 0;
	bool isGettingDatastore = false;

	private void Awake()
	{
		Instance = this;
	}

	public Datastore GetDatastore(string key, DynValue callback)
	{
		if (key.Length > 32)
		{
			throw new System.Exception("Datastore key must be 32 characters or less");
		}
		Datastore ds;
		if (!datastores.TryGetValue(key, out ds))
		{
			ds = new Datastore(key);
			datastores.Add(key, ds);
		}
		return ds;
	}

	void Update()
	{
		if (!isGettingDatastore && getDataStoreQueue.Count > 0)
		{
			isGettingDatastore = true;
			StartCoroutine(DoLoadFromServer(getDataStoreQueue.Dequeue()));
		}
	}

	public bool UseReadRequest()
	{
		if (currentMinute != System.DateTime.Now.Minute)
		{
			currentMinute = System.DateTime.Now.Minute;
			readRequestsThisMinute = 0;
		}

		if (readRequestsThisMinute >= MaxReadRequestsPerMinute + (ReadRequestsPerPlayerModifier * Game.singleton.PlayersConnected))
		{
			return false;
		}
		else
		{
			readRequestsThisMinute++;
			return true;
		}
	}

	public bool UseWriteRequest()
	{
		if (currentMinute != System.DateTime.Now.Minute)
		{
			currentMinute = System.DateTime.Now.Minute;
			writeRequestThisMinute = 0;
		}

		if (writeRequestThisMinute >= MaxWriteRequestsPerMinute + (WriteRequestsPerPlayerModifier * Game.singleton.PlayersConnected))
		{
			return false;
		}
		else
		{
			writeRequestThisMinute++;
			return true;
		}
	}

	public void LoadFromServer(Datastore ds, System.Action<bool> callback)
	{
		if (LaunchController.isSolo)
		{
			callback(true);
			return;
		}

		if (!isServer)
		{
			throw new System.Exception("Can only read/write datastore from server");
		}

		getDataStoreQueue.Enqueue(new GetDataStoreQueueEntry(ds, callback));
	}

	IEnumerator DoLoadFromServer(GetDataStoreQueueEntry entry)
	{
		Datastore ds = entry.datastore;
		using (var request = UnityWebRequest.Get("https://api.polytoria.com/v1/game/server/datastore/get-data?key=" + ds.Key))
		{
			request.SetRequestHeader("Authorization", LaunchController.serverToken);
			yield return request.SendWebRequest();

			if (request.result != UnityWebRequest.Result.Success)
			{
				Debug.LogError("Error while retrieving datastore data: " + request.error);
				entry.callback(true);
			}
			else
			{
				ds.Deserialize(request.downloadHandler.text);
				entry.callback(false);
			}
		}

		isGettingDatastore = false;
	}

	public void WriteToServer(Datastore ds, string key, object value, System.Action<bool> callback)
	{
		if (LaunchController.isSolo)
		{
			callback(true);
			return;
		}

		if (!isServer)
		{
			throw new System.Exception("Can only read/write datastore from server");
		}

		StartCoroutine(DoWriteToServer(ds, key, value, callback));
	}

	IEnumerator DoWriteToServer(Datastore ds, string key, object value, System.Action<bool> callback)
	{
		JSONNode json = new JSONObject();
		JSONNode valueNode = null;

		if (value == null)
		{
			valueNode = null;
		}
		else if (value is string)
		{
			valueNode = new JSONString((string) value);
		}
		else if (value is bool)
		{
			valueNode = new JSONBool((bool) value);
		}
		else
		{
			valueNode = new JSONNumber((double) value);
		}

		json.Add(key, valueNode);

		WWWForm form = new WWWForm();
		form.AddField("key", ds.Key);
		form.AddField("data", json.ToString());

		using (var request = UnityWebRequest.Post("https://api.polytoria.com/v1/game/server/datastore/set-data", form))
		{
			request.SetRequestHeader("Authorization", LaunchController.serverToken);
			yield return request.SendWebRequest();

			if (request.result != UnityWebRequest.Result.Success)
			{
				Debug.LogError("Error while writing datastore data: " + request.error);
				callback(false);
			}
			else
			{
				callback(true);
			}
		}
	}
}

public class GetDataStoreQueueEntry
{
	public Datastore datastore;
	public System.Action<bool> callback;

	public GetDataStoreQueueEntry(Datastore datastore, System.Action<bool> callback)
	{
		this.datastore = datastore;
		this.callback = callback;
	}
}
