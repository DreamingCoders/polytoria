using System;
using System.Collections.Generic;
using System.Net;
using System.Text.RegularExpressions;

public class FilterService
{
	static List<string> profanityList;

	private static List<string> GetWords()
	{
		if (profanityList == null)
		{
			using (WebClient web = new WebClient())
			{
				string listRaw = web.DownloadString("https://api.polytoria.com/v1/game/server/profanity");
				profanityList = new List<string>(listRaw.Split(new string[] { "\n" }, StringSplitOptions.RemoveEmptyEntries));
			}
		}

		return profanityList;
	}

	public static string Filter(string input)
	{
		string[] words = input.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
		List<string> filteredWords = new List<string>();
		foreach (string word in words)
		{
			bool found = false;
			foreach (string filter in GetWords())
			{
				string f = filter.Trim();
				if (f.Contains("*"))
				{
					string regex = f.Replace("*", ".*");
					if (Regex.IsMatch(word, regex, RegexOptions.IgnoreCase))
					{
						filteredWords.Add(new string('*', word.Length));
						found = true;
						break;
					}
				}
				else
				{
					if (word.Equals(f, StringComparison.OrdinalIgnoreCase))
					{
						filteredWords.Add(new string('*', word.Length));
						found = true;
						break;
					}
				}
			}

			if (!found)
			{
				filteredWords.Add(word);
			}
		}

		return string.Join(" ", filteredWords.ToArray());
	}
}
