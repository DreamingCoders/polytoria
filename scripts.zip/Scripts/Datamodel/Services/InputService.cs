using System.Collections.Generic;
using UnityEngine;

public class InputService
{
	public static LuaEvent KeyDown = new LuaEvent();
	public static LuaEvent KeyUp = new LuaEvent();
	public static Vector3 MousePosition => Input.mousePosition;
	public static bool CursorLocked
	{
		get => Cursor.lockState == CursorLockMode.Locked;
		set => Cursor.lockState = value ? CursorLockMode.Locked : CursorLockMode.None;
	}
	public static bool CursorVisible
	{
		get => Cursor.visible;
		set => Cursor.visible = value;
	}

	public static Vector3 GetMouseWorldPosition()
	{
		RaycastHit hit;
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

		if (Physics.Raycast(ray, out hit))
		{
			return hit.point;
		}

		return Vector3.zero;
	}

	public static Vector3 GetMouseWorldPoint()
	{
		return Camera.main.ScreenToWorldPoint(Input.mousePosition);
	}

	public static Vector3 ScreenToWorldPoint(Vector3 pos)
	{
		return Camera.main.ScreenToWorldPoint(pos);
	}

	public static Vector3 ScreenToViewportPoint(Vector3 pos)
	{
		return Camera.main.ScreenToViewportPoint(pos);
	}

	public static Vector3 WorldToScreenPoint(Vector3 pos)
	{
		return Camera.main.WorldToScreenPoint(pos);
	}

	public static Vector3 WorldToViewportPoint(Vector3 pos)
	{
		return Camera.main.WorldToViewportPoint(pos);
	}

	public static Vector3 ViewportToWorldPoint(Vector3 pos)
	{
		return Camera.main.ViewportToWorldPoint(pos);
	}

	public static Vector3 ViewportToScreenPoint(Vector3 pos)
	{
		return Camera.main.ViewportToScreenPoint(pos);
	}

	public static RayResult? ScreenPointToRay(Vector3 pos, List<Instance> ignoreList = null)
	{
		Ray ray = Camera.main.ScreenPointToRay(pos);
		RaycastHit[] hits = Physics.RaycastAll(ray);

		foreach (RaycastHit hit in hits)
		{
			Instance i = hit.collider.GetComponent<Instance>();

			if (!i && (ignoreList != null && ignoreList.Contains(i)))
			{
				continue;
			}

			return new RayResult
			{
				Origin = ray.origin,
				Direction = ray.direction,
				Position = hit.point,
				Normal = hit.normal,
				Distance = hit.distance,
				Instance = i
			};
		}

		return null;
	}

	public static RayResult? ViewportPointToRay(Vector3 pos, List<Instance> ignoreList = null)
	{
		Ray ray = Camera.main.ViewportPointToRay(pos);
		RaycastHit[] hits = Physics.RaycastAll(ray);

		foreach (RaycastHit hit in hits)
		{
			Instance i = hit.collider.GetComponent<Instance>();

			if (!i || (ignoreList != null && ignoreList.Contains(i)))
			{
				continue;
			}

			return new RayResult
			{
				Origin = ray.origin,
				Direction = ray.direction,
				Position = hit.point,
				Normal = hit.normal,
				Distance = hit.distance,
				Instance = i
			};
		}

		return null;
	}
}
