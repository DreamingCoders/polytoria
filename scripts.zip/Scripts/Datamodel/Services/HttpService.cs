using System;
using System.Collections;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;
using UnityEngine.Networking;

public class HttpService : MonoBehaviour
{
	public static HttpService instance;
	static int maxRequestsPerMinute = 90;
	static int requestsThisMinute = 0;
	static int currentMinute;

	private void Awake()
	{
		instance = this;
	}

	[MoonSharpHidden] public new void Invoke(string methodName, float delay) { }
	[MoonSharpHidden] public new void InvokeRepeating(string methodName, float delay, float repeatRate) { }


	static bool RateLimit(DynValue callback = null)
	{
		if (!Game.singleton.GetComponent<NetworkIdentity>().isServer)
		{
			Game.singleton.FindChildOfType<ScriptService>().CallFunc(callback, "", true, "Cannot call Http functions from client");
			return false;
		}

		int minute = (int) DateTimeOffset.Now.ToUnixTimeSeconds() / 60;

		if (minute != currentMinute)
		{
			currentMinute = minute;
			requestsThisMinute = 0;
		}

		if (requestsThisMinute >= maxRequestsPerMinute)
		{
			Game.singleton.FindChildOfType<ScriptService>().CallFunc(callback, "", true, "Http limit exceeded");
			return false;
		}

		requestsThisMinute++;
		return true;
	}

	public static void Get(string url, DynValue callback = null, Table headers = null)
	{
		if (RateLimit(callback))
		{
			instance.StartCoroutine(DoHttpGet(url, callback, headers));
		}
	}

	public static void Post(string url, string postData, DynValue callback = null, Table headers = null)
	{
		if (RateLimit(callback))
		{
			instance.StartCoroutine(DoHttpPost(url, postData, callback, headers));
		}
	}

	public static void Put(string url, string bodyData, DynValue callback = null, Table headers = null)
	{
		if (RateLimit(callback))
		{
			instance.StartCoroutine(DoHttpPut(url, bodyData, callback, headers));
		}
	}

	public static void Delete(string url, DynValue callback = null, Table headers = null)
	{
		if (RateLimit(callback))
		{
			instance.StartCoroutine(DoHttpDelete(url, callback, headers));
		}
	}

	static IEnumerator DoHttpGet(string url, DynValue callback, Table headers)
	{
		using UnityWebRequest uwr = UnityWebRequest.Get(url);

		foreach (TablePair header in headers.Pairs)
		{
			string key = header.Key.CastToString().Trim();
			string value = header.Value.CastToString();

			if (key != null && value != null)
			{
				if (!key.ToLower().Replace("-", "").Replace(" ", "").Replace("_", "").Contains("ptgameid"))
				{
					uwr.SetRequestHeader(key, value);
				}
			}
		}

		uwr.SetRequestHeader("PT-Game-ID", Game.singleton.GameID.ToString());
		yield return uwr.SendWebRequest();

		if (callback != null)
		{
			Game.singleton.FindChildOfType<ScriptService>().CallFunc(callback, uwr.downloadHandler.text, uwr.result != UnityWebRequest.Result.Success, uwr.error);
		}
	}

	static IEnumerator DoHttpPost(string url, string postData, DynValue callback, Table headers)
	{
		using UnityWebRequest uwr = new UnityWebRequest(url);

		uwr.method = "POST";
		uwr.uploadHandler = new UploadHandlerRaw(System.Text.Encoding.UTF8.GetBytes(postData));
		uwr.downloadHandler = new DownloadHandlerBuffer();

		foreach (TablePair header in headers.Pairs)
		{
			string key = header.Key.CastToString().Trim();
			string value = header.Value.CastToString();

			if (key != null && value != null)
			{
				if (!key.ToLower().Replace("-", "").Replace(" ", "").Replace("_", "").Contains("ptgameid"))
				{
					uwr.SetRequestHeader(key, value);
				}
			}
		}

		uwr.SetRequestHeader("PT-Game-ID", Game.singleton.GameID.ToString());
		yield return uwr.SendWebRequest();

		if (callback != null)
		{
			Game.singleton.FindChildOfType<ScriptService>().CallFunc(callback, uwr.downloadHandler.text, uwr.result != UnityWebRequest.Result.Success, uwr.error);
		}
	}

	static IEnumerator DoHttpPut(string url, string bodyData, DynValue callback, Table headers)
	{
		using UnityWebRequest uwr = new UnityWebRequest(url);

		uwr.method = "PUT";
		uwr.uploadHandler = new UploadHandlerRaw(System.Text.Encoding.UTF8.GetBytes(bodyData));
		uwr.downloadHandler = new DownloadHandlerBuffer();

		foreach (TablePair header in headers.Pairs)
		{
			string key = header.Key.CastToString().Trim();
			string value = header.Value.CastToString();

			if (key != null && value != null)
			{
				if (!key.ToLower().Replace("-", "").Replace(" ", "").Replace("_", "").Contains("ptgameid"))
				{
					uwr.SetRequestHeader(key, value);
				}
			}
		}

		uwr.SetRequestHeader("PT-Game-ID", Game.singleton.GameID.ToString());
		yield return uwr.SendWebRequest();

		if (callback != null)
		{
			Game.singleton.FindChildOfType<ScriptService>().CallFunc(callback, uwr.downloadHandler.text, uwr.result != UnityWebRequest.Result.Success, uwr.error);
		}
	}

	static IEnumerator DoHttpDelete(string url, DynValue callback, Table headers)
	{
		using UnityWebRequest uwr = UnityWebRequest.Delete(url);

		foreach (TablePair header in headers.Pairs)
		{
			string key = header.Key.CastToString().Trim();
			string value = header.Value.CastToString();

			if (key != null && value != null)
			{
				if (!key.ToLower().Replace("-", "").Replace(" ", "").Replace("_", "").Contains("ptgameid"))
				{
					uwr.SetRequestHeader(key, value);
				}
			}
		}

		uwr.SetRequestHeader("PT-Game-ID", Game.singleton.GameID.ToString());
		yield return uwr.SendWebRequest();

		if (callback != null)
		{
			Game.singleton.FindChildOfType<ScriptService>().CallFunc(callback, uwr.downloadHandler.text, uwr.result != UnityWebRequest.Result.Success, uwr.error);
		}
	}
}
