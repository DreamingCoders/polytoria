using Mirror;

public class ValueBase : Instance
{
	public LuaEvent Changed = new LuaEvent();

	protected void InvokeChanged()
	{

		if (isServer && NetworkServer.spawned.ContainsKey(netId))
			RpcChanged();
		else
			Changed.Invoke();
	}

	[ClientRpc]
	void RpcChanged()
	{
		Changed.Invoke();
	}
}
