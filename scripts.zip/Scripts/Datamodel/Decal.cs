using System;
using Mirror;
using UnityEngine;

[RequireComponent(typeof(MeshRenderer))]
public class Decal : DynamicInstance
{
	[SyncVar(hook = nameof(SetImage))]
	private string imageID = "0";

	[SyncVar(hook = nameof(SetImageType))]
	private ImageType imageType;

	[SyncVar(hook = nameof(SetTextureScale))]
	private Vector2 textureScale = Vector2.one;

	[SyncVar(hook = nameof(SetTextureOffset))]
	private Vector2 textureOffset = Vector2.zero;

	private ImageCacheKey lastCacheKey;
	private Texture2D placeholder;
	private BoxCollider col;
	private MeshRenderer meshRenderer;

	[CreatorProperty, Archivable]
	public string ImageID
	{
		get => imageID;
		set
		{
			imageID = value;
			GetImage();
		}
	}

	[CreatorProperty, Archivable]
	public ImageType ImageType
	{
		get => imageType;
		set
		{
			imageType = value;
			GetImage();
		}
	}

	[CreatorProperty, Archivable]
	public Vector2 TextureScale
	{
		get => textureScale;
		set
		{
			textureScale = value;
			meshRenderer.material.mainTextureScale = value;
		}
	}

	[CreatorProperty, Archivable]
	public Vector2 TextureOffset
	{
		get => textureOffset;
		set
		{
			textureOffset = value;
			meshRenderer.material.mainTextureOffset = value;
		}
	}

	private void SetTextureScale(Vector2 oldScale, Vector2 newScale)
	{
		if (isServer) return;
		TextureScale = newScale;
	}

	private void SetTextureOffset(Vector2 oldOffset, Vector2 newOffset)
	{
		if (isServer) return;
		TextureOffset = newOffset;
	}

	protected override void OnHide()
	{
		base.OnHide();
		GetComponent<MeshRenderer>().enabled = false;
	}

	protected override void OnShow()
	{
		base.OnShow();
		GetComponent<MeshRenderer>().enabled = true;
	}

	private void SetImage(string oldId, string newId)
	{
		if (isServer) return;
		ImageID = newId;
	}

	private void SetImageType(ImageType oldType, ImageType newType)
	{
		if (isServer) return;
		ImageType = newType;
	}

	protected override void Awake()
	{
		base.Awake();
		meshRenderer = GetComponent<MeshRenderer>();
		col = GetComponent<BoxCollider>();
	}

	protected override void Start()
	{
		base.Start();
		//although decals don't have actual collision in game, we need a collision box on the workshop to allow selection casts to work
		col.enabled = CreatorController.IsCreator;
		placeholder = meshRenderer.material.mainTexture as Texture2D;
	}

	protected override void Update()
	{
		base.Update();
	}

	private void GetImage()
	{
		lastCacheKey = new ImageCacheKey { id = ImageID, type = ImageType };
		ImageCacheController.Instance.GetImage(lastCacheKey, (key, entry) =>
		{
			if (key.Equals(lastCacheKey))
			{
				if (entry.hasTransparency)
				{
					meshRenderer.material = Resources.Load<Material>("Materials/Internal/Decal/Transparent");
				}
				else
				{
					meshRenderer.material = Resources.Load<Material>("Materials/Internal/Decal/Cutout");
				}

				meshRenderer.material.mainTexture = entry.texture;
				meshRenderer.material.mainTextureScale = TextureScale;
				meshRenderer.material.mainTextureOffset = TextureOffset;
			}
		});
	}

	public override Instance Clone()
	{
		Decal clone = (Decal) New("Decal", Parent);
		clone.Name = Name;
		clone.Position = Position;
		clone.Rotation = Rotation;
		clone.Size = Size;
		try
		{
			clone.ImageID = ImageID;
			clone.ImageType = ImageType;
			clone.TextureScale = TextureScale;
			clone.TextureOffset = TextureOffset;
		}
		catch (Exception e)
		{
			Debug.LogError(e);
		}

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}