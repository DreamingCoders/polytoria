using System;
using System.Collections;
using Mirror;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

[RequireComponent(typeof(AudioSource))]
public class Sound : DynamicInstance
{
	private AudioSource audioSource;
	private AudioClip clip;

	[SyncVar] private int soundID;
	[SyncVar] private bool _isPlaying;
	[SyncVar] private bool autoplay;
	[SyncVar] private float volume;
	[SyncVar] private float time;
	[SyncVar] private bool loop;
	[SyncVar] private bool playInWorld;
	[SyncVar] private float pitch = 1f;

	public LuaEvent Loaded = new LuaEvent();

	public bool Playing { get => _isPlaying; }

	[CreatorProperty, Archivable]
	public int SoundID
	{
		get => soundID;
		set
		{
			soundID = value;
			StartCoroutine(GetAudioClip(soundID));

			if (isServer)
				RpcSetSoundId(value);
		}
	}

	[CreatorProperty, Archivable]
	public float Pitch
	{
		get => pitch;
		set
		{
			pitch = value;
			audioSource.pitch = pitch;

			if (isServer)
				RpcSetPitch(value);
		}
	}

	public float Length => audioSource.clip?.length ?? 0f;

	new public Vector3 Size
	{
		get => Vector3.one;
		set
		{
			transform.localScale = Vector3.one;
		}
	}
	new public Vector3 Rotation
	{
		get => Vector3.one;
		set
		{
			transform.rotation = Quaternion.identity;
		}
	}

	public float Time
	{
		get => audioSource.time;
		set
		{
			time = value;
			audioSource.time = value;

			if (isServer)
			{
				RpcSetTime(value);
			}
		}
	}

	IEnumerator GetAudioClip(int id)
	{
		using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/assets/serve-audio/" + id))
		{
			yield return uwr.SendWebRequest();

			if (uwr.result != UnityWebRequest.Result.Success)
			{
				Debug.LogError(uwr.error);
			}
			else
			{
				JSONNode json = JSON.Parse(uwr.downloadHandler.text);

				if (json["success"].AsBool == true)
				{
					using (UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip(json["url"].Value, AudioType.MPEG))
					{
						yield return www.SendWebRequest();

						if (www.result != UnityWebRequest.Result.Success)
						{
							Debug.LogError(www.error);
						}
						else
						{
							audioSource.Stop();
							clip = DownloadHandlerAudioClip.GetContent(www);
							audioSource.clip = clip;

							Loaded?.Invoke();

							if ((autoplay || Playing) && !CreatorController.IsCreator)
							{
								audioSource.Play();
							}
						}
					}
				}
				else
				{
					Debug.LogError("Failed to get audio clip: " + json["message"]);
				}
			}
		}
	}

	[ClientRpc]
	private void RpcSetSoundId(int id)
	{
		if (isServer) return;
		soundID = id;
	}



	[CreatorProperty, Archivable]
	public bool Autoplay
	{
		get => autoplay;
		set
		{
			autoplay = value;

			if (isServer)
				RpcChangeBoolProperty(0, value);
		}
	}



	[CreatorProperty, Archivable]
	public bool Loop
	{
		get => loop;
		set
		{
			loop = value;

			if (isServer)
				RpcChangeBoolProperty(1, value);
			else
				audioSource.loop = value;
		}
	}



	[CreatorProperty, Archivable]
	public bool PlayInWorld
	{
		get => playInWorld;
		set
		{
			playInWorld = value;

			if (isServer)
				RpcChangeBoolProperty(2, value);
			else
				audioSource.spatialBlend = value ? 1 : 0;
		}
	}



	[CreatorProperty, Archivable]
	public float Volume
	{
		get => audioSource.volume;
		set
		{
			volume = value;
			audioSource.volume = value;
			if (isServer)
				RpcSetVolume(value);
		}
	}

	public void Play()
	{
		_isPlaying = true;
		if (isServer)
			RpcPlay();
		else
			StartCoroutine(playC());
	}

	private IEnumerator playC()
	{
		if (soundID <= 0)
			yield break;

		bool played = false;
		int timeout = 0;

		while (!played)
		{
			if (audioSource.clip != null && clip.loadState == AudioDataLoadState.Loaded)
			{
				audioSource.Play();
				played = true;
				goto PlayLoop;
			}
			else
			{
				yield return new WaitForSeconds(0.1f);
				timeout++;
			}

			if (timeout > 50)
			{
				yield break;
			}
		}
PlayLoop:
		do
		{
			yield return new WaitForSeconds(1);
		} while (audioSource.isPlaying);
		_isPlaying = false;

	}

	public void Stop()
	{
		_isPlaying = false;
		if (isServer)
			RpcStop();
		else
			audioSource.Stop();
	}

	protected override void Awake()
	{
		base.Awake();
		audioSource = GetComponent<AudioSource>();
	}

	protected override void Start()
	{
		base.Start();

		if (!isServer)
		{
			SoundID = soundID;
			Autoplay = autoplay;
			Loop = loop;
			PlayInWorld = playInWorld;
			Volume = volume;

			if (Playing)
			{
				Play();
			}

		}
		else
		{
			if (Autoplay)
				Play();
		}
	}

	protected override void Update()
	{
		base.Update();
	}

	public override Instance Clone()
	{
		Sound clone = (Sound) New("Sound", Parent);
		try
		{
			clone.Name = Name;
			clone.Position = Position;
			clone.SoundID = SoundID;
			clone.Autoplay = Autoplay;
			clone.Loop = Loop;
			clone.Volume = Volume;
			clone.Pitch = Pitch;
			clone.PlayInWorld = PlayInWorld;
		}
		catch (Exception e)
		{
			Debug.LogError(e);
		}

		return clone;
	}

	protected override void OnHide()
	{
		base.OnHide();
		GetComponent<AudioSource>().enabled = false;
	}

	protected override void OnShow()
	{
		base.OnShow();
		GetComponent<AudioSource>().enabled = true;
	}

	[ClientRpc]
	private void RpcStop()
	{
		audioSource.Stop();
		StopCoroutine(playC());
	}

	[ClientRpc]
	private void RpcPlay()
	{
		StartCoroutine(playC());
	}

	[ClientRpc]
	private void RpcSetTime(float t)
	{
		if (isServer) return;
		Time = t;
	}

	[ClientRpc]
	private void RpcSetVolume(float vol)
	{
		if (isServer) return;
		Volume = vol;
	}

	[ClientRpc]
	private void RpcSetPitch(float p)
	{
		if (isServer) return;
		Pitch = p;
	}

	[ClientRpc]
	private void RpcChangeBoolProperty(int property, bool value)
	{
		switch (property)
		{
			case 0:
				autoplay = value;
				break;
			case 1:
				loop = value;
				audioSource.loop = value;
				break;
			case 2:
				playInWorld = value;
				audioSource.spatialBlend = value ? 1 : 0;
				break;
		}
	}
}
