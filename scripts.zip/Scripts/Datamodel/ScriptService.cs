using System;
using System.Collections;
using Mirror;
using MoonSharp.Interpreter;
using TMPro;
using UnityEngine;

public class ScriptService : Instance
{
	const string payload = @"function wait(N)
coroutine.yield(N);
return os.time();
end";

	protected override void Awake()
	{
		canReparent = false;
		base.Awake();
	}

	[MoonSharpHidden]
	public void RunScripts()
	{
		if (!isServer) return;
		CheckForScripts(Game.singleton);
	}

	[MoonSharpHidden]
	public void RunLocalScripts()
	{
		CheckForLocalScripts(Game.singleton);
	}

	void CheckForLocalScripts(Instance parent)
	{
		foreach (Instance instance in parent.GetChildren())
		{
			if (instance is LocalScript ls)
			{
				ls.Run();
			}
			CheckForLocalScripts(instance);
		}
	}

	void CheckForScripts(Instance parent)
	{
		foreach (Instance i in parent.GetChildren())
		{
			if (i.ClassName == "ScriptInstance" || i.ClassName == "Script")
			{
				ScriptInstance script = (ScriptInstance) i;
				script.Run();
			}
			CheckForScripts(i);
		}
	}

	[MoonSharpHidden]
	public void RunScript(BaseScript s)
	{
		if (CreatorController.IsCreator) return;
		StartCoroutine(RunScriptInstance(s));
	}

	IEnumerator RunScriptInstance(BaseScript scriptInstance)
	{
		if (scriptInstance is LocalScript && isServer && !LaunchController.isSolo)
		{
			yield break; // cant do localscript on server
		}
		if (scriptInstance.running) yield break;

		if (scriptInstance is BaseScript && !(scriptInstance is ScriptInstance || scriptInstance is LocalScript))
		{
			yield break;
		}

		yield return new WaitForEndOfFrame();
		string source = scriptInstance.source;

		Script script = new Script(CoreModules.Preset_SoftSandbox);
		scriptInstance.script = script;

		script.Options.DebugPrint = s => LuaPrint(s);

		UserData.RegisterProxyType<InstanceProxy, Instance>(r => new InstanceProxy(r));
		UserData.RegisterProxyType<DynamicInstanceProxy, DynamicInstance>(r => new DynamicInstanceProxy(r));
		UserData.RegisterProxyType<PartProxy, Part>(r => new PartProxy(r));
		UserData.RegisterProxyType<GameProxy, Game>(r => new GameProxy(r));
		UserData.RegisterProxyType<BaseScriptProxy, BaseScript>(r => new BaseScriptProxy(r));
		UserData.RegisterProxyType<ScriptInstanceProxy, ScriptInstance>(r => new ScriptInstanceProxy(r));
		UserData.RegisterProxyType<LocalScriptProxy, LocalScript>(r => new LocalScriptProxy(r));
		UserData.RegisterProxyType<RemoveEventProxy, RemoteEvent>(r => new RemoveEventProxy(r));
		UserData.RegisterProxyType<ScriptServiceProxy, ScriptService>(r => new ScriptServiceProxy(r));
		UserData.RegisterProxyType<EnvironmentProxy, Environment>(r => new EnvironmentProxy(r));
		UserData.RegisterProxyType<PlayerProxy, Player>(r => new PlayerProxy(r));
		UserData.RegisterProxyType<PlayersProxy, Players>(r => new PlayersProxy(r));
		UserData.RegisterProxyType<Text3DProxy, Text3D>(r => new Text3DProxy(r));
		UserData.RegisterProxyType<SoundProxy, Sound>(r => new SoundProxy(r));
		UserData.RegisterProxyType<ToolProxy, Tool>(r => new ToolProxy(r));
		UserData.RegisterProxyType<NPCProxy, NPC>(r => new NPCProxy(r));
		UserData.RegisterProxyType<SpotlightProxy, Spotlight>(r => new SpotlightProxy(r));
		UserData.RegisterProxyType<ValueBaseProxy, ValueBase>(r => new ValueBaseProxy(r));
		UserData.RegisterProxyType<BoolValueProxy, BoolValue>(r => new BoolValueProxy(r));
		UserData.RegisterProxyType<ColorValueProxy, ColorValue>(r => new ColorValueProxy(r));
		UserData.RegisterProxyType<StringValueProxy, StringValue>(r => new StringValueProxy(r));
		UserData.RegisterProxyType<InstanceValueProxy, InstanceValue>(r => new InstanceValueProxy(r));
		UserData.RegisterProxyType<IntValueProxy, IntValue>(r => new IntValueProxy(r));
		UserData.RegisterProxyType<NumberValueProxy, NumberValue>(r => new NumberValueProxy(r));
		UserData.RegisterProxyType<Vector3ValueProxy, Vector3Value>(r => new Vector3ValueProxy(r));
		UserData.RegisterProxyType<MeshPartProxy, MeshPart>(r => new MeshPartProxy(r));
		UserData.RegisterProxyType<BodyPositionProxy, BodyPosition>(r => new BodyPositionProxy(r));
		UserData.RegisterProxyType<BackpackProxy, Backpack>(r => new BackpackProxy(r));
		UserData.RegisterProxyType<LightingProxy, Lighting>(r => new LightingProxy(r));
		UserData.RegisterProxyType<ClimbableProxy, Climbable>(r => new ClimbableProxy(r));
		UserData.RegisterProxyType<DecalProxy, Decal>(r => new DecalProxy(r));
		UserData.RegisterProxyType<HiddenProxy, Hidden>(r => new HiddenProxy(r));
		UserData.RegisterProxyType<ModelProxy, Model>(r => new ModelProxy(r));
		UserData.RegisterProxyType<PointLightProxy, PointLight>(r => new PointLightProxy(r));
		UserData.RegisterProxyType<TrussProxy, Truss>(r => new TrussProxy(r));
		UserData.RegisterProxyType<SeatProxy, Seat>(r => new SeatProxy(r));
		UserData.RegisterProxyType<SkyBaseProxy, SkyBase>(r => new SkyBaseProxy(r));
		UserData.RegisterProxyType<ImageSkyProxy, ImageSky>(r => new ImageSkyProxy(r));
		UserData.RegisterProxyType<NetworkEventProxy, NetworkEvent>(r => new NetworkEventProxy(r));
		UserData.RegisterProxyType<PlayerDefaultsProxy, PlayerDefaults>(r => new PlayerDefaultsProxy(r));
		UserData.RegisterProxyType<GUIProxy, Polytoria.Datamodel.GUI>(r => new GUIProxy(r));
		UserData.RegisterProxyType<UIButtonProxy, Polytoria.Datamodel.UIButton>(r => new UIButtonProxy(r));
		UserData.RegisterProxyType<UIFieldProxy, Polytoria.Datamodel.UIField>(r => new UIFieldProxy(r));
		UserData.RegisterProxyType<UILabelProxy, Polytoria.Datamodel.UILabel>(r => new UILabelProxy(r));
		UserData.RegisterProxyType<UITextInputProxy, Polytoria.Datamodel.UITextInput>(r => new UITextInputProxy(r));
		UserData.RegisterProxyType<UIViewProxy, Polytoria.Datamodel.UIView>(r => new UIViewProxy(r));
		UserData.RegisterProxyType<UIImageProxy, Polytoria.Datamodel.UIImage>(r => new UIImageProxy(r));
		UserData.RegisterProxyType<UIHVLayoutProxy, Polytoria.Datamodel.UIHVLayout>(r => new UIHVLayoutProxy(r));
		UserData.RegisterProxyType<UIVerticalLayoutProxy, Polytoria.Datamodel.UIVerticalLayout>(r => new UIVerticalLayoutProxy(r));
		UserData.RegisterProxyType<UIHorizontalLayoutProxy, Polytoria.Datamodel.UIHorizontalLayout>(r => new UIHorizontalLayoutProxy(r));
		UserData.RegisterProxyType<PlayerGUIProxy, Polytoria.Datamodel.PlayerGUI>(r => new PlayerGUIProxy(r));

		UserData.RegisterProxyType<CameraControllerProxy, CameraController>(r => new CameraControllerProxy(r));
		UserData.RegisterProxyType<DatastoreProxy, Datastore>(r => new DatastoreProxy(r));
		UserData.RegisterProxyType<DataStoreServiceProxy, DataStoreService>(r => new DataStoreServiceProxy(r));

		UserData.RegisterType<Vector4>();
		UserData.RegisterType<Vector3>();
		UserData.RegisterType<Vector2>();
		UserData.RegisterType<Color>();
		UserData.RegisterType<LuaVector2>();
		UserData.RegisterType<LuaVector3>();
		UserData.RegisterType<LuaVector4>();
		UserData.RegisterType<LuaColor3>();
		UserData.RegisterType<LuaJSON>();
		UserData.RegisterType<LuaEvent>();
		UserData.RegisterType<PartShape>();
		UserData.RegisterType<PartMaterial>();
		UserData.RegisterType<SkyboxPreset>();
		UserData.RegisterType<LeanTweenType>();
		UserData.RegisterType<AmbientSource>();
		UserData.RegisterType<HorizontalAlignmentOptions>();
		UserData.RegisterType<VerticalAlignmentOptions>();
		UserData.RegisterType<TMP_InputField.LineType>();
		UserData.RegisterType<TMP_InputField.ContentType>();
		UserData.RegisterType<Polytoria.Datamodel.TextFontPreset>();
		UserData.RegisterType<Polytoria.Datamodel.TextJustify>();
		UserData.RegisterType<Polytoria.Datamodel.TextVerticalAlign>();
		UserData.RegisterType<RayResult>();
		UserData.RegisterType<CameraMode>();
		UserData.RegisterType<NetMessage>();
		UserData.RegisterType<PlayerChatEvent>();
		UserData.RegisterType<TextAnchor>();
		UserData.RegisterType<ImageType>();

		UserData.RegisterType<TweenService>();
		UserData.RegisterType<InputService>();
		UserData.RegisterType<FilterService>();
		UserData.RegisterType<HttpService>();
		UserData.RegisterType<ChatService>();

		UserData.RegisterType<Polytoria.Datamodel.GUI>();
		UserData.RegisterType<Polytoria.Datamodel.UIButton>();
		UserData.RegisterType<Polytoria.Datamodel.UIField>();
		UserData.RegisterType<Polytoria.Datamodel.UILabel>();
		UserData.RegisterType<Polytoria.Datamodel.UITextInput>();
		UserData.RegisterType<Polytoria.Datamodel.UIView>();
		UserData.RegisterType<Polytoria.Datamodel.UIHVLayout>();
		UserData.RegisterType<Polytoria.Datamodel.UIVerticalLayout>();
		UserData.RegisterType<Polytoria.Datamodel.UIHorizontalLayout>();

		script.Globals["Instance"] = typeof(Instance);
		script.Globals["Tween"] = typeof(TweenService);
		script.Globals["Input"] = typeof(InputService);
		script.Globals["Filter"] = typeof(FilterService);
		script.Globals["Http"] = typeof(HttpService);
		script.Globals["Vector2"] = typeof(LuaVector2);
		script.Globals["Vector3"] = typeof(LuaVector3);
		script.Globals["Vector4"] = typeof(LuaVector4);
		script.Globals["Color"] = typeof(LuaColor3);
		script.Globals["NetMessage"] = typeof(NetMessage);
		script.Globals["NetworkMessage"] = typeof(NetMessage);
		script.Globals["PartShape"] = typeof(PartShape);
		script.Globals["PartMaterial"] = typeof(PartMaterial);
		script.Globals["TweenType"] = typeof(LeanTweenType);
		script.Globals["SkyboxPreset"] = typeof(SkyboxPreset);
		script.Globals["AmbientSource"] = typeof(AmbientSource);
		script.Globals["HorizontalAlignment"] = typeof(HorizontalAlignmentOptions);
		script.Globals["VerticalAlignment"] = typeof(VerticalAlignmentOptions);
		script.Globals["TextAnchor"] = typeof(TextAnchor);
		script.Globals["CameraMode"] = typeof(CameraMode);
		script.Globals["ContentType"] = typeof(TMP_InputField.ContentType);
		script.Globals["LineType"] = typeof(TMP_InputField.LineType);
		script.Globals["TextFontPreset"] = typeof(Polytoria.Datamodel.TextFontPreset);
		script.Globals["TextJustify"] = typeof(Polytoria.Datamodel.TextJustify);
		script.Globals["TextVerticalAlign"] = typeof(Polytoria.Datamodel.TextVerticalAlign);
		script.Globals["ImageType"] = typeof(ImageType);

		DynValue g = UserData.Create(Game.singleton);
		script.Globals.Set("game", g);

		DynValue sc = UserData.Create(scriptInstance);
		script.Globals.Set("script", sc);

		DynValue cs = UserData.Create(ChatService.instance);
		script.Globals.Set("Chat", cs);

		DynValue ds = UserData.Create(DataStoreService.Instance);
		script.Globals.Set("Datastore", ds);

		script.Globals["noise"] = (Func<float, float, float>) Mathf.PerlinNoise;
		script.Globals["spawn"] = (Action<DynValue>) LuaSpawn;
		script.Globals["Camera"] = CameraController.instance;
		script.Globals["tick"] = (Func<int>) Tick;
		script.Globals["time"] = (Func<int>) GameTime;

		DynValue res = null;
		DynValue coroutine = null;

		yield return new WaitForEndOfFrame();

		res = ExecuteScriptInstance(script, scriptInstance);
		scriptInstance.running = true;

		if (res == null)
		{
			yield break;
		}

		coroutine = script.CreateCoroutine(res);
		coroutine.Coroutine.AutoYieldCounter = 10000;

		while (coroutine.Coroutine.State != CoroutineState.Dead)
		{
			DynValue result = ResumeScriptCoroutine(coroutine, "Script '" + scriptInstance.Name + "'");
			if (result == null)
			{
				yield break;
			}
			switch (result.Type)
			{
				case DataType.Number:
					yield return new WaitForSeconds((float) result.Number);
					break;
				default:
					yield return new WaitForFixedUpdate();
					break;
			}
		}
	}

	public void LuaSpawn(DynValue func)
	{
		CallFunc(func);
	}

	void LuaPrint(string message, bool error = false)
	{
		if (error)
		{
			Debug.LogError("Lua Error: " + message);
		}
		else
		{
			Debug.Log("Lua: " + message);
		}

		if (isServer)
		{
			RpcOnLuaPrintReceive(message, error);
		}
		else
		{
			UIController.singleton.DebugLog(message, error);
		}
	}

	[ClientRpc]
	void RpcOnLuaPrintReceive(string message, bool error)
	{
		UIController.singleton.DebugLog(message, error);
	}

	private DynValue ResumeScriptCoroutine(DynValue coroutine, string identifier, params object[] par)
	{
		DynValue res = null;

		try
		{
			if (coroutine.Coroutine.State == CoroutineState.ForceSuspended)
				res = coroutine.Coroutine.Resume();
			else
				res = coroutine.Coroutine.Resume(par);
		}
		catch (InterpreterException err)
		{
			LuaPrint(err.DecoratedMessage, true);
		}

		return res;
	}

	private DynValue ExecuteScriptInstance(Script script, BaseScript s)
	{
		string scriptFunc = @"return function()
" + payload + @"
" + s.source + @"
end";

		DynValue res = null;

		try
		{
			res = script.DoString(scriptFunc, codeFriendlyName: s.FullName);
		}
		catch (InterpreterException err)
		{
			LuaPrint(err.DecoratedMessage, true);
		}

		return res;
	}

	[MoonSharpHidden]
	public void CallFunc(DynValue func, params object[] par)
	{
		if (func != null && func.IsNotNil())
			StartCoroutine(InvokeEvent(func, par));
	}

	[MoonSharpHidden]
	public IEnumerator InvokeEvent(DynValue func, params object[] par)
	{
		DynValue coroutine;
		coroutine = func.Function.OwnerScript.CreateCoroutine(func.Function);
		coroutine.Coroutine.AutoYieldCounter = 2000;

		while (coroutine.Coroutine.State != CoroutineState.Dead)
		{
			DynValue result = ResumeScriptCoroutine(coroutine, "LuaEvent", par);
			if (result == null)
			{
				yield break;
			}
			switch (result.Type)
			{
				case DataType.Number:
					yield return new WaitForSeconds((float) result.Number);
					break;
				default:
					yield return new WaitForFixedUpdate();
					break;
			}
		}
	}

	int Tick()
	{
		return (int) (DateTime.UtcNow - new DateTime(1970, 1, 1)).TotalSeconds;
	}

	int GameTime()
	{
		return (int) (Time.timeSinceLevelLoad);
	}
}
