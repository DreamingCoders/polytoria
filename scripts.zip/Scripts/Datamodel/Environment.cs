using System.Collections.Generic;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;

public class Environment : Instance
{
	[SyncVar] private SkyboxPreset skybox = SkyboxPreset.Day1;
	[SyncVar] private Vector3 gravity;
	[SyncVar] private bool fogEnabled = false;
	[SyncVar] private float fogStartDistance = 0;
	[SyncVar] private float fogEndDistance = 250f;
	[SyncVar] private Color fogColor = Color.white;

	[CreatorProperty, Archivable]
	public SkyboxPreset Skybox
	{
		get { return skybox; }
		set
		{
			skybox = value;

			Material mat = Resources.Load<Material>("Skyboxes/" + value.ToString());
			RenderSettings.skybox = mat;
			DynamicGI.UpdateEnvironment();

			if (isServer)
			{
				RpcSetSkybox(value);
			}
		}
	}

	[CreatorProperty, Archivable]
	public Vector3 Gravity
	{
		get => gravity;
		set
		{
			gravity = value;
			Physics.gravity = gravity;

			if (isServer)
				RpcSetGravity(value);
		}
	}

	[CreatorProperty, Archivable]
	public bool FogEnabled
	{
		get => fogEnabled;
		set
		{
			fogEnabled = value;
			RenderSettings.fog = value;
			RenderSettings.fogMode = FogMode.Linear;
			RenderSettings.fogStartDistance = fogStartDistance;
			RenderSettings.fogEndDistance = fogEndDistance;
			RenderSettings.fogColor = fogColor;

			if (isServer)
				RpcSetFogEnabled(value);
		}
	}

	[CreatorProperty, Archivable]
	public float FogStartDistance
	{
		get => fogStartDistance;
		set
		{
			fogStartDistance = value;
			RenderSettings.fogStartDistance = value;

			if (isServer)
				RpcSetFogStartDistance(value);
		}
	}

	[CreatorProperty, Archivable]
	public float FogEndDistance
	{
		get => fogEndDistance;
		set
		{
			fogEndDistance = value;
			RenderSettings.fogEndDistance = value;

			if (isServer)
				RpcSetFogEndDistance(value);
		}
	}

	[CreatorProperty, Archivable]
	public Color FogColor
	{
		get => fogColor;
		set
		{
			fogColor = value;
			RenderSettings.fogColor = value;

			if (isServer)
				RpcSetFogColor(value);
		}
	}

	GameObject explosionPrefab;

	protected override void Awake()
	{
		canReparent = false;
		base.Awake();
		gravity = Physics.gravity;
	}

	public void CreateExplosion(Vector3 position, float radius = 10f, float force = 5000f, bool affectKinematic = true, DynValue func = null)
	{
		Collider[] colliders = Physics.OverlapSphere(position, radius);
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();
		if (isServer)
			RpcExplode(position, radius);

		foreach (Collider col in colliders)
		{
			Rigidbody rb = col.GetComponent<Rigidbody>();

			if (rb)
			{
				if (affectKinematic)
				{
					Part part = rb.GetComponent<Part>();

					if (part)
					{
						bool unanchor = true;
						float volume = part.Size.x * part.Size.y * part.Size.z;
						float maxVolume = Mathf.Pow(radius * 2f, 3f);

						if (volume > maxVolume)
						{
							unanchor = false;
						}

						if (part.Size.x > radius * 1.3 || part.Size.y > radius * 1.3 || part.Size.z > radius * 1.3)
						{
							unanchor = false;
						}

						if (Vector3.Distance(rb.transform.position, position) > radius)
						{
							unanchor = false;
						}

						if (unanchor)
						{
							part.Anchored = false;
						}
					}
				}

				Instance i = rb.GetComponent<Instance>();
				if (i && func != null)
				{
					ss.CallFunc(func, i);
				}

				if (rb.GetComponent<Player>()) rb.GetComponent<Player>().Health = 0;
				rb.AddExplosionForce(force, position, radius, 3f);
			}
		}
	}

	public RayResult? Raycast(Vector3 origin, Vector3 direction, float maxDistance = Mathf.Infinity, List<Instance> ignoreList = null)
	{
		RaycastHit[] hits = Physics.RaycastAll(origin, direction, maxDistance);

		foreach (RaycastHit hit in hits)
		{
			Instance i = hit.collider.GetComponent<Instance>();

			if (i && ignoreList != null && ignoreList.Contains(i))
			{
				continue;
			}

			return new RayResult
			{
				Origin = origin,
				Direction = direction,
				Position = hit.point,
				Normal = hit.normal,
				Distance = hit.distance,
				Instance = i
			};
		}

		return null;
	}

	public RayResult[] RaycastAll(Vector3 origin, Vector3 direction, float maxDistance = Mathf.Infinity, List<Instance> ignoreList = null)
	{
		RaycastHit[] hits = Physics.RaycastAll(origin, direction, maxDistance);
		List<RayResult> results = new List<RayResult>();

		foreach (RaycastHit hit in hits)
		{
			Instance instance = hit.collider.GetComponent<Instance>();

			if (!instance || (ignoreList != null && ignoreList.Contains(instance)))
			{
				continue;
			}

			results.Add(new RayResult
			{
				Origin = origin,
				Direction = direction,
				Position = hit.point,
				Normal = hit.normal,
				Distance = hit.distance,
				Instance = instance
			});
		}

		return results.ToArray();
	}

	protected override void Start()
	{
		base.Start();
		RenderSettings.fogMode = FogMode.Linear;

		if (!isServer)
		{
			if (FindObjectOfType<SkyBase>() == null)
				Skybox = skybox;

			Gravity = gravity;
			FogStartDistance = fogStartDistance;
			FogEndDistance = fogEndDistance;
			FogColor = fogColor;
		}

		FogEnabled = fogEnabled;

		explosionPrefab = Resources.Load<GameObject>("Effects/Explosion");
	}

	[ClientRpc]
	void RpcSetSkybox(SkyboxPreset sky)
	{
		if (isServer) return;
		Skybox = sky;
	}

	[ClientRpc]
	void RpcExplode(Vector3 position, float radius)
	{
		GameObject ex = Instantiate(explosionPrefab, position, Quaternion.identity);
		foreach (Transform child in ex.transform)
		{
			child.localScale = Vector3.one * (radius / 3f);
		}

		Destroy(ex, 4f);
	}

	[ClientRpc]
	void RpcSetGravity(Vector3 g)
	{
		if (isServer) return;
		Gravity = g;
	}

	[ClientRpc]
	void RpcSetFogEnabled(bool enabled)
	{
		if (isServer) return;
		FogEnabled = enabled;
	}

	[ClientRpc]
	void RpcSetFogStartDistance(float dist)
	{
		if (isServer) return;
		FogStartDistance = dist;
	}

	[ClientRpc]
	void RpcSetFogEndDistance(float dist)
	{
		if (isServer) return;
		FogEndDistance = dist;
	}

	[ClientRpc]
	void RpcSetFogColor(Color c)
	{
		if (isServer) return;
		FogColor = c;
	}
}

public enum SkyboxPreset
{
	Day1,
	Day2,
	Day3,
	Day4,
	Day5,
	Day6,
	Day7,
	Morning1,
	Morning2,
	Morning3,
	Morning4,
	Night1,
	Night2,
	Night3,
	Night4,
	Night5,
	Sunset1,
	Sunset2,
	Sunset3,
	Sunset4,
	Sunset5
}

public struct RayResult
{
	public Vector3 Origin { get; set; }
	public Vector3 Direction { get; set; }
	public Vector3 Position { get; set; }
	public Vector3 Normal { get; set; }
	public float Distance { get; set; }
	public Instance Instance { get; set; }
}
