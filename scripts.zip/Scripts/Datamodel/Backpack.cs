public class Backpack : Instance
{
	protected override void Awake()
	{
		canReparent = false;
		hidesMembers = true;
		base.Awake();
	}

	protected override void Start()
	{
		base.Start();
	}
}
