using System.Collections;
using System.Collections.Generic;
using Mirror;
using SimpleJSON;
using UnityEngine;
using UnityEngine.Networking;

public class ImageSky : SkyBase
{
	public static Material skyboxMaterial;

	static readonly string topTextureName = "_UpTex";
	static readonly string bottomTextureName = "_DownTex";
	static readonly string leftTextureName = "_LeftTex";
	static readonly string rightTextureName = "_RightTex";
	static readonly string frontTextureName = "_FrontTex";
	static readonly string backTextureName = "_BackTex";

	bool processing = false;

	[SyncVar] int topId = 14168;
	[SyncVar] int bottomId = 14166;
	[SyncVar] int leftId = 14154;
	[SyncVar] int rightId = 14155;
	[SyncVar] int frontId = 14153;
	[SyncVar] int backId = 14151;

	Queue<ImageLoadQueueEntry> queue = new Queue<ImageLoadQueueEntry>();

	[CreatorProperty, Archivable]
	public int TopId
	{
		get => topId;
		set
		{
			topId = value;
			queue.Enqueue(new ImageLoadQueueEntry { TextureName = topTextureName, ImageId = value });

			if (isServer)
				RpcSetImageId(SkyboxSide.Top, value);
		}
	}

	[CreatorProperty, Archivable]
	public int BottomId
	{
		get => bottomId;
		set
		{
			bottomId = value;
			queue.Enqueue(new ImageLoadQueueEntry { TextureName = bottomTextureName, ImageId = value });

			if (isServer)
				RpcSetImageId(SkyboxSide.Bottom, value);
		}
	}

	[CreatorProperty, Archivable]
	public int LeftId
	{
		get => leftId;
		set
		{
			leftId = value;
			queue.Enqueue(new ImageLoadQueueEntry { TextureName = leftTextureName, ImageId = value });

			if (isServer)
				RpcSetImageId(SkyboxSide.Left, value);
		}
	}

	[CreatorProperty, Archivable]
	public int RightId
	{
		get => rightId;
		set
		{
			rightId = value;
			queue.Enqueue(new ImageLoadQueueEntry { TextureName = rightTextureName, ImageId = value });

			if (isServer)
				RpcSetImageId(SkyboxSide.Right, value);
		}
	}

	[CreatorProperty, Archivable]
	public int FrontId
	{
		get => frontId;
		set
		{
			frontId = value;
			queue.Enqueue(new ImageLoadQueueEntry { TextureName = frontTextureName, ImageId = value });

			if (isServer)
				RpcSetImageId(SkyboxSide.Front, value);
		}
	}

	[CreatorProperty, Archivable]
	public int BackId
	{
		get => backId;
		set
		{
			backId = value;
			queue.Enqueue(new ImageLoadQueueEntry { TextureName = backTextureName, ImageId = value });

			if (isServer)
				RpcSetImageId(SkyboxSide.Back, value);
		}
	}

	protected override void Start()
	{
		base.Start();

		if (!isServer)
		{
			TopId = topId;
			BottomId = bottomId;
			FrontId = frontId;
			BackId = backId;
			LeftId = leftId;
			RightId = rightId;
		}

		Loaded();
	}

	private void OnEnable() // for creator delete
	{
		Loaded();
	}

	void Loaded()
	{
		if (skyboxMaterial == null)
		{
			skyboxMaterial = Resources.Load<Material>("Materials/Internal/ImageSkybox");
		}

		RenderSettings.skybox = skyboxMaterial;

		queue.Enqueue(new ImageLoadQueueEntry { TextureName = topTextureName, ImageId = TopId });
		queue.Enqueue(new ImageLoadQueueEntry { TextureName = bottomTextureName, ImageId = BottomId });
		queue.Enqueue(new ImageLoadQueueEntry { TextureName = leftTextureName, ImageId = LeftId });
		queue.Enqueue(new ImageLoadQueueEntry { TextureName = rightTextureName, ImageId = RightId });
		queue.Enqueue(new ImageLoadQueueEntry { TextureName = frontTextureName, ImageId = FrontId });
		queue.Enqueue(new ImageLoadQueueEntry { TextureName = backTextureName, ImageId = BackId });
	}

	private void Update()
	{
		if (!processing && queue.Count > 0)
		{
			StartCoroutine(LoadSkyboxImage(queue.Dequeue()));
		}
	}

	IEnumerator LoadSkyboxImage(ImageLoadQueueEntry entry)
	{
		processing = true;

		using (UnityWebRequest uwr = UnityWebRequest.Get("https://api.polytoria.com/v1/assets/serve/" + entry.ImageId + "/asset"))
		{
			yield return uwr.SendWebRequest();

			if (uwr.result == UnityWebRequest.Result.Success)
			{
				JSONNode data = JSON.Parse(uwr.downloadHandler.text);
				string url = data["url"].Value;
				using (UnityWebRequest twr = UnityWebRequestTexture.GetTexture(url))
				{
					yield return twr.SendWebRequest();

					if (twr.result == UnityWebRequest.Result.Success)
					{
						Texture2D wwwTexture = DownloadHandlerTexture.GetContent(twr);
						Texture2D texture = new Texture2D(wwwTexture.width, wwwTexture.height, wwwTexture.format, true);
						texture.LoadImage(twr.downloadHandler.data);
						texture.Apply(true);
						texture.wrapMode = TextureWrapMode.Clamp;

						skyboxMaterial.SetTexture(entry.TextureName, texture);
						DynamicGI.UpdateEnvironment();
					}
					else
					{
						Debug.LogError("Could not load skybox texture! " + twr.error);
					}
				}
			}
			else
			{
				Debug.LogError("Could not load skybox texture! " + uwr.error);
			}
		}

		processing = false;
	}

	struct ImageLoadQueueEntry
	{
		public string TextureName { get; set; }
		public int ImageId { get; set; }
	}

	[ClientRpc]
	void RpcSetImageId(SkyboxSide side, int id)
	{
		if (isServer) return;
		switch (side)
		{
			case SkyboxSide.Top:
				TopId = id;
				break;
			case SkyboxSide.Bottom:
				BottomId = id;
				break;
			case SkyboxSide.Left:
				LeftId = id;
				break;
			case SkyboxSide.Right:
				RightId = id;
				break;
			case SkyboxSide.Front:
				FrontId = id;
				break;
			case SkyboxSide.Back:
				BackId = id;
				break;
		}
	}

	enum SkyboxSide
	{
		Top,
		Bottom,
		Left,
		Right,
		Front,
		Back
	}
}
