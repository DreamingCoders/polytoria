public class SkyBase : Instance
{
	protected void OnDisable()
	{
		//base.OnDestroy();
		Environment env = Game.singleton.FindChildOfType<Environment>();

		if (env != null)
			env.Skybox = env.Skybox;
	}
}
