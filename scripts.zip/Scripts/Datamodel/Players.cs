using System.Collections;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;

public class Players : Instance
{
	public LuaEvent PlayerAdded = new LuaEvent();
	public LuaEvent PlayerRemoved = new LuaEvent();

	private Player _localPlayer;
	public Player LocalPlayer => _localPlayer;

	[SyncVar] bool playerCollisions;

	[Archivable, CreatorProperty]
	public bool PlayerCollisionEnabled
	{
		get => playerCollisions;
		set
		{
			playerCollisions = value;

			Physics.IgnoreLayerCollision(LayerMask.NameToLayer("LocalPlayer"), LayerMask.NameToLayer("Player"), !value);
			Physics.IgnoreLayerCollision(LayerMask.NameToLayer("Player"), LayerMask.NameToLayer("Player"), !value);

			if (isServer)
				RpcSetPlayerCollisions(value);
		}
	}

	protected override void Awake()
	{
		canReparent = false;
		base.Awake();
	}

	protected override void Start()
	{
		base.Start();

		if (!isServer)
		{
			PlayerCollisionEnabled = playerCollisions;
		}
	}

	public Player[] GetPlayers()
	{
		return GetChildrenOfType<Player>();
	}

	public Player GetPlayer(string username)
	{
		foreach (Player player in GetPlayers())
		{
			if (player.Name == username)
				return player;
		}
		return null;
	}

	public Player GetPlayerByID(int id)
	{
		foreach (Player player in GetPlayers())
		{
			if (player.UserID == id)
				return player;
		}
		return null;
	}

	[MoonSharpHidden]
	public void AddPlayer(Player player)
	{
		player.Parent = this;
		StartCoroutine(DelayedPlayerAddEvent(player));
		if (isServer)
			PlayerAddedClientRpc(player);
	}

	IEnumerator DelayedPlayerAddEvent(Player player)
	{
		yield return new WaitForSeconds(0.5f);
		PlayerAdded?.Invoke(player);
	}

	[MoonSharpHidden]
	public void NotifyPlayerDestroyed(Player player)
	{
		PlayerRemoved?.Invoke(player);

		if (isServer)
			PlayerRemovedClientRpc(player.Name);
	}

	[ClientRpc]
	void PlayerAddedClientRpc(Player p)
	{
		UIController.singleton.AddLeaderboardUser(p);
	}

	[ClientRpc]
	void PlayerRemovedClientRpc(string name)
	{
		UIController.singleton.RemoveLeaderboardUser(name);
	}

	[ClientRpc]
	void RpcSetPlayerCollisions(bool enabled)
	{
		if (!isServer)
			return;

		PlayerCollisionEnabled = enabled;
	}

	[MoonSharpHidden]
	public void SetLocalPlayer(Player player)
	{
		_localPlayer = player;
	}
}
