using System.Collections;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;

public class BaseScript : Instance
{
	public bool running = false;
	[SyncVar][MoonSharpHidden] public string source;
	[MoonSharpHidden] public Script script;

	[MoonSharpHidden, Archivable]
	public string Source
	{
		get => source;
		set => source = value;
	}

	public new object this[string name]
	{
		get
		{
			return script.Globals[name];
		}
		set
		{
			script.Globals[name] = value;
		}
	}

	protected override void Start()
	{
		base.Start();

		if (!isServer)
		{
			Source = source;
		}
	}

	[MoonSharpHidden]
	public void Run()
	{
		if (isHidden) return;
		if (Game.singleton == null) return;
		ScriptService ss = Game.singleton.FindChildOfType<ScriptService>();

		if (ss)
		{
			ss.RunScript(this);

			if (isServer && this is LocalScript)
			{
				RpcRun();
			}
		}
	}

	[ClientRpc]
	void RpcRun()
	{
		if (isServer) return;

		IEnumerator DelayedRun()
		{
			yield return new WaitForEndOfFrame();
			Run();
		}

		StartCoroutine(DelayedRun());
	}

	public void Call(string function, params object[] args)
	{
		Game.singleton.FindChildOfType<ScriptService>().CallFunc(script.Globals.Get(function), args);
	}

	public override Instance Clone()
	{
		BaseScript clone = (BaseScript) New(this.className, Parent);
		try
		{
			clone.Parent = Parent;
			clone.Name = Name;

			clone.Source = Source;

			foreach (Instance child in GetChildren())
			{
				Instance clonedChild = child.Clone();
				clonedChild.Parent = clone;
			}
		}
		catch (System.Exception e)
		{
			Debug.LogError(e);
		}

		clone.Run();

		return clone;
	}

	protected override void OnHide()
	{
		base.OnHide();
	}

	protected override void OnShow()
	{
		base.OnShow();

		if (!running) Run();
	}
}
