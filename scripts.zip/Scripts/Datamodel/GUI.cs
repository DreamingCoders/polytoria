using Mirror;
using UnityEngine;

namespace Polytoria.Datamodel
{
	public class GUI : Instance
	{
		CreatorViewport vp;
		[SyncVar(hook = nameof(SyncSetVisible))] bool visible = true;

		[CreatorProperty, Archivable]
		public bool Visible
		{
			get => visible;
			set
			{
				visible = value;
				isHidden = !visible;
				if (visible)
				{
					OnShow();
				}
				else
				{
					OnHide();
				}
			}
		}

		protected override void Start()
		{
			base.Start();

			vp = GameObject.FindObjectOfType<CreatorViewport>();
		}

		public void Update()
		{
			if (vp != null)
			{
				RectTransform rt = (RectTransform) vp.transform;
				RectTransform rt2 = (RectTransform) transform;

				rt2.anchorMin = rt.anchorMin;
				rt2.anchorMax = rt.anchorMax;
				rt2.offsetMin = rt.offsetMin;
				rt2.offsetMax = rt.offsetMax;
			}
			else
			{
				RectTransform rt = (RectTransform) transform;
				rt.anchorMin = Vector2.zero;
				rt.anchorMax = Vector2.one;
				rt.sizeDelta = Vector2.zero;
				rt.offsetMin = Vector2.zero;
				rt.offsetMax = Vector2.zero;
			}
		}

		public void SyncSetVisible(bool oldValue, bool newValue)
		{
			Visible = newValue;
		}

		protected override void OnHide()
		{
			base.OnHide();
		}

		protected override void OnShow()
		{
			base.OnShow();
		}

		public override Instance Clone()
		{
			GUI clone = (GUI) New("GUI", Parent);
			try
			{
				clone.Name = Name;
				clone.Visible = Visible;

				foreach (Instance child in GetChildren())
				{
					Instance childClone = child.Clone();
					childClone.Parent = clone;
				}
			}
			catch (System.Exception e)
			{
				Debug.LogError(e);
			}
			return clone;
		}
	}
}