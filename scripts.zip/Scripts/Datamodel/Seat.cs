using System;
using Mirror;
using MoonSharp.Interpreter;
using UnityEngine;
public class Seat : Part
{
	[SyncVar] Player occupant;
	public Player Occupant => occupant;
	float timeUntilCanSitAgain = 0;

	[MoonSharpHidden] public event Action<Player> _Sat;
	public LuaEvent Sat = new LuaEvent();

	[MoonSharpHidden] public event Action<Player> _Vacated;
	public LuaEvent Vacated = new LuaEvent();

	protected override void Start()
	{
		base.Start();
		Transform seatTransform = new GameObject("SeatTransform").transform;
		seatTransform.SetParent(transform);
		seatTransform.localPosition = Vector3.up / 2;
		seatTransform.localRotation = Quaternion.identity;
	}

	protected override void Update()
	{
		base.Update();

		if (timeUntilCanSitAgain > 0)
		{
			timeUntilCanSitAgain -= Time.deltaTime;
		}
	}

	protected override void OnCollisionEnter(Collision collision)
	{
		base.OnCollisionEnter(collision);

		if (timeUntilCanSitAgain <= 0)
		{
			Player plr = collision.gameObject.GetComponent<Player>();
			if (plr != null && plr.isLocalPlayer)
			{
				plr.Sit(this);
				timeUntilCanSitAgain = 1;
			}
		}
	}

	protected override void OnTriggerEnter(Collider other)
	{
		base.OnTriggerEnter(other);

		if (timeUntilCanSitAgain <= 0)
		{
			Player plr = other.gameObject.GetComponent<Player>();
			if (plr != null && plr.isLocalPlayer)
			{
				plr.Sit(this);
				timeUntilCanSitAgain = 1;
			}
		}
	}

	[MoonSharpHidden]
	public void SetOccupant(Player player)
	{
		if (player == null)
		{
			_Vacated?.Invoke(occupant);
			Vacated?.Invoke(occupant);
		}
		else
		{
			_Sat?.Invoke(player);
			Sat?.Invoke(player);
		}
		occupant = player;

	}

	public override Instance Clone()
	{
		Seat clone = (Seat) New("Seat", Parent);
		clone.Parent = Parent;
		clone.Name = Name;
		clone.CanCollide = CanCollide;
		clone.Anchored = Anchored;
		clone.Color = Color;
		clone.Shape = Shape;
		clone.HideStuds = HideStuds;
		clone.Material = Material;
		clone.IsSpawn = IsSpawn;
		clone.Position = Position;
		clone.Rotation = Rotation;
		clone.Size = Size;

		foreach (Instance child in GetChildren())
		{
			Instance clonedChild = child.Clone();
			clonedChild.Parent = clone;
		}

		return clone;
	}
}
