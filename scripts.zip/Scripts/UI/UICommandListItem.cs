using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UICommandListItem : MonoBehaviour
{
	private static List<Sprite> commandIcons = new List<Sprite>();
	private static List<Sprite> commandIconsActive = new List<Sprite>();

	private static Sprite contSprite;
	private static Sprite contSpriteActive;

	private static bool loaded = false;

	private Image cont;
	private Image icon;
	private TMP_Text nameT;
	private TMP_Text description;

	void Awake()
	{
		if (!loaded)
		{
			loaded = true;
			commandIcons.Add(Resources.Load<Sprite>("Textures/SlashCommands/slash"));
			commandIconsActive.Add(Resources.Load<Sprite>("Textures/SlashCommands/slash-sel"));
			commandIcons.Add(Resources.Load<Sprite>("Textures/SlashCommands/emote"));
			commandIconsActive.Add(Resources.Load<Sprite>("Textures/SlashCommands/emote-sel"));

			contSprite = Resources.Load<Sprite>("Textures/SlashCommands/slashCommand");
			contSpriteActive = Resources.Load<Sprite>("Textures/SlashCommands/slashCommand-sel");
		}

		cont = transform.GetComponent<Image>();
		icon = transform.Find("CmdIcon").GetComponent<Image>();
		nameT = transform.Find("CmdName").GetComponent<TMP_Text>();
		description = transform.Find("CmdDesc").GetComponent<TMP_Text>();
	}

	private SlashCommand cmd;
	private bool active;
	public void SetCommand(SlashCommand cmd)
	{
		this.cmd = cmd;
		icon.sprite = commandIcons[cmd.Icon];
		nameT.text = cmd.CommandName;
		description.text = cmd.Description;
	}

	public void SetActive(bool active)
	{
		UICommandList.ActiveCommandFilled = false;
		this.active = active;
		cont.sprite = active ? contSpriteActive : contSprite;
		icon.sprite = active ? commandIconsActive[cmd.Icon] : commandIcons[cmd.Icon];
		if (active)
			UICommandList.ActiveCommand = cmd;
	}
}
