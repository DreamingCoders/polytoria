using UnityEngine;

public class CreatorViewport : MonoBehaviour
{
	/*private Vector2 resolution;
	private RenderTexture render;
	private RectTransform rect;

	private void Awake()
	{
		resolution = new Vector2(Screen.width, Screen.height);
		rect = GetComponent<RectTransform>();
	}
	void Start() {
		ResetRenderTexture();
	}
	public Camera cam;
	void ResetRenderTexture() {
		render = new RenderTexture((int)rect.rect.width, (int)rect.rect.height, 24);
		GetComponent<RawImage>().texture = render;
		GetComponent<RawImage>().color = new Color(1, 1, 1, 1);
		cam.targetTexture = render;
	}

	private void Update ()
	{
		if (resolution.x != Screen.width || resolution.y != Screen.height)
		{
			ResetRenderTexture();

			resolution.x = Screen.width;
			resolution.y = Screen.height;
		}
	}*/
	private RectTransform rect;

	private void Awake()
	{
		rect = GetComponent<RectTransform>();
	}
	void Update()
	{
		Rect r = rect.rect;

		float rel_sizeX = r.width / Screen.width,
			  rel_sizeY = r.height / Screen.height,
			  rel_posX = rect.offsetMin.x / Screen.width,
			  rel_posY = rect.offsetMin.y / Screen.height;

		Camera.main.rect = new Rect(rel_posX, rel_posY, rel_sizeX, rel_sizeY);
	}

}
