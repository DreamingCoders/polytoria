using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class SlashCommand
{
	public int Icon;
	public string CommandName;
	public string[] Args;
	public string Description;
}
public class UICommandList : MonoBehaviour
{
	public static bool IsActive = false;
	public static SlashCommand ActiveCommand = null;
	public static bool ActiveCommandFilled = false;
	private Transform container;
	private Transform listContainer;
	private Transform emptyContainer;
	private ScrollRect scrollRect;
	public SlashCommand[] commands;
	private List<Transform> commandObjects = new List<Transform>();
	void Awake()
	{
		container = transform.Find("CommandListInterface");
		scrollRect = container.GetComponent<ScrollRect>();
		listContainer = transform.Find("CommandListInterface/Viewport/Content");
		emptyContainer = transform.Find("CommandListInterface/Empty");
	}
	[SerializeField] private int curActive = 0;
	void Update()
	{
		int oldActive = curActive;
		if (Input.GetKeyDown(KeyCode.DownArrow))
		{
			curActive++;
		}
		if (Input.GetKeyDown(KeyCode.UpArrow))
		{
			curActive--;
		}
		if (oldActive != curActive)
		{
			UIController.singleton.ChatBar.caretPosition = UIController.singleton.ChatBar.text.Length;
			if (curActive < 0)
				curActive = commandObjects.Count - 1;
			if (curActive >= commandObjects.Count)
				curActive = 0;
			for (int i = 0; i < commandObjects.Count; i++)
				commandObjects[i].GetComponent<UICommandListItem>().SetActive(i == curActive);

			//scroll to keep object in view
			scrollRect.verticalNormalizedPosition = commandObjects.Count > 4 ? 1 - Mathf.Clamp01((curActive - 3) / ((float) commandObjects.Count - 4)) : 0;
		}
	}
	public void SetActive(bool active)
	{
		IsActive = active;
		container.gameObject.SetActive(active);
	}
	public void AddObject(SlashCommand cmd)
	{
		Transform newObj = Instantiate(Resources.Load<Transform>("UI/CommandListItem"), listContainer);
		newObj.GetComponent<UICommandListItem>().SetCommand(cmd);
		newObj.GetComponent<UICommandListItem>().SetActive(commandObjects.Count == 0);
		commandObjects.Add(newObj);
	}
	public void Search(string Text)
	{
		foreach (Transform obj in commandObjects)
		{
			Destroy(obj.gameObject);
		}
		commandObjects.Clear();
		curActive = 0;
		if (Text == "")
		{
			foreach (SlashCommand cmd in commands)
			{
				AddObject(cmd);
			}
		}
		else
		{
			foreach (SlashCommand cmd in commands)
			{
				if (cmd.CommandName.ToLower().Contains(Text.ToLower()))
				{
					AddObject(cmd);
				}
			}
		}
		emptyContainer.gameObject.SetActive(commandObjects.Count == 0);

	}

}
