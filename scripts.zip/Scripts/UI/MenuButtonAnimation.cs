using UnityEngine;

public class MenuButtonAnimation : MonoBehaviour
{
	private Animator anim;
	void Awake()
	{
		anim = GetComponent<Animator>();
	}
	public void SetOpen(bool open)
	{
		anim.SetInteger("state", open ? 1 : 0);
	}
}
