using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;


public enum ChatWindowState
{
	Inactive, Active, Focused
}

public class ChatMessageRef
{
	public TMP_Text txt;
	public bool faded;
}

public class ChatWindow : MonoBehaviour
{
	private Image darken;
	private Scrollbar scrollbar;
	private Image focusImage;
	public TMP_InputField input;
	private ScrollRect scrollRect;
	public static ChatWindow instance;
	RectTransform chatMessage;
	public RectTransform ChatContainer { get; private set; }
	private ChatWindowState _state;
	private RectTransform PopContainer;

	public Vector2 normalSize;
	public Vector2 focusedSize;
	public float stateChangeCooldown = 0;
	public float StateChangeRateLimit = 0.3f;

	public UICommandList commandList;
	public bool Focused => input.isFocused;

	public ChatWindowState state
	{
		get => _state;
		set
		{
			if (_state == value) return;
			_state = value;
			UIController.singleton.SetButtonFocused(UIController.HudButton.Chat, value == ChatWindowState.Focused);
			scrollRect.vertical = value == ChatWindowState.Focused;
			if (value == ChatWindowState.Inactive || value == ChatWindowState.Focused)
			{
				LeanTween.value(darken.gameObject, darken.color.a, 0, chatFadeTime).setOnUpdate((float val) =>
				{
					darken.color = new Color(0, 0, 0, val);
				});
			}
			input.gameObject.SetActive(value == ChatWindowState.Focused);
			scrollbar.gameObject.SetActive(value == ChatWindowState.Focused);
			darken.gameObject.SetActive(value != ChatWindowState.Focused);
			if (value != ChatWindowState.Focused)
				commandList.SetActive(false);

			if (value == ChatWindowState.Focused)
			{
				input.Select();
				input.ActivateInputField();
				LeanTween.size((RectTransform) transform, focusedSize, 0.3f).setEase(LeanTweenType.easeOutQuad).setOnUpdate((float val) =>
				{
					scrollViewToBottom();
				});
				focusImage.enabled = true;
				LeanTween.value(focusImage.gameObject, focusImage.color.a, 0.2f, 0.15f).setOnUpdate((float val) =>
				{
					focusImage.color = new Color(0, 0, 0, val);
				});
				scrollRect.gameObject.SetActive(true);
				PopContainer.gameObject.SetActive(false);
				/*foreach (ChatMessageRef chat in chatMessages)
				{
					var txt = chat.txt;
					txt.gameObject.SetActive(true);
					LeanTween.value(txt.gameObject, 0, 1, 0.15f).setOnUpdate((float val) =>
					{
						txt.color = new Color(txt.color.r, txt.color.g, txt.color.b, val);
					});
				}*/
			}
			else
			{
				input.DeactivateInputField(true);
				LeanTween.size((RectTransform) transform, normalSize, 0.3f).setEase(LeanTweenType.easeOutQuad).setOnComplete(() =>
				{
					scrollViewToBottom();
				});
				LeanTween.value(focusImage.gameObject, focusImage.color.a, 0, 0.15f).setOnUpdate((float val) =>
				{
					focusImage.color = new Color(0, 0, 0, val);
				}).setOnComplete(() =>
				{
					focusImage.enabled = false;
				});
				scrollRect.gameObject.SetActive(false);
				PopContainer.gameObject.SetActive(true);
				/*foreach (ChatMessageRef chat in chatMessages)
				{
					var txt = chat.txt;
					txt.gameObject.SetActive(!chat.faded);
				}*/

			}
			switch (value)
			{
				case ChatWindowState.Active:
					LeanTween.value(darken.gameObject, 0, 0.5f, 0.3f).setOnUpdate((float val) =>
					{
						darken.color = new Color(0, 0, 0, val);
					});
					break;
				case ChatWindowState.Focused:

					break;
			}
		}
	}

	private List<ChatMessageRef> chatMessages = new List<ChatMessageRef>();

	void Awake()
	{
		instance = this;
	}
	void Start()
	{

		input.onValueChanged.AddListener(delegate
		{
			bool active = input.text.Length > 0 && input.text.Substring(0, 1) == "/";
			UICommandList.ActiveCommandFilled = active && UICommandList.ActiveCommand != null && input.text.StartsWith("/" + UICommandList.ActiveCommand.CommandName) && !input.text.Contains(" ");

			commandList.SetActive(active);
			if (active)
				commandList.Search(input.text.Substring(1).ToLower().Split(' ')[0]);
		});

		((RectTransform) transform).sizeDelta = normalSize;
		ChatContainer = (RectTransform) transform.Find("Scroll View/Viewport/Content");
		chatMessage = Resources.Load<RectTransform>("UI/ChatMessage");
		darken = transform.Find("Darken").GetComponent<Image>();
		focusImage = GetComponent<Image>();
		scrollbar = transform.Find("Scroll View/Scrollbar Vertical").GetComponent<Scrollbar>();
		scrollRect = transform.Find("Scroll View").GetComponent<ScrollRect>();
		PopContainer = transform.Find("PopContainer").GetComponent<RectTransform>();

		state = ChatWindowState.Inactive;

	}
	const float chatStayTime = 10f;
	const float chatFadeTime = 0.3f;
	IEnumerator inactiveFade(ChatMessageRef t)
	{
		var txt = t.txt;
		yield return new WaitForSeconds(chatStayTime);
		//if (state == ChatWindowState.Active)
		//{
		LeanTween.value(txt.gameObject, 1, 0, chatFadeTime).setOnUpdate((float val) =>
		{
			txt.color = new Color(txt.color.r, txt.color.g, txt.color.b, val);
		}).setOnComplete(() =>
		{
			//Destroy(txt.gameObject);
			//if (state == ChatWindowState.Active)
			//	txt.gameObject.SetActive(false);
			//t.faded = true;
		});
		//}
		//else
		//   Destroy(txt.gameObject);
		//t.faded = true;
	}
	//private float fadeTime = 0;
	void Update()
	{
		stateChangeCooldown += Time.deltaTime;
		if (state == ChatWindowState.Active)
		{
			if (PopContainer.childCount == 0)
			{
				state = ChatWindowState.Inactive;
			}
			/*fadeTime += Time.deltaTime;
			if (fadeTime > chatStayTime + 0.15f)
			{
				state = ChatWindowState.Inactive;
				fadeTime = 0;
			}*/
		}
	}

	public void ToggleFocused()
	{
		if (stateChangeCooldown < StateChangeRateLimit) return;
		if (state == ChatWindowState.Inactive || state == ChatWindowState.Active)
			state = ChatWindowState.Focused;
		else if (state == ChatWindowState.Focused)
			state = PopContainer.childCount > 0 ? ChatWindowState.Active : ChatWindowState.Inactive;
	}
	public void SetInactive()
	{
		stateChangeCooldown = 0;
		state = PopContainer.childCount > 0 ? ChatWindowState.Active : ChatWindowState.Inactive;
	}

	void scrollViewToBottom()
	{
		Canvas.ForceUpdateCanvases();

		scrollRect.verticalNormalizedPosition = 0f;
	}

	public void PushChat(string username, string message, Color usernameColor)
	{
		if (state == ChatWindowState.Inactive)
		{
			state = ChatWindowState.Active;
		}

		if (PopContainer.childCount >= 8)
		{
			Destroy(PopContainer.GetChild(0).gameObject);
		}
		if (ChatContainer.childCount >= 50)
		{
			Destroy(ChatContainer.GetChild(0).gameObject);
		}

		RectTransform chatPop = Instantiate(chatMessage, PopContainer);
		TMP_Text t = chatPop.GetComponent<TMP_Text>();
		t.text = $"{message}";

		if (username != "")
		{
			t.text = $"<color=#{ColorUtility.ToHtmlStringRGB(usernameColor)}><b>{username}</b></color>: " + message;
		}

		ChatMessageRef r = new ChatMessageRef
		{
			txt = t,
			faded = false
		};

		RectTransform chat = Instantiate(chatPop.gameObject, ChatContainer).GetComponent<RectTransform>();

		chatMessages.Add(r);

		Destroy(chatPop.gameObject, chatStayTime + 0.6f);
		StartCoroutine(inactiveFade(r));

		LayoutRebuilder.ForceRebuildLayoutImmediate(ChatContainer);
		LayoutRebuilder.ForceRebuildLayoutImmediate(PopContainer);

		if (state == ChatWindowState.Active || scrollRect.verticalNormalizedPosition == 0f)
		{
			scrollViewToBottom();
		}


		/*if (state == ChatWindowState.Active)
		{
			fadeTime = 0;
		}*/
		Canvas.ForceUpdateCanvases();
	}
}

