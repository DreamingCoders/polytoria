using UnityEngine;
using UnityEngine.UI;

public class UIStaminaBar : MonoBehaviour
{
	//private float _fadeTimer = 0;
	const float fadeTime = 0.3f;
	private float _fadeStartTimer;
	private int fadeTimerState;
	const float fadeStartTime = 0.3f;

	private Image fill;
	private Image cont;
	private float fillAmount = 1f;
	public Color FillColor;
	public Color FillExhaustedColor;
	private void Awake()
	{
		cont = transform.Find("Container").GetComponent<Image>();
		fill = transform.Find("Container/Fill").GetComponent<Image>();
	}
	float alpha = 1;
	void Update()
	{
		if (fillAmount == 1)
		{
			alpha = Mathf.Clamp01(alpha - Time.deltaTime / fadeTime);

			/*_fadeStartTimer += Time.deltaTime;
			if (_fadeStartTimer > fadeStartTime) {
				_fadeTimer += Time.deltaTime;
				if (_fadeTimer > fadeTime) {
					_fadeTimer = 0;
					_fadeStartTimer = 0;
					fadeTimerState = 0;
					LeanTween.value(gameObject, 1, 0, 0.2f).setOnUpdate((float val) => {
						cont.color = new Color(cont.color.r, cont.color.g, cont.color.b, val);
						fill.color = new Color(fill.color.r, fill.color.g, fill.color.b, val);
					});
				}
			}*/
		}
		else
		{
			alpha = Mathf.Clamp01(alpha + Time.deltaTime / fadeTime);
			/*if (_fadeTimer != 0 || _fadeStartTimer != 0) {
				cont.color = new Color(cont.color.r, cont.color.g, cont.color.b, 1);
				fill.color = new Color(fill.color.r, fill.color.g, fill.color.b, 1);
			}
			_fadeStartTimer = 0;
			_fadeTimer = 0;*/
		}
		cont.color = new Color(cont.color.r, cont.color.g, cont.color.b, alpha);
		fill.color = new Color(fill.color.r, fill.color.g, fill.color.b, alpha);
	}
	public void SetEnabled(bool enabled)
	{
		cont.gameObject.SetActive(enabled);
	}

	public void SetFill(float newFillAmount, bool exhausted)
	{
		this.fillAmount = Mathf.Clamp01(newFillAmount);
		fill.fillAmount = this.fillAmount;
		fill.color = exhausted ? FillExhaustedColor : FillColor;
		fill.color = new Color(fill.color.r, fill.color.g, fill.color.b, alpha);
	}
}