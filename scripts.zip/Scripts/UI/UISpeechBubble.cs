using TMPro;
using UnityEngine;

public class UISpeechBubble : MonoBehaviour
{
	private RectTransform chatContentRect;
	private RectTransform bubbleRect;
	private TMP_Text chatText;
	private string message;
	public Vector2 Padding;
	public float DisplayTime = 8;
	float targetOpacity = 0;
	float timer = 0;
	CanvasGroup canvasGroup;

	public string Message
	{
		get
		{
			return message;
		}
		set
		{
			message = value;
			chatText.text = message;
			chatText.ForceMeshUpdate();
			Canvas.ForceUpdateCanvases();
			bubbleRect.sizeDelta = chatContentRect.sizeDelta + Padding;

			targetOpacity = 1;
			timer = DisplayTime;
		}
	}

	void Awake()
	{
		bubbleRect = transform.Find("BubbleRect").GetComponent<RectTransform>();

		chatContentRect = transform.Find("ChatContentContainer/ChatContentRect").GetComponent<RectTransform>();
		chatText = transform.Find("ChatContentContainer/ChatContentRect/ChatText").GetComponent<TMP_Text>();

		canvasGroup = GetComponent<CanvasGroup>();
	}

	private void Update()
	{
		timer -= Time.deltaTime;

		if (timer <= 0)
		{
			targetOpacity = 0;
		}

		if (canvasGroup.alpha != targetOpacity)
			canvasGroup.alpha = Mathf.Lerp(canvasGroup.alpha, targetOpacity, Time.deltaTime * 8);

		transform.LookAt(transform.position + Camera.main.transform.rotation * Vector3.forward, Camera.main.transform.rotation * Vector3.up);

		// float distance = Vector3.Distance(transform.position, Camera.main.transform.position);
		// transform.localScale = Vector3.one * distance * 0.002f;
	}

	// public string test;
	// IEnumerator Start()
	// {
	// 	Message = "test";
	// 	while (true)
	// 	{
	// 		yield return new WaitForSeconds(0.5f);
	// 		Message = test;
	// 	}
	// }

}