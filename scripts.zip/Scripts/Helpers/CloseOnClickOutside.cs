using UnityEngine;
using UnityEngine.EventSystems;

public class CloseOnClickOutside : MonoBehaviour
{
	bool close;

	void Update()
	{
		if (close)
		{
			gameObject.SetActive(ClickingSelfOrChild());
			close = false;
		}
		if (Input.GetMouseButtonUp(0) || Input.GetMouseButtonUp(1) || Input.GetMouseButtonUp(2))
		{
			close = true;
		}
	}
	private bool ClickingSelfOrChild()
	{
		RectTransform[] rectTransforms = GetComponentsInChildren<RectTransform>();
		foreach (RectTransform rectTransform in rectTransforms)
		{
			if (EventSystem.current.currentSelectedGameObject == rectTransform.gameObject)
			{
				return true;
			};
		}
		return false;
	}
}
