using System.Reflection;
using HSVPicker;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UI.ProceduralImage;

public class PropertyGridItemColor : PropertyGridItem
{
	ProceduralImage colorDisplayer;
	Button colorDisplayerBtn;

	private void Awake()
	{

	}

	public override void SetProperty(PropertyInfo property)
	{
		base.SetProperty(property);
		// toggle = transform.Find("ValueContainer/Toggle").GetComponent<Toggle>();
		// if (property.CanWrite) {
		// 	toggle.onValueChanged.AddListener(OnValueChanged);
		// } else {
		// 	toggle.interactable = false;
		// }

		colorDisplayer = transform.Find("ValueContainer/ColorBtn").GetComponent<ProceduralImage>();
		colorDisplayerBtn = colorDisplayer.GetComponent<Button>();

		if (property.CanWrite)
		{
			colorDisplayerBtn.onClick.AddListener(OnColorDisplayerBtnClick);
		}
		else
		{
			colorDisplayerBtn.interactable = false;
		}
	}

	void OnColorDisplayerBtnClick()
	{
		Color color = (Color) currentValue;
		ColorPicker picker = CreatorController.singleton.propertyColorPicker;
		picker.gameObject.SetActive(true);
		picker.onValueChanged.RemoveAllListeners();
		picker.CurrentColor = color;
		picker.R = color.r;
		picker.G = color.g;
		picker.B = color.b;
		picker.A = color.a;
		picker.onValueChanged.AddListener(OnValueChange);
	}

	private void OnValueChange(Color color)
	{
		colorDisplayer.color = color;
		if ((Color) currentValue != color)
		{
			InvokeValueChanged(color);
		}
	}

	private void OnDestroy()
	{
		CreatorController.singleton.propertyColorPicker.gameObject.SetActive(false);
	}

	public override void SetValue(object value)
	{
		if (currentValue != null && !currentValue.Equals(value))
		{
			editingMultipleValues = true;
			colorDisplayer.color = Color.white;
		}
		else
		{
			colorDisplayer.color = (Color) value;
		}

		currentValue = value;
	}

	void OnValueChanged(bool value)
	{
		InvokeValueChanged(value);
	}
}
