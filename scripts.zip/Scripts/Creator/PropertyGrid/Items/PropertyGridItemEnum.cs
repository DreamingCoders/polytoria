using System;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
public class PropertyGridItemEnum : PropertyGridItem
{
	TMP_Dropdown dropdown;

	public override void SetProperty(PropertyInfo property)
	{
		base.SetProperty(property);
		dropdown = transform.Find("ValueContainer/Dropdown").GetComponent<TMP_Dropdown>();
		if (property.CanWrite)
		{
			dropdown.onValueChanged.AddListener(OnValueChanged);
		}
		else
		{
			dropdown.interactable = false;
		}

		string[] names = Enum.GetNames(property.PropertyType);
		List<string> options = new List<string>();
		foreach (string name in names)
		{
			options.Add(name);
		}
		dropdown.ClearOptions();
		dropdown.AddOptions(options);
	}

	public override void SetValue(object value)
	{
		dropdown.onValueChanged.RemoveListener(OnValueChanged);

		if (currentValue != null && !currentValue.Equals(value))
		{
			editingMultipleValues = true;
			dropdown.value = -1;
		}
		else
		{
			dropdown.value = (int) value;
		}

		dropdown.onValueChanged.AddListener(OnValueChanged);
		currentValue = value;
	}

	void OnValueChanged(int value)
	{
		InvokeValueChanged(value);
	}
}