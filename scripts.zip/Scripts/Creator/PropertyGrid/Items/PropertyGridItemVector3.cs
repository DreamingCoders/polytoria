using System.Reflection;
using TMPro;
using UnityEngine;
public class PropertyGridItemVector3 : PropertyGridItem
{
	TMP_InputField inputFieldX;
	TMP_InputField inputFieldY;
	TMP_InputField inputFieldZ;
	public override void SetProperty(PropertyInfo property)
	{
		base.SetProperty(property);
		inputFieldX = transform.Find("ValueContainer/InputFieldX").GetComponent<TMP_InputField>();
		inputFieldY = transform.Find("ValueContainer/InputFieldY").GetComponent<TMP_InputField>();
		inputFieldZ = transform.Find("ValueContainer/InputFieldZ").GetComponent<TMP_InputField>();
		if (property.CanWrite)
		{
			inputFieldX.onValueChanged.AddListener(OnValueChanged);
			inputFieldY.onValueChanged.AddListener(OnValueChanged);
			inputFieldZ.onValueChanged.AddListener(OnValueChanged);
		}
		else
		{
			inputFieldX.interactable = false;
			inputFieldY.interactable = false;
			inputFieldZ.interactable = false;
		}
	}

	public override void SetValue(object value)
	{
		inputFieldX.onValueChanged.RemoveListener(OnValueChanged);
		inputFieldY.onValueChanged.RemoveListener(OnValueChanged);
		inputFieldZ.onValueChanged.RemoveListener(OnValueChanged);

		if (currentValue != null && !currentValue.Equals(value))
		{
			editingMultipleValues = true;
			inputFieldX.text = "-";
			inputFieldY.text = "-";
			inputFieldZ.text = "-";
		}
		else
		{
			Vector3 v = (Vector3) value;
			inputFieldX.text = v.x.ToString();
			inputFieldY.text = v.y.ToString();
			inputFieldZ.text = v.z.ToString();
		}

		inputFieldX.onValueChanged.AddListener(OnValueChanged);
		inputFieldY.onValueChanged.AddListener(OnValueChanged);
		inputFieldZ.onValueChanged.AddListener(OnValueChanged);

		currentValue = value;
	}

	void OnValueChanged(string value)
	{
		Vector3 vector = new Vector3();
		if (float.TryParse(inputFieldX.text, out vector.x) && float.TryParse(inputFieldY.text, out vector.y) && float.TryParse(inputFieldZ.text, out vector.z))
		{
			InvokeValueChanged(vector);
		}
	}
}