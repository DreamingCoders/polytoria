using System.Reflection;
using TMPro;
using UnityEngine;
public class PropertyGridItemVector2 : PropertyGridItem
{
	TMP_InputField inputFieldX;
	TMP_InputField inputFieldY;
	public override void SetProperty(PropertyInfo property)
	{
		base.SetProperty(property);
		inputFieldX = transform.Find("ValueContainer/InputFieldX").GetComponent<TMP_InputField>();
		inputFieldY = transform.Find("ValueContainer/InputFieldY").GetComponent<TMP_InputField>();
		if (property.CanWrite)
		{
			inputFieldX.onValueChanged.AddListener(OnValueChanged);
			inputFieldY.onValueChanged.AddListener(OnValueChanged);
		}
		else
		{
			inputFieldX.interactable = false;
			inputFieldY.interactable = false;
		}
	}

	public override void SetValue(object value)
	{
		inputFieldX.onValueChanged.RemoveListener(OnValueChanged);
		inputFieldY.onValueChanged.RemoveListener(OnValueChanged);

		if (currentValue != null && !currentValue.Equals(value))
		{
			editingMultipleValues = true;
			inputFieldX.text = "-";
			inputFieldY.text = "-";
		}
		else
		{
			Vector2 v = (Vector2) value;
			inputFieldX.text = v.x.ToString();
			inputFieldY.text = v.y.ToString();
		}

		inputFieldX.onValueChanged.AddListener(OnValueChanged);
		inputFieldY.onValueChanged.AddListener(OnValueChanged);

		currentValue = value;
	}

	void OnValueChanged(string value)
	{
		Vector2 vector = new Vector2();
		if (float.TryParse(inputFieldX.text, out vector.x) && float.TryParse(inputFieldY.text, out vector.y))
		{
			InvokeValueChanged(vector);
		}
	}
}