using System.Reflection;
using UnityEngine.UI;
public class PropertyGridItemBoolean : PropertyGridItem
{
	Toggle toggle;
	public override void SetProperty(PropertyInfo property)
	{
		base.SetProperty(property);
		toggle = transform.Find("ValueContainer/Toggle").GetComponent<Toggle>();
		if (property.CanWrite)
		{
			toggle.onValueChanged.AddListener(OnValueChanged);
		}
		else
		{
			toggle.interactable = false;
		}
	}

	public override void SetValue(object value)
	{
		toggle.onValueChanged.RemoveListener(OnValueChanged);

		if (currentValue != null && !currentValue.Equals(value))
		{
			editingMultipleValues = true;
			toggle.isOn = false;
		}
		else
		{
			toggle.isOn = (bool) value;
		}

		toggle.onValueChanged.AddListener(OnValueChanged);

		currentValue = value;
	}

	void OnValueChanged(bool value)
	{
		InvokeValueChanged(value);
	}
}