using System.Reflection;
using TMPro;
public class PropertyGridItemString : PropertyGridItem
{
	TMP_InputField inputField;
	public override void SetProperty(PropertyInfo property)
	{
		base.SetProperty(property);
		inputField = transform.Find("ValueContainer/InputField").GetComponent<TMP_InputField>();
		if (property.CanWrite)
		{
			inputField.onValueChanged.AddListener(OnValueChanged);
		}
		else
		{
			inputField.interactable = false;
		}
	}

	public override void SetValue(object value)
	{
		inputField.onValueChanged.RemoveListener(OnValueChanged);

		if (currentValue != null && !currentValue.Equals(value))
		{
			editingMultipleValues = true;
			inputField.text = "-";
		}
		else
		{
			inputField.text = value.ToString();
		}

		inputField.onValueChanged.AddListener(OnValueChanged);

		currentValue = value;
	}

	void OnValueChanged(string value)
	{
		InvokeValueChanged(value);
	}
}