using System.Reflection;
using TMPro;

public class PropertyGridItemReadOnly : PropertyGridItem
{
	public override void SetProperty(PropertyInfo property)
	{
		base.SetProperty(property);
	}

	public override void SetValue(object value)
	{
		if (currentValue != null && !currentValue.Equals(value))
		{
			editingMultipleValues = true;
			transform.Find("ValueContainer/Label").GetComponent<TMP_Text>().text = "-";
		}
		else
		{
			transform.Find("ValueContainer/Label").GetComponent<TMP_Text>().text = value.ToString();
		}

		currentValue = value;
	}
}