using System;
using System.Collections.Generic;
using System.Reflection;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
public class CreatorPropertyGrid : MonoBehaviour
{
	Vector2 scrollPosition;
	RectTransform content;
	Dictionary<string, PropertyGridItem> items = new Dictionary<string, PropertyGridItem>();
	List<Instance> instances = new List<Instance>();
	private void Awake()
	{
		content = GetComponentInChildren<ScrollRect>().content;
	}

	public void SetPropertyGridItems(List<Instance> instances)
	{
		foreach (Transform child in content)
		{
			Destroy(child.gameObject);
		}
		items.Clear();

		if (instances.Count == 0)
		{
			return;
		}

		this.instances = instances;

		Type type = instances[0].GetType();

		Type baseType = type;
		while (baseType != null)
		{
			GameObject section = Instantiate(Resources.Load("Prefabs/PropertyGrid/Section")) as GameObject;
			section.transform.SetParent(content, false);
			section.GetComponentInChildren<TMP_Text>().text = baseType.Name;
			Sprite icon = Resources.Load<Sprite>("TreeViewIcons/" + baseType.Name);
			if (icon != null)
			{
				section.transform.Find("Content/Icon").GetComponent<Image>().sprite = icon;
			}

			foreach (PropertyInfo property in baseType.GetProperties(BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.Instance))
			{
				CreatorProperty attribute = property.GetCustomAttribute<CreatorProperty>();
				if (attribute == null)
				{
					continue;
				}

				AddPropertyItem(property);
			}

			baseType = baseType.BaseType;
			if (baseType == typeof(Instance).BaseType)
			{
				break;
			}
		}

		foreach (Instance instance in instances)
		{
			if (instance.GetType() != type)
			{
				foreach (Transform child in content)
				{
					Destroy(child.gameObject);
				}

				GameObject section = Instantiate(Resources.Load("Prefabs/PropertyGrid/Section")) as GameObject;
				section.transform.SetParent(content, false);
				section.GetComponentInChildren<TMP_Text>().text = "Cannot edit multiple objects of different types";
				return;
			}

			foreach (PropertyInfo property in type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
			{
				CreatorProperty attribute = property.GetCustomAttribute<CreatorProperty>();
				if (attribute == null)
				{
					continue;
				}

				items[property.Name].SetValue(property.GetValue(instance));
			}
		}
	}

	public void Clear()
	{
		this.SetPropertyGridItems(new List<Instance>());
	}

	private void AddPropertyItem(PropertyInfo property)
	{
		// PropertyGridItem item = Instantiate(Resources.Load<PropertyGridItem>("Prefabs/PropertyGrid/Item"));
		// item.transform.SetParent(content, false);
		// item.SetProperty(property);

		string itemType = "ReadOnly";

		if (property.PropertyType == typeof(string))
		{
			itemType = "String";
		}
		else if (property.PropertyType == typeof(Vector3))
		{
			itemType = "Vector3";
		}
		else if (property.PropertyType == typeof(Vector2))
		{
			itemType = "Vector2";
		}
		else if (property.PropertyType == typeof(int))
		{
			itemType = "Integer";
		}
		else if (property.PropertyType == typeof(float))
		{
			itemType = "Float";
		}
		else if (property.PropertyType == typeof(bool))
		{
			itemType = "Boolean";
		}
		else if (property.PropertyType == typeof(Color))
		{
			itemType = "Color";
		}
		else if (property.PropertyType.IsEnum)
		{
			itemType = "Enum";
		}

		if (!items.ContainsKey(property.Name))
		{
			PropertyGridItem item = Instantiate(Resources.Load<PropertyGridItem>("Prefabs/PropertyGrid/Items/" + itemType));
			item.transform.SetParent(content, false);
			items.Add(property.Name, item);
			item.SetProperty(property);
			item.PropertyChanged += (value) => { OnValueChanged(property, value); };
		}
	}

	private void OnValueChanged(PropertyInfo property, object value)
	{
		foreach (Instance instance in instances)
		{
			property.SetValue(instance, value);
		}
	}
}
