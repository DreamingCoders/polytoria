using System;
using System.Reflection;
using TMPro;
using UnityEngine;

public abstract class PropertyGridItem : MonoBehaviour
{
	public event Action<object> PropertyChanged;
	PropertyInfo property;
	protected object currentValue = null;
	protected bool editingMultipleValues = false;

	public virtual void SetProperty(PropertyInfo property)
	{
		this.property = property;
		transform.Find("Label").GetComponent<TMP_Text>().text = property.Name;
	}

	public abstract void SetValue(object value);
	protected virtual void InvokeValueChanged(object value)
	{
		PropertyChanged?.Invoke(value);
	}
}